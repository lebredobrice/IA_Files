<?php
header('Content-Type: text/html; charset=UTF-8');

if(!isset($_SESSION)){
	session_start();
//	session_destroy();
}

// Few config
include('config.php');

echo "<p><span style='font-size:2em'>".SITENAME."</span></p>";
echo "<p style='font-style:italic'>Install the app</p>";
echo "<p>Installe les tables et les donn�es statiques dans certaines tables<br><br></p>";

// correct password
$password = SITEPASS;               // password
if(isset($_POST['password']) && $_POST['password'] == $password){
	$_SESSION['typedpassword'] = $_POST['password'];                // le client est connect�
}

if(isset($_POST['password']) && $_POST['password'] != $password){
		echo "<p style='color:red'>Mot de passe incorrect<br></p>";
}
// Formulaire � afficher
if(isset($_SESSION['typedpassword']) ){
	echo "<p style='color:green'>Bienvenue admin  <a href='logout.php'>deconnexion</a></p>";
	// echo "<p>Installe les tables et les donn�es statiques dans certaines tables</p>";
	echo "<p>
			<form method='post' enctype='multipart/form-data'>
				<div style='background-color:#F4F4F4; width:80%;'>
					<br>
						<input type='submit' value='COMMENCER' style='height:40px; width:175px'>
					<br>
				</div>
				<input type='hidden' name='commencer'>
			</form>
		 </p>";
}
else{
	echo "<p>veuillez vous identifier pour continuer</p>";
	echo "<p><form method='post'>
		     <input type='password' name='password' name='password'><input type='submit' value='ok'>
			 </form>
		  </p>";
}

// session_destroy();