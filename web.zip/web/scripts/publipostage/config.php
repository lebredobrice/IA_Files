<?php 
	$_SESSION['fileDir']       = "files";                           // upload directrory
	$_SESSION['inputName']     = "companiesFile";                   // upload directrory
	$_SESSION['outputfile']    = "output.txt";                      // upload directrory
	define('HOST',   "sg211.servergrove.com");			            // database host
	define('DBNAME', "weynaakc_kigali");	 					    // database name
	define('USER',   "weyna_kigali");                               // database user
	define('PASS',   "!aA111111");                                  // database pass
	define('SITENAME',   "Publipostage File Generator");            // site name
	define('SITEPASS',   "aDmin58965");                             // site pass