<?php
header('Content-Type: text/html; charset=UTF-8');
// error reporting
error_reporting(E_ALL);
ini_set("display_errors", 1);

//header
include("header.php");

// autoloader   
function my_autoloader($class) {
    include __DIR__.'/class/'.$class.'.php';
}
spl_autoload_register('my_autoloader');



// main
if(isset($_POST['commencer'])){
	//uploaded file of ids and emails
	$target_dir = "files/";
	$target_file = $target_dir . basename($_FILES["emailfile"]["name"]);
	
	$file = new writetofile;
	// is a file uploaded?
	if (move_uploaded_file($_FILES["emailfile"]["tmp_name"], $target_file)) {
        // is checkbox checked?
		if(isset($_POST['diff'])){
			$file->writingtofile($_FILES["emailfile"]["name"], TRUE);
		}
		else{
			$file->writingtofile($_FILES["emailfile"]["name"]);
		}
    } else {
        $file->writingtofile();
    }
}

echo "
<p>&nbsp;</p>
<p>&nbsp;</p>";

// footer
include("footer.php");