<?php
/**
 *	Walk thru the company table and write line to the text file
 **/
header('Content-Type: text/html; charset=UTF-8');
class writetofile
{

	public $connexion;
	
	public function __construct(){
		// connexion
		$this->connexion = new Dbconnexion;
		$this->connexion->connect();
	}

	public function writingtofile($filename = NULL, $diff = NULL){
		ini_set('max_execution_time', 0);

		// file creation
		$myfile = "files/".$filename;
		// id list
		$idlist = array();
		$idfromfile = array();
		$idfromdb = array();
		
		// ids from the file
		if($filename){
			// open the file
			$fileobj = fopen($myfile,"r");

			while(!feof($fileobj))
  			{
  				$fileline = fgets($fileobj);
				$filelineArray = explode(",", $fileline);
				// id list
				if($filelineArray[0]){
					$id = trim($filelineArray[0]);
					array_push($idfromfile, $id);
					$idlist = $idfromfile;
					$message = utf8_encode("Source de donn�es: fichier")."<br>";
				}
				// update email in the database if differentiation not checked
				if(isset($filelineArray[0]) && isset($filelineArray[1]) && $diff == NULL){
					$email = trim($filelineArray[1]);
					$sql =  "UPDATE activite SET email = '$email'  WHERE id = '$id'";
					$stmt = $this->connexion->MyPDO->prepare($sql);
					$stmt->execute();
					$count = $stmt->rowCount();
				}
  			}
			fclose($fileobj);
		}
		
		// ids from the database - id from file
		$sql    =  "SELECT id FROM activite";
		$stmt   = $this->connexion->MyPDO->prepare($sql);
		$this->connexion->MyPDO->exec("set names utf8");
		$stmt->execute();
		$result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
		
		if($filename && $diff){ 
			foreach( $result as $row ) {
				// id list
				array_push($idfromdb, $row['id']);
			}
			$idlist = array_diff($idfromdb, $idfromfile);
			$message = utf8_encode("Source de donn�es: difference entre la base de donn�e et le fichier")."<br>";
		}
// var_dump($result);
		// ids from the database
		if(!$filename){
		$message = utf8_encode("Source de donn�es: database ").DBNAME."<br>";
			foreach( $result as $row ) {
				// id list
				array_push($idfromdb, $row['id']);
			}
			$idlist = $idfromdb;
		}
		// message de la source de donn�e
		echo $message;
		// Publipostage data
		// query
		$sql =  "SELECT * FROM activite WHERE id = :id";
		$sth = $this->connexion->MyPDO->prepare($sql);
		
		// company property initialisation
		$properties = new companyproperties;
		// company links initialisation
		$link = new linkcreator;
		// walking and writing
		$lineText = "";
		$towrite = array();
		
		$publipostagefile = fopen("files/publipostage.txt", "w");
		foreach($idlist as $id){
			$sth->bindParam(':id', $id);
			$sth->execute();
			$result = $sth->fetchAll();
			foreach($result as $row) {
			//if($row['email']){ // only companies with email are treated
				$properties->getProperties($row['id']); // properties id to name
				$link->getLink($row['id']); // build company links object property
				// create a line to write in output
				$lineText = $row['id'].'*'.$row['entreprise'].'*'.$row['bp'].'*'.$row['telephone01'].'*'.$row['telephone02'].'*'.trim($row['web']).'*'.$row['fax'].'*'.$row['contact'].'*'.$properties->fonction.'*'.$row['map'].'*'.$row['email'].'*'.$properties->alphabetique.'*'.$properties->rubrique.'*'.$properties->quartier.'*'.$properties->rue.'*'.$link->alphabetiqueLink.'*'.$link->rubriqueLink.'*'.$link->quartierLink.'*'.$link->rueLink.'*'.$link->companyLink.'*'.$link->gsearchLink.'*'.$link->gmapLink.'*'.$properties->adsize.'*'.$row['activated'];
				// remove all line breaks
				$lineText = preg_replace( "/\r|\n/", "", $lineText );
				// write to output text file
				array_push($towrite, $lineText);
			//}
			}
		}
		// Write publipostage data to file and output
		echo "Nombre d'entreprises: ".count($idlist);
		foreach($towrite as $lineText){
			echo "<p>".$lineText."</p>";
			fwrite($publipostagefile, $lineText."\r\n\r\n");
		}
		fclose($publipostagefile);
	}
}