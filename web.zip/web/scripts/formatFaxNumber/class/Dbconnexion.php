<?php

class Dbconnexion
{
	public $MyPDO  = "";
	public $host   = HOST;
	public $dbname = DBNAME;
	public $user   = USER;
	public $pass   = PASS;
	
	public function connect(){
		try{
			$this->MyPDO = new PDO("mysql:host=".$this->host.";dbname=".$this->dbname, $this->user, $this->pass);
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}
}