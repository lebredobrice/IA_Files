<?php
echo '<br>';
echo '&copy; September 2018 '.SITENAME;