<?php 
	$_SESSION['fileDir']       = "files";                           // upload directrory
	$_SESSION['inputName']     = "companiesFile";                   // upload directrory
	$_SESSION['outputfile']    = "output.txt";                      // upload directrory
	define('HOST',   "localhost");			            // database host
	define('DBNAME', "default_db");	 					    // database name
	define('USER',   "root");                               // database user
	define('PASS',   "");                                  // database pass
	define('SITENAME',   "Format Fax Number");                    // site name
	define('SITEPASS',   "aDmin58965");                        // site pass
