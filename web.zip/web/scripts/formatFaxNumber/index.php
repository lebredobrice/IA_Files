<?php 
// error reporting
error_reporting(E_ALL);
ini_set("display_errors", 1);

// autoloader   
function my_autoloader($class) {
    include 'class/' . $class . '.php';
}
spl_autoload_register('my_autoloader');

//header
include("header.php");

// main
if(isset($_POST['commencer'])){
	include("controller.php");
}
// footer
include("footer.php");