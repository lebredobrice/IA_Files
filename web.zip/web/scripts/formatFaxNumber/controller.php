<?php 

// tableau des numeros de telephone et fax
$numbersArrayObj = new numbers;
$numbersArray = $numbersArrayObj->getNumbers();

// liste des numero de fax
$modification = new modification;
$selectedFax = array();
$i = 0;
foreach($numbersArray as $key => $value){ // update (formatage) des numeros l'array des numbers
	// traitement de fax
//	echo $value['fax']."<br>";
	if( $modification->verification(trim($value['fax'])) ){
		$selectedFax[$i]['fax'] = $modification->formatel($value['fax']);
		$selectedFax[$i]['id']  = $value['id'];
		$i++;
	}
}
//echo "<pre>";
//var_dump($selectedFax);
//echo "</pre>";

// update the database
$update = new update;
$updated = $update->updatenumbers($selectedFax); // update
echo $update->message.'<br>'; // result message
// affichage des donn�es trait�s
foreach($updated as $key=>$value){ // update (formatage) des numeros l'array des numbers
	echo '<p>';
	echo 'fax:'.$value['fax'].' ';
	echo '</p>';
}