﻿<?php
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
	
	$f01 = fopen( "anglais_francais.txt", "r" ) or exit( "Unable to open file!" ); // for read lines
	$f02 = fopen( "francais_anglais.txt",  "w" ) or exit( "Unable to open file!" );// for write results
	while ( !feof( $f01 ) ){
		$line    = fgets( $f01 ); // Make an array new line and space as delimiter
		$lineTab = explode( '*', $line ); //
		if( isset( $lineTab[0] ) && isset( $lineTab[1] ) ){
			$rubrique    = utf8_encode(trim($lineTab[1]));
			$tranlation  = utf8_encode(trim($lineTab[0]));
			fwrite( $f02,  $rubrique."*".$tranlation."\r\n"  );
			echo "$rubrique * $tranlation <br>";
		}
	}
	fclose($f01);
	fclose($f02);