<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
/**
 *  This script wipe the translation table
 *  iterate a translation file, line by line
 *  get each translated id from rubrique table
 *  ge langage id from the translation file name
 *  insert the translatons
 **/

// create connexion object to database
require_once("Dbconnexion.php");

class SetTranslation
{
	public $connexion;
	
	public function __construct(){
		// connexion
		$this->connexion = new Dbconnexion;
		$this->connexion->connect();
	}

		// get rubrique id
	public function getId($item, $table){
		$field = $table;
		// query
		$this->connexion->MyPDO->quote( $item );
		$query = "SELECT id 
				  FROM $table
				  WHERE $field =:item";
		$this->connexion->MyPDO->exec("set names utf8");		  
		$stmt = $this->connexion->MyPDO->prepare($query);
		$stmt->execute( [':item' => $item] );
		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		$id = $result['id'];

		if(!$id){
			echo "erreur $item n' existe pas dans la table $table<br>"; 
			return NULL;
		}
		return $id;
	}
	
	// insert translation
	public function insertTranslation( $languageId, $rubriqueId, $translation, $translatedId ){
		$this->connexion->MyPDO->quote($translation);
		$this->connexion->MyPDO->exec("set names utf8");
		$query = "INSERT INTO translation ( language_id, table_id, translation, translatedid ) 
				  VALUES ( 
						  '$languageId', 
						  '$rubriqueId',
						  :translation, 
						  '$translatedId'
						)";
		$stmt = $this->connexion->MyPDO->prepare($query);
		$stmt->execute([':translation' => $translation]);
		$id = $this->connexion->MyPDO->lastInsertId();

		if(!$id){
			return false;
		}
		return $id;
	}
	// iterate and insert
    public function iterate($file){
		// language Id
		$langageIdTab = explode( '.', $file );
		$languageId   = $langageIdTab[0];
		// delete before insert
		$this->deleteRubriqueTranslation('translation', $languageId, 1); // 1 is the id o fthe table rubrique
		//
		$directory  = $_SESSION['fileDir'];
		$outputfile = $_SESSION['outputfile'];
		$f01 = fopen("$directory/$file.txt", "r") or exit("Unable to open file!"); // for read lines
		$f02 = fopen("$directory/$outputfile",  "w") or exit("Unable to open file!");// for write results
		$date       =  date("d/m/Y");
		$i = 1;

		fwrite($f02, utf8_encode("Traductions ajout�es avec succes ($date)\r\n\r\n"));
		while (!feof($f01)){
			$line = fgets($f01); // Make an array new line and space as delimiter
			$lineTab = explode('*', $line); //
			if( isset( $lineTab[1] ) ){

				echo '<b>'.$i.'- '.$lineTab[0].'</b>:<br>';

				// rubrique
				$rubrique     = trim( $lineTab[0] );
				// translation
				$translation  = trim( $lineTab[1] );
				// language Id
				$langageIdTab = explode( '.', $file );
				$languageId   = $langageIdTab[0];
				// translated id
				if( $rubrique ){
					$translatedId = $this->getId( $rubrique, 'rubrique' );
				}
				// insert
				if( $translatedId ){
					// insert new translation
					$inserted = $this->insertTranslation( $languageId, 1, $translation, $translatedId );
					// write result in a file
					if( $inserted ){
						fwrite($f02, utf8_encode("$rubrique - $translation<br>:  succ�s\r\n"));
						echo utf8_encode("<span style='color: green'>SUCCES </span>$rubrique - $translation<br>");
					}
					else{
						echo utf8_encode("<span style='color: red'>x Erreur: $translation not inserted<br>") ;
					}
					$i++;
				}
			}
		}
	}

	// delete all translation
	public function deleteRubriqueTranslation( $table, $language_id, $table_id ){
		$query = "DELETE FROM $table 
				  WHERE language_id = '$language_id'
				  AND   table_id    = '$table_id'
				  ";
		$stmt   = $this->connexion->MyPDO->prepare($query);
		$stmt->execute();
		$count = $stmt->rowCount();

		if($count){
			echo utf8_encode("<span style='color:green'>$count effac� de la table $table</span><br>");
		}
		else{
			echo utf8_encode("<span style='color:red'>0 supprim�</span><br>") ;
		}
	}
}

// $insertTrans->getRubriqueId('Abattoir');
?>


