<?php
// error reporting
error_reporting(E_ALL);
ini_set("display_errors", 1);

function treatlist(){
	$i = 0;
	$rueIdWithBusiness = [];
	
	try{
		$MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}
	
	$query01 = "SELECT id FROM rue";
	
	$stmt01 = $MyPDO->prepare($query01);
	$stmt01->execute();
	$result01 = $stmt01->fetchAll(\PDO::FETCH_NUM);
	$rueIdWithNoBusiness = [];
	if($result01){
		$query02 = "SELECT entreprise FROM activite WHERE rueId =:rueid";
		
		$j = 0;
		foreach($result01 as $key=>$value){
			$ruevalue = $value[0];
			$stmt02 = $MyPDO->prepare($query02);
			$stmt02->bindParam(":rueid", $ruevalue);
			$stmt02->execute();
			//Fetch all of the values in form of a numeric array 
			$result02 = $stmt02->fetchAll(\PDO::FETCH_NUM);		
			$count = $stmt02->rowCount();
			//echo $ruevalue;
			if(!$count){ // aucune entreprise dans cette rue
				$rueIdWithNoBusiness[$j] = $ruevalue;
				$j++;
			}
		}
		//echo $j;
		//echo "<pre>";
		//	var_dump($rueIdWithNoBusiness);
		//echo "</pre>";
	}
	
// Output file

	$f01 = fopen("removedStreetId.txt", "w") or exit("Unable to open file!");
	foreach($rueIdWithNoBusiness as $key=>$value){
		fwrite($f01, $value."\n");
	}

// Remove
	$query03 = "DELETE FROM rue WHERE id =:rueid";
	$stmt03 = $MyPDO->prepare($query03);
	$k = 0;
	echo count($rueIdWithNoBusiness);
	foreach($rueIdWithNoBusiness as $key=>$value){
		$ruevalue = (int)$value;
		$stmt03->bindParam(":rueid", $ruevalue);
		$stmt03->execute();
		$count = $stmt03->rowCount();
		echo ($count);
		$k = $k + $count;
	}
	echo "Total supprimé: ".$k;
	
	fclose($f01);
	$MyPDO = NULL;
} 

treatlist();

