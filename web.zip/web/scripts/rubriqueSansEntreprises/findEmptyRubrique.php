<?php
// error reporting
error_reporting(E_ALL);
ini_set("display_errors", 1);

// all rubrique id
function rubriqueidarray(){
	$sql = "SELECT id FROM rubrique";
	try{
		$MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}

	$stmt = $MyPDO->prepare($sql);
	$stmt->execute();
	$result = $stmt->fetchAll(\PDO::FETCH_NUM);
	$t = 0;
	$rubriqueidarray = [];
	if($result){
		foreach($result as $key=>$value){
			$rubriqueidarray[$t] = $value[0];
			$t++;
		}
	}

	return $rubriqueidarray;
}
//rubriqueidarray();
//echo "<pre>";
//var_dump(rubriqueidarray());
//echo "<pre>";

function emptyRubriqueId(){
	
	$rubriqueidarray = rubriqueidarray();
	try{
		$MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}
	$query = "SELECT rubriqueId FROM activite WHERE rubriqueId =:rubriqueId";
	$stmt = $MyPDO->prepare($query);
	
	$j = 0;
	$h = 0;
//	echo '<pre>';
	$emptyRubriqueId = [];
//	echo '</pre>';
//	var_dump($rubriqueidarray);
	foreach($rubriqueidarray as $key=>$value){
		$h++;
		$rubriquevalue = (int)$value; // Tres important
//		echo $rubriquevalue;
		$stmt->bindParam(":rubriqueId", $rubriquevalue);
		$stmt->execute();
		$result = $stmt->fetchAll(\PDO::FETCH_NUM);
		$count = $stmt->rowCount();
		if(!$count){
			$emptyRubriqueId[$j] = $rubriquevalue; 
			$j++;
		}
	}	

//	echo '<br>--'.$j.'<br>--'.$h;
//var_dump($rubriqueIdWithBusiness);

	return $emptyRubriqueId;
}

function treatlist(){ // preparation de l'affichage
	$query = "SELECT id, rubrique FROM rubrique WHERE id =:rubriqueId ";
	try{
		$MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}
	$stmt = $MyPDO->prepare($query);
	$i = 0;
	$emptyRubrique = [];
	$emptyRubriqueId = emptyRubriqueId();
	foreach($emptyRubriqueId as $key=>$value){
		$rubriqueId = (int)$value; // Tres important
		$stmt->bindParam(":rubriqueId", $rubriqueId);
		$stmt->execute();
		$result = $stmt->fetchAll(\PDO::FETCH_NUM);

		$count = $stmt->rowCount();
		foreach($result as $key=>$value){
			$emptyRubrique[$i]['id'] = $value[0];
			$emptyRubrique[$i]['rubrique'] = $value[1];
			$i++;
		}
	}
	echo '<pre>';
	var_dump($emptyRubrique);
	echo '</pre>';
	// Output file
	$f01 = fopen("emptyRubrique.txt", "w") or exit("Unable to open file!");
	fwrite($f01,"Rubrique sans entreprises:".$i."\r\n\r\n");
	foreach($emptyRubrique as $key=>$value){
		fwrite($f01, $value['id']." ".$value['rubrique']."\r\n");
	}
	fclose($f01);
} 

treatlist();
