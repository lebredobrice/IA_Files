<?php
// error reporting
error_reporting(E_ALL);
ini_set("display_errors", 1);

function treatlist(){
	$i = 0;
	$rueIdWithBusiness = [];
	$f01 = fopen("ruesId.txt", "r") or exit("Unable to open file!");
	
	while (!feof($f01)){
		$rueIdTabExploded = explode('"',fgets($f01)); // Make an array new line and space as delimiter
		$rueIdTab[$i] = $rueIdTabExploded[0];
		$i++;
	}
	fclose($f01);
	
	try{
		$MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}
	
	$query = "SELECT rueId FROM activite WHERE rueId=:rueid";
	$stmt = $MyPDO->prepare($query);
	$j = 0;
	$rueIdWithBusiness = [];
	foreach($rueIdTab as $key=>$value){
		$ruevalue = (int)$value; // Tres important
		$stmt->bindParam(":rueid", $ruevalue);
		$stmt->execute();
		$count = $stmt->rowCount();
		if($count>0){
            $rueIdWithBusiness[$j] = $value; 
			$j++;
		}
	}
	
	var_dump($rueIdWithBusiness);
	// Output file
	$f01 = fopen("filteredStreetId.txt", "w") or exit("Unable to open file!");
	foreach($rueIdWithBusiness as $key=>$value){
		fwrite($f01, $value."\n");
	}
	fclose($f01);
} 

treatlist();

$MyPDO = NULL;
