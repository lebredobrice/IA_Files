<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
/**
 *  connecte to database
 *	find the rubrique id
 *  iterate the file, line by line
 *  insert the translation
 **/

// create connexion object to database
class InsertTranslation
{
	public $MyPDO = "";
	public function connect(){
		try{
			$this->MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}

	// find the rubrique id with rubrique name
	public function getRubriqueId($rubriquenameFr){
		$rubriquenameFr = $this->MyPDO->quote($rubriquenameFr);
		$query = "SELECT id FROM rubrique WHERE rubrique = $rubriquenameFr";
		$stmt = $this->MyPDO->prepare($query);
		$stmt->execute();
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		$result = $stmt->fetchAll();
		$count = $stmt->rowCount();
		if($count){
			echo 'La rubrique '.$rubriquenameFr.' a pour id:'.$result[0]['id'];
		}
		else{
			echo 'La rubrique '.$rubriquenameFr.' n\'a pas �t� trouv�e <br>' ;
		}
		return($result[0]['id']);
	}

	// find the rubrique id with rubrique name
	public function insertion($rubriqueId, $rubriqueName, $totranslate){
		$query = "INSERT INTO translation (language_id, table_id, translation, translatedid) 
				  VALUES ('1', '1', '$rubriqueName', '$rubriqueId')";
		$stmt = $this->MyPDO->prepare($query);
		$stmt->execute();
		$count = $stmt->rowCount();

		if($count){
			echo "La rubrique $rubriqueName a �t� ajout�e.<br>";
		}
		else{
			echo "La rubrique $rubriqueName n'a pas �t� ajout�e <br>" ;
		}
	}
	
	// itterate in insert
    public function iterate(){
		$this->connect();
		$list = "anglais_francais.txt";
		$f01 = fopen($list, "r") or exit("Unable to open file!");
		while (!feof($f01)){
			$line = fgets($f01); // Make an array new line and space as delimiter

			$rubriqueTab = explode('*', $line); //
			//
			$rubriqueFr = trim($rubriqueTab[1]);
			$rubriqueEn = trim($rubriqueTab[0]);
			//
			$rubriqueId = $this->getRubriqueId($rubriqueFr);
			//
			if($rubriqueId){
				$this->insertion($rubriqueId, $rubriqueEn, $rubriqueFr);
			}
		}
	}
// 	$this->iterate();
}

$insertTrans = new InsertTranslation;
$insertTrans->iterate();
// $insertTrans->getRubriqueId('Abattoir');
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
Copyright 2018 - DoualaZoom.com
</body>
</html>


