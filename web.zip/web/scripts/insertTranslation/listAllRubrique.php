<?php
header('Content-Type: text/html; charset = utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);
/**
 *  connecte to database
 *	find the rubrique id
 *  iterate the file, line by line
 *  insert the translation
 **/

// create connexion object to database
class InsertTranslation
{
	public $MyPDO = "";
	public function connect(){
		try{
			$this->MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}

	// find the rubrique in translation table
	public function getRubriques(){
		$query = "SELECT *
				  FROM translation
				  WHERE language_id = 5
				  AND table_id = 1
				  ORDER BY translation ASC";
		$stmt = $this->MyPDO->prepare($query);
		$stmt->execute();
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		$result = $stmt->fetchAll();
		$count = $stmt->rowCount();
		echo "Total: ".$count;
		for($i = 0; $i < $count; $i++){
			echo $i.'--'.$result[$i]['translation']."<br>";
		}
	}
}

$insertTrans = new InsertTranslation;
$insertTrans->connect();
$insertTrans->getRubriques();
// $insertTrans->getRubriqueId('Abattoir');
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
Copyright 2018 - DoualaZoom.com
</body>
</html>


