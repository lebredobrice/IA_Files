<?php 

// tableau des numeros de telephone et fax
$numbersArrayObj = new numbers;
$numbersArray = $numbersArrayObj->getNumbers();

// traitement de numbersArray
$modification = new modification;
$modifiedNumbersArray = array();
foreach($numbersArray as $key=>&$value){ // update (formatage) des numeros l'array des numbers
	// traitement de telephone01
	if($modification->verification(trim($value['telephone01']))){
		$value['telephone01'] = $modification->formatel($value['telephone01']);
	}
	// traitement de telephone02
	if($modification->verification(trim($value['telephone02']))){
		$value['telephone02'] = $modification->formatel($value['telephone02']);
	}
	// traitement de fax
	if($modification->verification(trim($value['fax']))){
		$value['fax'] = $modification->formatel($value['fax']);
	}
}

// update the database
$update = new update;
$updated = $update->updatenumbers($numbersArray); // update
echo $update->message.'<br>'; // result message
// affichage des donn�es trait�s
foreach($updated as $key=>$value){ // update (formatage) des numeros l'array des numbers
	echo '<p>';
	echo 'entreprise id:'.$value['id'].' | ';
	echo 'telephone01:'.$value['telephone01'].' | ';
	echo 'telephone02:'.$value['telephone02'].' | ';
	echo 'fax:'.$value['fax'].' ';
	echo '</p>';
}