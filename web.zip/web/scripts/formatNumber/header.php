<?php
header('Content-Type: text/html; charset=UTF-8');

if(!isset($_SESSION)){
	session_start();
//	session_destroy();
}

// Few config
include('config.php');

echo "<p><span style='font-size:2em'>".SITENAME."</span></p>";
echo "<p style='font-style:italic'>Formatage des numeros de telephone du site courant</p>";
echo "<p>Les numeros de la forme 697****** sont formates en 697 ** ** **. <br><br></p>";


// correct password
$password = SITEPASS;               // password
if(isset($_POST['password']) && $_POST['password'] == $password){
	$_SESSION['typedpassword'] = $_POST['password'];                // le client est logu�
}

if(isset($_POST['password']) && $_POST['password'] != $password){
		echo "<p style='color:red'>Mot de passe incorrect<br></p>";
}
// Formulaire � afficher
if(isset($_SESSION['typedpassword']) ){
	// Bienvenue
	echo "<p style='color:green'>Bienvenue admin</p>";
	// warning
	echo utf8_encode("<b>Warning</b>: Ce script modifie la base de donn�e ".DBNAME."<br> Faire une sauvegarde avant son execution.");
	echo "<p>
			<form method='post'>
				<input type='hidden' name='commencer'><input type='submit' value='COMMENCER'>
			</form>
		  </P>";
}
else{
	echo "<p>veuillez vous identifier pour continuer</p>";
	echo "<p><form method='post'>
		     <input type='password' name='password' name='password'><input type='submit' value='ok'>
			 </form>
		  </p>";
}

// session_destroy();