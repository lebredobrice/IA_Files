<?php
/**
	Creation du tableau des numeros et fax
**/

class numbers
{
	// verifcation de la validit� du numero
	public function getNumbers(){
	    $sql =  'SELECT id, telephone01, telephone02, fax FROM activite LIMIT 5';
		$numbersArray = array();
		
		//connexion
		$connexion = new dbconnexion;
		$dbh = $connexion->connect(); // database object
		$i = 0;
    	foreach  ($dbh->query($sql) as $row) {
			$numbersArray[$i]['id'] = $row['id'];
			$numbersArray[$i]['telephone01'] = $row['telephone01'];
			$numbersArray[$i]['telephone02'] = $row['telephone02'];
			$numbersArray[$i]['fax'] = $row['fax'];
			$i++;
  		}
		$connexion = NULL;
		return $numbersArray;
	}
}