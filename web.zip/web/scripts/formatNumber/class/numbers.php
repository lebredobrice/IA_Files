<?php
/**
	Return all phone and fax numbers
**/

class numbers
{
	public $connexion;
	
	public function __construct(){
		// connexion
		$this->connexion = new Dbconnexion;
		$this->connexion->connect();
	}
	// get phone ans fax numbers
	public function getNumbers(){
		// db query
	    $sql =  'SELECT id, telephone01, telephone02, fax FROM activite';
		$stmt   = $this->connexion->MyPDO->prepare($sql);
		$stmt->execute();
		$result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
		
		$numbersArray = array();
		
		$i = 0;
    	foreach  ($result as $row) {
			$numbersArray[$i]['id'] = $row['id'];
			$numbersArray[$i]['telephone01'] = $row['telephone01'];
			$numbersArray[$i]['telephone02'] = $row['telephone02'];
			$numbersArray[$i]['fax'] = $row['fax'];
			$i++;
  		}
		$connexion = NULL;
		return $numbersArray;
	}
}