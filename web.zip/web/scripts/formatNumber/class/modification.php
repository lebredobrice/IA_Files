<?php
/**
	Formatage des numeros de telephone 698****** devient 698 *** ***
**/

class modification
{
	// verifcation de la validit� du numero
	public function verification($numero){
		if(is_numeric($numero) && count($numero)){
			return true;
		}
		else{
			return false;
		}
	}
	
	// formatage du numero numero
	public function formatel($numero){
		$formated_number = $numero[0].$numero[1].$numero[2].' '.$numero[3].$numero[4].' '.$numero[5].$numero[6].' '.$numero[7].$numero[8];
		return $formated_number;
	}
}