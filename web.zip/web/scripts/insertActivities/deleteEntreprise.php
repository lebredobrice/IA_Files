<?php
header('Content-Type: text/html; charset= iso 8859 1');
error_reporting(E_ALL);
ini_set('display_errors', 1);
/**
 *
 *  Ce script suprime les traductions de rubriques dans la table translation.
 *
 **/

// create connexion object to database
class deletetReperes
{
	public $MyPDO = "";

	public function connect(){
		try{
			$this->MyPDO = new PDO("mysql:host = sg211.servergrove.com; dbname=weynaakc_dzoom", 'weyna_dzoom', '!aA111111');
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}

	// delete all rubrique translation
	public function deleteRep(){
		$query = "DELETE FROM repere 
				  WHERE id  > '10000'";
		$stmt   = $this->MyPDO->prepare($query);
		$stmt->execute();
		$count  = $stmt->rowCount();
		if($count){
			echo "$count repere effac�es";
		}
		else{
			echo 'Erreur lors de la suppression <br>' ;
		}
	}
// 	$this->iterate();
}

$deletetReperes = new deletetReperes;
$deletetReperes->connect();
$deletetReperes->deleteRep();
// $insertTrans->getRubriqueId('Abattoir');
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
Copyright 2018 - DoualaZoom.com
</body>
</html>


