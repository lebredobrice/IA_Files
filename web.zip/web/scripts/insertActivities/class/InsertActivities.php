<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
/**
 *  This script insert new activities in database and returns inserted entreprise id, and write results
 *  connecte to database
 *  iterate the file, line by line
 *  get the repere repere of the line
 *  insert the repere and get his id
 *  insert the new entreprise
 *  save new enterprise and his id in a file
 **/

// create connexion object to database
require_once("Dbconnexion.php");

class insertActivities
{
	public $connexion;
	
	public function __construct(){
		// connexion
		$this->connexion = new dbconnexion;
		$this->connexion->connect();
	}
	// insert a new repere and return his id
	public function insertReperGetId($repere, $quartierId, $villeId, $description){
//      var_dump($repere);	
		$this->connexion->MyPDO->quote($repere);
		$query = "INSERT INTO repere (repere, quartierId, villeId, description) 
				  VALUES ('$repere', '$quartierId', '$villeId', '$description')";
		
		$this->connexion->MyPDO->exec("set names utf8");		  
		$stmt = $this->connexion->MyPDO->prepare($query);
		$stmt->execute();
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		$id = $this->connexion->MyPDO->lastInsertId();

		if(!$id){
			echo utf8_encode("<span style='color=red'>x Erreur</span>Le repere n'a pas �t� ajout�e <br>");
			$rep = false;
		}
		else{
			$rep = $id;
		}
		return $rep;
	}

	// get rubrique id
	public function getId($item, $table){
		// couleur du message (gravit�)
		$color = "";
		if($table == 'quartier' || $table == 'rubrique'){
			$erreur = "<span style='color: red'>x Erreur:</span>";
		}
		else{
			$erreur = "<span style='color: blue'>Note</span>";
		}
		// cas particulier
		if($table == "activite"){ 
			$field = "entreprise";
		}
		else{
			$field = $table;
		}
		// case of empty item
		if($table == 'quartier' || $table == 'rubrique'){
			if(!$item){
				echo "$erreur $field fournie est vide<br>";
				return NULL;
			}
		}
		// query
		$this->connexion->MyPDO->quote( $item );
		$query = "SELECT id 
				  FROM $table
				  WHERE $field =:item";
		$this->connexion->MyPDO->exec("set names utf8");		  
		$stmt = $this->connexion->MyPDO->prepare($query);
		$stmt->execute( [':item' => $item] );
		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		$id = $result['id'];

		if(!$id){
			echo "$erreur $item n' existe pas dans la table $table<br>"; 
			return NULL;
		}
		return $id;
	}
	

	// insert values
	public function insertActivityGetId($entreprise, $rubriqueId, $bp, $telephone01, $telephone02, $fax, $email, $web, $quartierId, $rueId, $date, $villeId){
		$this->connexion->MyPDO->quote($entreprise);
		$this->connexion->MyPDO->exec("set names utf8");
		$query = "INSERT INTO activite (entreprise, rubriqueId, bp, telephone01, telephone02, fax, email, web, quartierId, rueId, date, activated, villeId) 
				  VALUES (:entreprise, 
						  '$rubriqueId', 
						  '$bp', 
						  '$telephone01', 
						  '$telephone02', 
						  '$fax', 
						  '$email', 
						  '$web', 
						  '$quartierId', 
						  '$rueId', 
						  '$date',
						  'oui',
						  '$villeId')";
		$stmt = $this->connexion->MyPDO->prepare($query);
		$stmt->execute([':entreprise' => $entreprise]);
		$id = $this->connexion->MyPDO->lastInsertId();

		if(!$id){
			return false;
		}
		return $id;
	}
	
	// itterate and insert
    public function iterate($file){
		$i = 1;
		$directory  = $_SESSION['fileDir'];
		$outputfile = $_SESSION['outputfile'];
		$f01 = fopen("$directory/$file", "r") or exit("Unable to open file!"); // for read lines
		$f02 = fopen("$directory/$outputfile",  "w") or exit("Unable to open file!");// for write results
		$date       =  date("d/m/Y");
		fwrite($f02, utf8_encode("Entreprises ajout�es avec succes ($date)\r\n\r\n"));
		while (!feof($f01)){
			$line = fgets($f01); // Make an array new line and space as delimiter
			$lineTab = explode('*', $line); //
			if( isset( $lineTab[1] ) ){
				echo '<b>'.$i.'- '.$lineTab[0].'</b>:<br>';
				// insert new reper and get repere id
				// collect datas to flush
				$entreprise   =  trim($lineTab[0]);
				// deleting
/**				
 $this->deleteACompany($entreprise, 'activite'); 
 **/
				// is company already registered
				$exist = $this->isAlreadyExist($entreprise, 'activite');
				if( !$exist ){
					$rubriqueId   =  trim($lineTab[1]);
					$bp           =  trim($lineTab[2]); 
					$telephone01  =  trim($lineTab[3]);
					$telephone02  =  trim($lineTab[4]);
					$fax          =  trim($lineTab[5]);
					$email        =  trim($lineTab[6]);
					$web          =  trim($lineTab[7]);
					$quartier     =  trim($lineTab[8]);
					$rue          =  trim($lineTab[9]);
//					$repere = trim($lineTab[9]);
					$villeId      =  1;
				
					// get quartier id
					$quartierId = $this->getId($quartier, 'quartier');
					// get repere id
//					$repereId = $this->insertReperGetId($repere, $quartierId, $villeId, $repere);
					// get rue id
					$rueId = $this->getId($rue, 'rue');
					// get rubrique id
					// $rubriqueId = $this->getId('rubrique', $rubrique); 
					// Insert entreprise
					if( $rubriqueId && $quartierId ){
						// insert new enterprise and get id
						$entrepriseId = $this->insertActivityGetId($entreprise, $rubriqueId, $bp, $telephone01, $telephone02, $fax, $email, $web,  $quartierId, $rueId, $date, $villeId);
						// write result in a file
						if($entrepriseId){
							fwrite($f02, utf8_encode("$entreprise, Id: $entrepriseId,  quartier:$quartier:  succ�s\r\n"));
							echo utf8_encode("<span style='color: green'>SUCCES </span>L'entreprise $entreprise, Id: $entrepriseId, a bien �t� ajout�e <br>");
						}
						else{
							echo utf8_encode("<span style='color: red'>x Erreur: L'entreprise $entreprise</span>, quartier:$quartier,  n'a pas pu �tre inser� <br>") ;
						}
					}
				}

$i++;

			}
		}
	}
	// verify if this item is already in database
    public function isAlreadyExist($item, $table){
		if($table == "activite"){ // cas particulier
			$field = "entreprise";
		}
		else{
			$field = $table;
		}
		//
		$item = trim($item);
		$this->connexion->MyPDO->quote($item);
		$query = "SELECT count(*) AS total
				  FROM $table 
				  WHERE $field =:item";
		$this->connexion->MyPDO->exec("set names utf8");	  
		$stmt = $this->connexion->MyPDO->prepare($query);
		$stmt->execute( [':item' => $item] );
		// result
		$result = $stmt->fetch(PDO::FETCH_ASSOC);
//		$result = true;
		// no correspondance found
		if( $result['total'] == 0 ){
			return false;
		}
		// correspondance found
		if($table == "activite"){ 
			echo utf8_encode("<span style='color: blue'>Note</span> $item existe d�ja dans la basse de donn�e<br>");
		}
		return true;
	}

	// delete
	public function deleteACompany($item, $table){
		if($table == "activite"){ // cas particulier
			$field = "entreprise";
		}
		else{
			$field = $table;
		}
		$this->connexion->MyPDO->quote($item);
		$query = "DELETE FROM $table 
				  WHERE $field  =:item";
		$stmt   = $this->connexion->MyPDO->prepare($query);
		$stmt->execute( [':item' => $item] );
		$count = $stmt->rowCount();

		if($count){
			echo utf8_encode("<span style='color:green'>$item effac� de la table $table $count fois</span><br>");
		}
		else{
			echo utf8_encode("<span style='color:red'>0 suppression</span><br>") ;
		}
	}
}

// $insertTrans->getRubriqueId('Abattoir');
?>


