<?php
echo '<br>';
echo '&copy; August 2018 '.SITENAME;