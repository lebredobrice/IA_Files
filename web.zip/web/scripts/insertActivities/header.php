<?php
header('Content-Type: text/html; charset=UTF-8');

if(!isset($_SESSION)){
	session_start();
//	session_destroy();
}

// Few config
include('config.php');

echo "<p><span style='font-size:2em'>".SITENAME."</span></p>";
echo "<p style='font-style:italic'>Insert new companies</p>";
echo "<p>This script insert new companies from a file. <br><br></p>";

// correct password
$password = SITEPASS;               // password
if(isset($_POST['password']) && $_POST['password'] == $password){
	$_SESSION['typedpassword'] = $_POST['password'];                // le client est logu�
}

if(isset($_POST['password']) && $_POST['password'] != $password){
		echo "<p style='color:red'>Mot de passe incorrect<br></p>";
}
// Formulaire � afficher
if(isset($_SESSION['typedpassword']) ){
	echo "<p style='color:green'>Bienvenue admin  <a href='logout.php'>deconnexion</a></p>";
	echo "<p>At the end of the treatment, download a report <a href = '".$_SESSION['fileDir']."/".$_SESSION['outputfile']."' download = '".$_SESSION['fileDir']."/".$_SESSION['outputfile']."' target='_blank'>here</a></p>";
	echo "<p>
			<form method='post' enctype='multipart/form-data'>
				<div style='background-color:#F4F4F4; width:80%;'>
				<label>Importer un fichier .txt au format [entreprise	*	rubriqueId	*	 bp	*	 telephone01	*	telephone02	*	fax 	*	email	*	web	* quartier	*	rue]<br>
					<br><input type='file' name='companiesFile'  id='emailfile'>
				</label>
				</div>
				<input type='hidden' name='commencer'>
				<br><input type='submit' value='COMMENCER' style='height:40px; width:175px'>
			</form>
		 </p>";
}
else{
	echo "<p>veuillez vous identifier pour continuer</p>";
	echo "<p><form method='post'>
		     <input type='password' name='password' name='password'><input type='submit' value='ok'>
			 </form>
		  </p>";
}

// session_destroy();