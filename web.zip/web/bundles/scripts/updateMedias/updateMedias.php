<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>DoualaZoom.com - Update Medias</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
	<script src="jquery.ui.core.js"></script>
	<script src="jquery.ui.widget.js"></script>
	<script src="jquery.ui.position.js"></script>
	<script src="jquery.ui.menu.js"></script>
	<script src="jquery.ui.autocomplete.js"></script>
	<link rel="stylesheet" href="style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="jquery.ui.autocomplete.css" type="text/css" media="all" />
	<link rel="stylesheet" href="jquery.ui.all.css" type="text/css" media="all" />
	<link rel="stylesheet" href="jquery.ui.menu.css" type="text/css" media="all" />
</head>
<?php
session_start();
if(empty($_SESSION["authenticated"]) || $_SESSION["authenticated"] != 'true') {
    header('Location: index.php');
}

?>
<body>
*** DOUALAZOOM.com ***<br /><br />
Ce script utilise le logo, l'image et la vid&eacute;o d'une entreprise de reference pour changer logo, l'image et la vid&eacute;o de toutes les entreprises ayant pout mot cl&eacute; le mot cl&eacute; saisie.
<br /><br /><br /><br />
<?php 
error_reporting(E_ALL); 
ini_set('display_errors', 1)
?>

<?php
if(!($_SERVER['REQUEST_METHOD'] == 'POST')){
?>
	<form method="post">
 		<p><label>Entreprise de reference</label> 
		<input type="text" id="entreprise" name="entreprise"/></p>
 		<p><label>Mot cl&eacute; des entreprises &agrave; changer</label> 
		<input type="text" id="motcle" name="motcle" /></p>
		<p><label>Changer</label> 
		<input type="submit" value="Envoyer" name="envoyer" /></p>
	</form>
	
<!-- Autocompletion -->

	<style>
	.ui-autocomplete
	{
		max-height: 100px;
		max-width: 300px;
		font-size:10px;
		overflow-y: auto;
		/* prevent horizontal scrollbar */
		overflow-x: hidden;
    }
	
	.ui-autocomplete-loading
	{
		background: white url("search_anim.gif") right center no-repeat;
	}
	
    /* IE 6 doesn't support max-height
     * we use height instead, but this forces the menu to always be this tall
     */
    *html .ui-autocomplete
	{
		height: 100px;
		width:243px;
		text-transform:capitalize;
	}

	</style>
    <script type="text/javascript">
	/* recherche autocompletion */
	var jqs = $.noConflict();
	jQuery(document).ready(function(){
	var json_data = "activitesRead_json.php";
    jqs(function() {
  	jqs( "#entreprise" ).autocomplete({
	source: json_data
		});
	});
	});
	</script>
	<!-- Fin Autocompletion -->	

<?php
}
else{
?>
	<div class="responce01Container">
		<div class="responce01Colomn">
			Media de l'entreprise <?php echo $_POST['entreprise']; ?>
			<?php 
				$entrepriseTab = explode('-', $_POST['entreprise']);
				$id = trim($entrepriseTab[1]);
				$medias = medias($id); // fonction qui retourne les media
				$image = $medias['path01']; // image
				$video = $medias['path02']; // video
				$logo = $medias['path03']; // logo
				$entreprise = $medias['entreprise'];
				echo "<br><br>";
				echo "logo: $logo <br> <img src ='../../uploads/documents/".$logo."'><br>";
				echo "image: $image <br> <img src ='../../uploads/documents/".$image."'><br>";
				echo "video: $video<br>";
			?>
		</div>
		<div class="responce01Colomn">
			
			 <?php 
			 	$motcle = trim($_POST['motcle']);
				$refId = $id;
			 	$entreprises = entreprises($motcle, $refId);
// var_dump($entreprises); 
				$count = count($entreprises);
				$i = 0;
				echo $count." Entreprise(s) &agrave; updater <br><br>";
				?> <form novalidate>
					<?php foreach($entreprises as $key => $value){?>
					<input type="checkbox" id="<?php echo 'entreprise'.$i; ?>" name="<?php $value['entreprise'];?>" checked='checked' value="<?php echo $value['id'];?>">		
						<?php echo $value['entreprise']."<br>";
						$i++;
				}?>
				<br />
				<input type="button" value="Updater le(s) entreprise(s)" onclick="updateEntreprise(<?php echo $id.",'".$logo."','".$image."','".$video."'";?>)"/>
				</form>
		
		<div id="respnseAjax">&nbsp;</div>
		</div>
	</div>
<?php
}
?>

<?php
function connecton(){
	require('connexion.php');
	try{
		$MyPDO = new PDO('mysql:host = '.$dbhost.'; dbname='.$dbname.'', ''.$dbuser.'', ''.$dbpass.'');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}
	return $MyPDO;
}

function medias($id){
	$MyPDO = connecton();
	$query = "SELECT path01, path02, path03, entreprise FROM activite WHERE id = '$id'";
	$stmt = $MyPDO->query($query);
	$MyPDO->exec($query);
	$pathArray = $stmt->fetch();
	$MyPDO = NULL;
    return $pathArray;
}

function entreprises($motcle, $refId){ // refId � ne pas selectionner
	$MyPDO = connecton();
	$query = "SELECT entreprise, id FROM activite WHERE activite.entreprise like '%$motcle%' AND id!=$refId";
	$stmt = $MyPDO->query($query);
	$MyPDO->exec($query);
	$entreprises = $stmt->fetchAll();
	$MyPDO = NULL;
    return $entreprises;
}
?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<script>
// create a data chain with checked values
function getCheckboxValues(){
	//count checkboxes
	var inputTags = document.getElementsByTagName('input');
	var checkboxCount = 0;
	for (var i=0, length = inputTags.length; i<length; i++) {
     	if (inputTags[i].type == 'checkbox') {
         	checkboxCount++;
     	}
	}
	// create data chain for ajax
	var data ="";
	
	for (var i=0, length = checkboxCount; i<length; i++) {
		box = document.getElementById("entreprise"+i+"");
		if(box.checked == true){
			data = data+"&entreprise"+i+"="+box.value;
		}
	}
	data = data.substring(1); // on retire le caractere & du debut
	return data;
}
// update entreprises media
function updateEntreprise(refId, logo, image, video){
	var ajaxdata = getCheckboxValues();
	if(ajaxdata == ""){
		alert("aucune entreprise selectionn�e!");
	}
	else{
		ajaxdata = ajaxdata+"&refId="+refId+"&logo="+logo+"&video="+video+"&image="+image;
		var hrJavascriptSubmit = new XMLHttpRequest();
		hrJavascriptSubmit.open("POST", "updateEntreprise.php", true);
		hrJavascriptSubmit.setRequestHeader("Content-type", "application/x-www-form-urlencoded;charset=ISO-8859-15");
		hrJavascriptSubmit.onreadystatechange = function() 
		{
			var response = hrJavascriptSubmit.responseText;
			if(hrJavascriptSubmit.readyState == 4)
			{
				if(hrJavascriptSubmit.status == 200) 
				{   
					var response = hrJavascriptSubmit.responseText;
				     //alert(response);
					 document.getElementById('respnseAjax').innerHTML = response;
				}
			}
		}
		// alert(ajaxdata);
		hrJavascriptSubmit.send(ajaxdata);
	}
}
</script>

Copyright 2017 - DoualaZoom.com
</body>
</html>
