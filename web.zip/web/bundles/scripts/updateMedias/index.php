<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>DoualaZoom.com - UpdateRues script</title>
</head>

<body>
*** DOUALAZOOM.com ***<br /><br />
Ce script utilise le logo, l'image et la vid&eacute;o d'une entreprise de reference pour changer logo, l'image et la vid&eacute;o d'une entreprise &agrave; modifier.
<br /><br />
Saisissez votre mot de passe pour continuer<br><br>
<?php
$password = "adminpass";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if(!empty($_POST["password"])) {
        $pass = $_POST["password"];
        
        if($password == $pass) {
            session_start();
            $_SESSION["authenticated"] = 'true';
            header('Location: updateMedias.php');
        }
        else {
            header('Location: index.php');
        }
    } 
}
?>

<form id="login" method="post">
            <label for="password">Mot de passe</label>
            <input id="password" name="password" type="password" required>                    
            <br />
            <input type="submit" value="Login">
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
Copyright 2017 - DoualaZoom.com
</body>
</html>

