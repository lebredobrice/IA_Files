<?php
   include_once("connexion.php"); 
   $table = 'quartier';
?>