<?php
$totalvar = count($_POST);
$refId = $_POST['refId'];
$logo = $_POST['logo'];
$image = $_POST['image'];
$video = $_POST['video'];
// echo $image;

for($i=0; $i<$totalvar-3; $i++){
	if(isset($_POST['entreprise'.$i])){
		$entrepriseId = $_POST['entreprise'.$i];
		updateEntreprise($entrepriseId);
	}
}

function updateEntreprise($entrepriseId){
	// utilisation des variables definies hors de la fonction
	global $logo;
	global $image;
	global $video;
	global $refId;
	$message = "";
	require('connexion.php');
	try{
		$MyPDO = new PDO('mysql:host = '.$dbhost.'; dbname='.$dbname.'', ''.$dbuser.'', ''.$dbpass.'');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}
	$query = "UPDATE activite SET path01 = '$image', path02 = '$video', path03 = '$logo' WHERE id = '$entrepriseId'";
	$stmt = $MyPDO->prepare($query);
	$stmt->execute();
	$count = $stmt->rowCount();
	if($count){
		$message = $message.'Entreprise '.$entrepriseId.' mise � jour avec succes ---<br>';
	}
	else{
		$message = $message.'Entreprise '.$entrepriseId.' deja � jour ---<br>';
	}
	
	echo $message;
	
	$MyPDO = NULL;
}

