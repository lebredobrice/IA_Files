<?php
/**
	retourne le nom d'un element en fonction de son id dans la table activite
**/

class idtoname
{
	// id to name
	public function getName($elementId, $elementType){
	    if($elementType == 'activite'){ // cas particulier de la table activite qui a pour champ de nom 'entreprise'
			$sql =  "SELECT entreprise FROM $elementType WHERE id = '$elementId'";
		}
		else{
			$sql =  "SELECT $elementType FROM $elementType WHERE id = '$elementId'";
		}
		
		//connexion
		$connexion = new dbconnexion;
		$dbh = $connexion->connect(); // database object
		$name = "";
    	foreach  ($dbh->query($sql) as $row) {
			$name = $row[$elementType];
  		}
		$connexion = NULL;
		return $name;
	}
}

