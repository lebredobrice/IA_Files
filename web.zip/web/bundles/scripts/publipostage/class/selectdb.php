<?php
/**
 *	Update de la base de donn�e
 **/

class update
{
	public $message;
	// verifcation de la validit� du numero
	public function updatenumbers($numbersArray){
		$total = count($numbersArray);
		$connexion = new dbconnexion;
		$dbh = $connexion->connect(); // database object
		$i = 0; // controlleur
		$updated = array();
	    try{
			foreach($numbersArray as $key=>$value){ // walk thru  the formated numbers and update the database
				$id = $value['id'];
				$telephone01 =  $value['telephone01'];
				$telephone02 =  $value['telephone02'];
				$fax =  $value['fax'];
				$sql =  "UPDATE  activite
					 	SET telephone01 = '$telephone01', telephone02 = '$telephone02', fax = '$fax'
					 	WHERE id = $id";
				$dbh->query($sql);
				// array � retourner
				$updated[$id]['id'] = $id;
				$updated[$id]['telephone01'] = $telephone01;
				$updated[$id]['telephone02'] = $telephone02;
				$updated[$id]['fax'] = $fax;
				$i++; 
			}
			$this->message = "$i entreprises modifi�es sur $total";
		}
		catch(Exception $e){
			$this->message = "ERREUR! $i insertion(s) sur $total,".$e->getMessage();
		}
		return $updated;
	}
}