<?php 
// tableau des numeros de telephone et fax
$numbersArrayObj = new numbers;
$numbersArray = $numbersArrayObj->getNumbers();

// id to name
$test = new idtoname;
echo $test->getName(10, 'rubrique');
