<?php
/**
	Translate rubrique
	Return rubrique list to show in top menu
**/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

header('Content-type: text/html; charset=UTF-8');
error_reporting(E_ALL);
// current locale
$local = trim( $_POST["sitelocal"]);
$languageid = "";
if($local == "en"){
	$languageid = 1;
}
else if($local == "fr"){
	$languageid = 2;
}
else if($local == "cn"){
	$languageid = 3;
}
else if($local == "es"){
	$languageid = 4;
}
else if($local == "ar"){
	$languageid = 5;
}
// echo $languageid;
// $languageid = 1;

// var_dump($languageid);

// list of rubriques and their id
include_once("connexionTableRubrique.php");
$conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
mysqli_set_charset($conn,"utf8");
$query01 = "SELECT rubrique, id from $table ORDER BY rubrique ASC";
$result01 = mysqli_query($conn, $query01);
$j = 0; // output array index
$rubriques = array();
while($row01 = mysqli_fetch_array($result01, MYSQLI_ASSOC)){
	// output array id
    $id =  $row01["id"];
	
	// output array rubrique
	$rubrique = $row01["rubrique"];		
	// look if there is a translation for this $row01["rubrique"]
	// create output array
	// reorder output array and generate the output string
	$query02 = "SELECT translation FROM translation 
			    WHERE table_id = 1 
				AND language_id = $languageid  
				AND translatedid = $id LIMIT 1";
	$result02 = mysqli_query($conn, $query02);

	while($row02 = mysqli_fetch_array($result02, MYSQLI_ASSOC)){
		if($row02){
			$rubrique = $row02["translation"];
		}
		else{
			$rubrique = $row01["rubrique"];
		}
	}
	// rubrique deal wth encoding issue
	if( $languageid != 1 && $languageid != 2 ){ // not latin
		$rubriques[$j]["rubrique"] = $rubrique;
	}
	else{
		$rubriques[$j]["rubrique"] = $rubrique; 
	}
	// rubrique id
	$rubriques[$j]["rubriqueId"] = $id;
	$j = $j+1;
}

// reordering outpout string 
array_multisort($rubriques,SORT_ASC);

// output string
$out = "";
foreach($rubriques as $key=>$value){
	$out .= $value["rubriqueId"].'|'.strtoupper($value["rubrique"]).'||';
}

// echo "<pre>";
//	var_dump($rubriques);
// echo "</pre>";
 
// $rubriques .= $id.'|'.strtoupper($rubrique).'||';
// Close your database connection
mysqli_close($conn);
// Echo the results back to Ajax
// $villes = rtrim($villes, "|");
echo $out ;


