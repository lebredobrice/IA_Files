<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// siteurl
$siteurl = $_POST['siteurl'];

$service_key = $_POST['mackey'];
$return_url  = $siteurl.'/web/bundles/zoomdouala/ajax/monetbil/return.html';
$notify_url  = $siteurl.'/web/bundles/zoomdouala/ajax/monetbil/monetbil52845645ghjg875678frrd587.php';

$monetbil_args = array(
 'amount'       => $_POST['amount'],
 'phone'        => $_POST['customerPhone'],
 'locale'       => $_POST['lang'],
 'country'      => $_POST['country'],
 'currency'     => $_POST['currency'],
 'item_ref'     => $_POST['itemId'],
 'payment_ref'  => $_POST['transactionReference'],
 'user'         => $_POST['customerEmail'],
 'first_name'   => $_POST['customerName'],
 'last_name'    => $_POST['customerName'],
 'email'        => $_POST['customerEmail'],
 'return_url'   => $return_url,
 'notify_url'   => $notify_url,
 'logo' 		=> $siteurl.'/web/bundles/zoomdouala/images/logo_fr.gif' 
);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.monetbil.com/widget/v2.1/'.$service_key);
curl_setopt($ch, CURLOPT_HTTPGET, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($monetbil_args, '', '&'));
$response = curl_exec($ch);

$result = json_decode($response, true);
curl_close($ch);

// var_dump($result);
$status  = $result["success"];
//echo $status;
if($status === true){
	$transactionUrl = $result["payment_url"]; // our application item id
	echo $transactionUrl;
}
else{
	echo "Error: ".$result;
}
