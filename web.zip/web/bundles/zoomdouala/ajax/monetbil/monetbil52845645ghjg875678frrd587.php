<?php

header('Content-type: text/html; charset=ISO-8859-1');
ini_set("display_errors","1"); 
ERROR_REPORTING(E_ALL);

class Paiement_notification
{
	public $dbhost;
	public $dbname;
	public $dbuser;
	public $dbpass;
	public $dbport;
	public $MyPDO;
	public $secret;
	
	public function __construct(){
		require("../connexion.php");// required
		//Initiate PDO vars from included file
		$this->dbhost =  $dbhost;
		$this->dbname =  $dbname;
		$this->dbuser =  $dbuser;
		$this->dbpass =  $dbpass;
		$this->dbport =  $dbport;
		//
		$this->secret = "V7uAFJi05E9DeX6HAAOEwHZkJyqDlxsSFJKHclPdaicbgACJlqtQGXHtVpmOB0XZ"; // Your service secret
	}
   /**
	* connect pdo connect
	*/
	public function connect(){
		try{
			$this->MyPDO = new PDO("mysql:host=$this->dbhost;port=$this->dbport;dbname=$this->dbname", $this->dbuser, $this->dbpass);
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}
	
   /**
	* monetbil_sign
	*
	* @param string $service_secret
	* @param array $params
	* @return string
	*/
	public function monetbil_sign($service_secret, $params)
	{
		ksort($params);
		$signature = md5($service_secret . implode('', $params));
		return $signature;
	}

   /**
	* monetbil_check_sign
	*
	* @param string $service_secret
	* @param array $_POST
	* @return bool
	*/
	public function monetbil_check_sign($service_secret, $params){
		if(!array_key_exists('sign', $params)){
			return false;
		}
		$sign = $params['sign'];
		unset($params['sign']);

		$signature = monetbil_sign($service_secret, $params);
	  
		return ($sign == $signature);
	}

	/**
	* update_transaction_status
	*
	* @param array $params
	* @param int status
	* @return bool
	*/
	public function update_transaction_status($params, $status){
		$transaction_id = $params['payment_ref']; // paiement_id or paiement_ref

		$connexion = $this->connect();
		$query = "UPDATE curent_transaction 
				  SET status = '$status' 
				  WHERE transaction_id = '$transaction_id'";
		$pdo   = $this->MyPDO;
		$stmt  = $pdo->prepare($query);
		$stmt->execute();
		$count = $stmt->rowCount();
		return $count;
	}
}

$notification = new Paiement_notification;

// test
// $params['transaction_id'] = "test_transid";
// $result = $notification->update_transaction_status($params, 1);
// var_dump($result);

$service_secret = $notification->secret;
$params 		= $_POST;

//if(!$notification->monetbil_check_sign($service_secret, $params)){
//	 header("HTTP/1.0 404 Not Found");
//	 die("Error: Invalide signature");
//}
	
$status = $params['status'];	// status of transaction
$result = "";
if('success' == $status){
	$result = $notification->update_transaction_status($params, 1);  // set status to 1 in the database
}
else{
	$result = $notification->update_transaction_status($params, -1); // set status to -1 in the database
}
// echo $result;
exit($result);