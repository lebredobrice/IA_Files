<?php 
header('Content-type: text/plain; charset=UTF-8');

foreach($_POST as $key => $value) 
{
  if(ini_get('magic_quotes_gpc'))
  $_POST[$key] = stripslashes($_POST[$key]);
  $_POST[$key] = htmlspecialchars(strip_tags($_POST[$key]));
}

$visitoremail   = rawurlencode($_POST["email"]);
$dzoomemail     = rawurlencode("courrier@doualazoom.com"); // adresse smtp
$dzoomreceveur  = rawurlencode("info@doualazoom.com"); // adresse du destinataire du mail (admin)
$nom            = rawurlencode($_POST["nom"]);
$entreprise     = rawurlencode($_POST["entreprise"]);
$message        = rawurlencode($_POST["message"]);
$local          = rawurlencode($_POST["local"]);

// Envoie du mail en utilisant une route Symfony2 
$urlprefix = "http://".$_SERVER['SERVER_NAME']."/web/mail";
$url =  $urlprefix.'/'.$visitoremail.'/'.$dzoomemail.'/'.$dzoomreceveur.'/'.$message.'/'.$nom.'/'.$entreprise.'/'.$local;
// echo $url."<br>";
$content = file_get_contents($url);
if($content === Null)
{
	echo "Erreur d'envoie des donn�es";
}
else
{
	echo $content; // reponse du controller ShowController
}
