﻿<?php
/**
- First method: one translation. Take 3 arguments, the id of the table and id of the word to find in the table. Also the language to find id.
Returns the translated word if found or NULL.

- Second method: Take 2 arguments [(int)tableId], [(int)languageId] and return an array with translation found or the same source word if no translation.
**/

//errors
header('Content-type: text/html; charset=UTF-8');
ini_set("display_errors","1"); 
ERROR_REPORTING(E_ALL);

class Translate
{
	public $dbhost;
	public $dbname;
	public $dbuser;
	public $dbpass;
	public $dbport;
	public $MyPDO;
	
	public function __construct(){
		// required
		require("../connexion.php");
		//Initiate PDO vars from required file
		$this->dbhost =  $dbhost;
		$this->dbname =  $dbname;
		$this->dbuser =  $dbuser;
		$this->dbpass =  $dbpass;
		$this->dbport =  $dbport;
	}

	
	public function connect(){
		try{
			$this->MyPDO = new PDO("mysql:host=$this->dbhost;port=$this->dbport;dbname=$this->dbname;charset=UTF8", $this->dbuser, $this->dbpass);
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}
	// get id
	function getId($table, $term){
		if($table == "activite"){
			$query = "SELECT id FROM $table 
				      WHERE activated = 'oui' 
				      AND entreprise  = '$term'";
		}
		else if($table == "tablelist"){
			$query = "SELECT id FROM $table 
				      WHERE name = '$term'";
		}
		else{
			$query = "SELECT id FROM $table 
				      WHERE $table = '$term'";
		}
		$stm = $this->MyPDO->query($query);
		$stm->execute();
		$result = $stm->fetch(PDO::FETCH_ASSOC);
//		var_dump($result['id']);
		return $result['id']; // returns a row
	}
	// Return a string with the translated data
	public function getOneTranslation($tableid, $wordid, $languageid){
		// Get table name
		// $table = new Tablename;
		// $tablename = strtolower($table->getTablename($tableid));
		// get the translation
		$table = 'translation';
//		$connexion = new Dbconnexion;
		$sql = "SELECT translation FROM translation WHERE table_id=:tableid AND language_id=:languageid  AND translatedid =:wordid LIMIT 1";
		$this->MyPDO->exec("set names utf8");
		$stmt = $this->MyPDO->prepare($sql);
		$stmt->bindParam(':tableid', $tableid);
		$stmt->bindParam(':wordid', $wordid);
		$stmt->bindParam(':languageid', $languageid);
		$stmt->execute();
		//Fetch all of the values in form of a numeric array 
		$result = $stmt->fetchAll(\PDO::FETCH_NUM);
		if($result){
			foreach($result as $key=>$value){
				$translation = $value[0];
			}
		}
		else{
			$translation = NULL;
		}
		return $translation;
	}
}

$translate = new Translate;
$dbh = $translate->connect();

// posted datas
//$post_term_brut = "Art (accessoires et matériels) - antiquaires - galeries d'art - ouvrages d'art";
$post_term_brut   = $_POST['term'];
$cleanstr = str_replace("'", "\'", $post_term_brut);
$post_term = $cleanstr;
// $languageid = 3;
$languageid  = trim( $_POST["languageid"] ); // id in the table of languages
//$table = "rubrique";
$table       = trim( $_POST["table"] );      // table of the term to translate

$termid      = $translate->getId($table, $post_term);        // id of the table of the term
$tableid     = $translate->getId("tablelist", $table); 
$translation = $translate->getOneTranslation($tableid, $termid, $languageid);

if($translation){
	if( $languageid != 1 && $languageid != 2 ){ // not latin
		echo $translation.'*'.$termid;
	}
	else{
		echo html_entity_decode(htmlentities($translation, 0, 'UTF-8')); 
	}
} 
else{	
	echo trim($post_term_brut).'*'.$termid;
} 