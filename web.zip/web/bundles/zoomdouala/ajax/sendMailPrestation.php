<?php
header('Content-type: text/plain; charset=UTF-8');
$visitoremail  = rawurlencode($_POST["email"]);
$dzoomemail    = rawurlencode("courrier@doualazoom.com"); // adresse smtp
$dzoomreceveur = rawurlencode("registration@doualazoom.com"); // adresse du destinataire du mail (admin)
$nom           = rawurlencode($_POST["nom"]);
$entreprise    = rawurlencode ($_POST["entreprise"]);
$prestation    = rawurlencode($_POST["prestation"]);
$local         = $_POST["local"];

// Envoie des mails admin et visiteur en utilisant une route Symfony2


$urlprefix = "http://".$_SERVER['SERVER_NAME']."/web/mailprestation";
$url =  $urlprefix.'/'.$visitoremail.'/'.$dzoomemail.'/'.$dzoomreceveur.'/'.$nom.'/'.$entreprise.'/'.$prestation.'/'.$local;

$content = file_get_contents($url);

if($content === Null)
{
	echo "Erreur d'envoie des donn�es";
}
else
{
	 //echo $visitoremail;
	 echo $content; // reponse du controller ShowController
}