<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

error_reporting(E_ALL);
// current locale

function convertCurrency($amount, $from, $to){
	$data = file_get_contents("https://finance.google.com/bctzjpnsun/converter?a=$amount&from=$from&to=$to");
//	var_dump($data);
	preg_match("/<span class=bld>(.*)<\/span>/",$data, $converted);
	$converted = preg_replace("/[^0-9.]/", "", $converted[1]);
	return number_format(round($converted, 3),2);
}

echo convertCurrency($_POST('total'), $_POST('from'), $_POST('to'));

