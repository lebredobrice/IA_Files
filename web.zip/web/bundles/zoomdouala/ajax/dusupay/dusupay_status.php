<?php

///////////////////////// Paiement status ////////////////////////////////////////////////////
$dusupay_transactionId = $_POST[dusupay_transactionReference];
$dusupay_merchantId = $_POST[dusupay_merchantId];
// $dusupay_transactionId = "REF1527772233";
// $dusupay_merchantId = "2657";

//  $url = "http://sandbox.dusupay.com/transactions/check_status/".$dusupay_merchantId."/".$dusupay_transactionId.".json";
$url = "https://dusupay.com/transactions/check_status/".$dusupay_merchantId."/".$dusupay_transactionId.".json";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-type: application/json"));
curl_setopt($curl, CURLOPT_POST, true);


$json_response = curl_exec($curl);

$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

curl_close($curl);

$response = json_decode($json_response, true);
//var_dump($response);
$dusupay_transactionStatus = $response["Response"]["dusupay_transactionStatus"];
//echo $dusupay_transactionStatus;
$dusupay_status  = $response["Response"]["status"];

//echo "<pre>";
//	var_dump($dusupay_status);
//echo "</pre>";

echo $dusupay_transactionStatus;
