<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Creating dusupay_hash for the form data
// Hashing algorithm = sha1
// Copy your security mackey from your merchant page
$mackey 					  = $_POST['mackey'];
$dusupay_merchantId           = $_POST['dusupay_merchantId'];
//$dusupay_amount               = $_POST['dusupay_amount'];
$dusupay_amount               = 100;
$dusupay_currency             = $_POST['dusupay_currency'];
$dusupay_transactionReference = $_POST['dusupay_transactionReference'];
$dusupay_customerPhone        = $_POST['dusupay_customerPhone'];
$dusupay_transactionTimestamp = time();
//$dusupay_successURL         = $_POST['dusupay_successURL'];
$dusupay_itemId               = $_POST['dusupay_itemId'];
$dusupay_itemName             = $_POST['dusupay_itemName'];
$dusupay_customerName         = $_POST['dusupay_customerName'];
$dusupay_customerEmail        = $_POST['dusupay_customerEmail'];

// create signature
// Function to generate request signature
function getSignature($requestData, $merchantMackey){
    ksort($requestData);
    $stringData = '';
    foreach ($requestData as $key => $value) {
        if(in_array($key, ['signature'])) continue;
        $stringData .= $value;
    }
    return hash_hmac('sha1', $stringData, $merchantMackey);
}
// Create Data Array
$myJSON_array = [
    'merchant_id'            => $dusupay_merchantId,
    'amount'                 => $dusupay_amount,
    'account_number'         => $dusupay_customerPhone,
    'account_name'           => $dusupay_customerName,
    'timestamp'              => time(),
    'merchant_reference'     => $dusupay_transactionReference,
    'currency'   		 	 => $dusupay_currency,
    'item_id'   			 => $dusupay_itemId,
    'item_name'   			 => $dusupay_itemName,
    'account_email'   		 => $dusupay_customerEmail,
	'simulatePayBill'        => false
];
 // Generate Request Signature
$myJSON_array['signature'] = getSignature($myJSON_array, $mackey);

// $url = "http://sandbox.dusupay.com/merchant-api/collections/v2/mobile/requestPayment.json"; 
$url = "https://dusupay.com/merchant-api/collections/v2/mobile/requestPayment.json";    
$content = json_encode($myJSON_array);

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-type: application/json"));
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $content);

$json_response = curl_exec($curl);

$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

//if ( $status != 201 ) {
//    die("Error: call to URL $url failed with status $status, response $json_response, curl_error " . curl_error($curl) . //", curl_errno " . curl_errno($curl));
//}

curl_close($curl);



$response = json_decode($json_response, true);
// var_dump($response);
$status  = $response["response"]["status"];
//echo $status;
if($status === true){
	// $dusupay_transactionId = $response["response"]["data"]["transactionId"];
	$dusupay_transactionStatus = $response["response"]["transaction_status"]; // our application item id
	echo $dusupay_transactionStatus;
}
else{
	echo "Error: ".$response["response"]["message"];
}