<?php
   $dbhost = 'sg211.servergrove.com';
   $dbname = 'weynaakc_dzoom';
   $dbuser = 'weyna_dzoom';
   $dbpass = '!aA111111';
   $dbport = '';
?>