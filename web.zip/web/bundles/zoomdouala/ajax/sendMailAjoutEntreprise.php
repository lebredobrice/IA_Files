<?php
header('Content-type: text/plain; charset=ISO-8859-15');
$visitoremail = rawurlencode($_POST["email"]);
$dzoomemail = rawurlencode("courrier@doualazoom.com"); // adresse smtp // overrided by the symfony parametter config
$dzoomreceveur = rawurlencode("registration@doualazoom.com"); // adresse du destinataire du mail (admin)
$nom = rawurlencode($_POST["nom"]);
$entreprise = rawurlencode ($_POST["entreprise"]);
$datas = rawurlencode($_POST["form_datas"]);

$photo = rawurlencode($_POST["photo"]);
$video = rawurlencode($_POST["video"]);
$logo = rawurlencode($_POST["logo"]);

// on evite des vide dans le lien

if(!$photo)
{
	$photo = "no";
}
if(!$video)
{
	$video = "no";
}
if(!$logo)
{
	$logo = "no";
}

$type = rawurlencode($_POST["type"]); // type (ajout ou modification)

// Envoie du mail en utilisant une route Symfony2
$urlprefix = "http://".$_SERVER['SERVER_NAME']."/web/mailajout";

$url =  $urlprefix.'/'.$visitoremail.'/'.$dzoomemail.'/'.$dzoomreceveur.'/'.$nom.'/'.$entreprise.'/'.$datas.'/'.$type.'/'.$photo.'/'.$video.'/'.$logo;

$content = file_get_contents($url);

if($content === Null)
{
	echo "Erreur d'envoie des donn�es";
}
else
{
	// echo "Photo:$photo , video: $video , logo:$logo";
	echo $content; // reponse du controller ShowController
}