<?php 

/**
 * Remplacement des caracteres '&[...]' par leur valeur pour gerer le probleme de decodage de & avec Json_encode()
 **/
 
header('Content-type: text/html; charset=ISO-8859-1');

class AmpersandRemplace
{
	public $word;
	
	public $replaced;
	
	public function replacement($word)
	{
		$this->word = $word;
		if(strpos($word, '&amp;'))
		{
			$this->word = str_replace('&amp;', '&', $this->word);
		}
		if(strpos($word, '&eacute;'))
		{
			$this->word = str_replace('&eacute;', '�', $this->word);
		}
		if(strpos($word, '&egrave;'))
		{
			$this->word = str_replace('&egrave;', '�', $this->word);
		}
		if(strpos($word, '&ecirc;'))
		{
			$this->word = str_replace('&ecirc;', '�', $this->word);
		}
		if(strpos($word, '&Eacute;'))
		{
			$this->word = str_replace('&Eacute;', '�', $this->word);
		}
		if(strpos($word, '&Egrave;'))
		{
			$this->word = str_replace('&Egrave;', '�', $this->word);
		}
		if(strpos($word, '&Ecirc;'))
		{
			$this->word = str_replace('&Ecirc;', '�', $this->word);
		}
		if(strpos($word, '&acirc;'))
		{
			$this->word = str_replace('&acirc;', '�', $this->word);
		}
		if(strpos($word, '&ucirc;'))
		{
			$this->word = str_replace('&ucirc;', '�', $this->word);
		}
		if(strpos($word, '&#039;'))
		{
			$this->word = str_replace('&#039;', '\'', $this->word);
		}
		if(strpos($word, '&deg;'))
		{
			$this->word = str_replace('&deg;', '�', $this->word);
		}
		return $this->word;
	}
}
// $newReplacement = new AmpersandRemplace;
// $keyword = "Toto & Tata";
// echo $newReplacement->replacement($keyword);