<?php 

header('Content-type: text/plain; charset=ISO-8859-15'); 
 
// toutes les entreprises, pour la listbox dr recherche dans une rubrique
	include_once("connexionTableQuartier.php");
	
	$conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname"); 
    $query01 = "SELECT quartier, id from $table ORDER BY quartier ASC";
    $result = mysqli_query($conn, $query01);
	$i = 0;
	$quartiers = "";
	while($row01 = mysqli_fetch_array($result, MYSQLI_ASSOC))
    {
       if($row01)
	   {
		   $quartier =  ucfirst(strtolower($row01["quartier"]));
		   $id =  $row01["id"];
	       $quartiers .= $id.'|'.$quartier.'||';
	   }
    }

	// Close your database connection
    mysqli_close($conn);
	// Echo the results back to Ajax
	// $villes = rtrim($villes, "|");
    echo $quartiers ;
