<?php 
/**
 * Get a field value from a string containing company id
 **/	
header('Content-type: text/html; charset=ISO-8859-1');
//errors
ini_set("display_errors","1"); 
ERROR_REPORTING(E_ALL);

class isASectorCompany
{
	public $dbhost;
	public $dbname;
	public $dbuser;
	public $dbpass;
	public $dbport;
	public $MyPDO;
	
	public function __construct(){
		// required
		require("../connexion.php");
		//Initiate PDO vars from required file
		$this->dbhost =  $dbhost;
		$this->dbname =  $dbname;
		$this->dbuser =  $dbuser;
		$this->dbpass =  $dbpass;
		$this->dbport =  $dbport;
	}
	
	public function connect(){
		try{
			$this->MyPDO = new PDO("mysql:host=$this->dbhost;port=$this->dbport;dbname=$this->dbname", $this->dbuser, $this->dbpass);
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}
	// get term id in child the table
	public function getSectorId($table, $term){ // table = rubrique
		$query  = "SELECT id FROM $table 
				   WHERE $table = '$term'";
// echo $query;		   
		$sth = $this->MyPDO->prepare($query);
		$sth->execute();
		$result = $sth->fetch(PDO::FETCH_ASSOC);
		return $result['id'];
	}
	// is this id exist in the activity table
	public function isASectorCompany($table, $field, $fieldId, $term, $id){// table = activite, field = rubriqueId, 
		$query  = "SELECT * FROM $table 
				   WHERE $field   = '$fieldId'
				   AND id = '$id'";
			   
		$sth = $this->MyPDO->prepare($query);
		$sth->execute();
		$result = $sth->fetch(PDO::FETCH_ASSOC);
		$count = count($result["id"]);
//		echo $count;
		if($count){
			return true;
		}
		else{
			return false;
		}
		
	}
}


$isASectorCompany = new isASectorCompany;
$isASectorCompany->connect();
$table = "rubrique";
//rubrique=Commerce g�n�ral - Import - Export company=AK IMPORT id= 1779
//$term  = "Commerce g�n�ral - Import - Export";
 $term  = utf8_decode($_POST['rubrique']);
// get id of the term id on his child table
$childTableId = $isASectorCompany->getSectorId($table, $term);
// var_dump($childTableId);
// check if this id exist for the field of the table
$table = "activite";
$field = "rubriqueId"; // field name in the mother table (activite)
//$company = "AK IMPORT";
//$id = 1779;
$company  =  utf8_decode($_POST['company']);
$id =  $_POST['id'];

$isInSector  =  $isASectorCompany->isASectorCompany($table, $field, $childTableId, $company, $id);
// var_dump($isInSector);
// echo "childTableId ".$childTableId."<br>";
if($isInSector){
	echo 1;
}
else{ 
	echo 0;
}


