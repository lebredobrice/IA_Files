<?php 
/**
 * Get a field value from a string containing company id
 **/	
header('Content-type: text/html; charset=ISO-8859-1');
//errors
ini_set("display_errors","1"); 
ERROR_REPORTING(E_ALL);

class GetAData
{
	public $dbhost;
	public $dbname;
	public $dbuser;
	public $dbpass;
	public $dbport;
	public $MyPDO;
	
	public function __construct(){
		// required
		require("../connexion.php");
		//Initiate PDO vars from required file
		$this->dbhost =  $dbhost;
		$this->dbname =  $dbname;
		$this->dbuser =  $dbuser;
		$this->dbpass =  $dbpass;
		$this->dbport =  $dbport;
	}
	
	public function connect(){
		try{
			$this->MyPDO = new PDO("mysql:host=$this->dbhost;port=$this->dbport;dbname=$this->dbname", $this->dbuser, $this->dbpass);
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}
	// extract company id from string
	public function extractId($companyInfo){
		if($companyInfo){
			$tabString = explode('-', $companyInfo);
			if(count($tabString) < 2){
				return false;
			}
			$companyId = $tabString[count($tabString)-1]; // the last tab index must be company id
			return $companyId;
		}
		else{
			return false;
		}
	}
	// get a row from given table and id
	public function getRow($table, $id){
		//query
		if($table == "activite"){
			$query  = "SELECT * FROM $table 
				       WHERE activated = 'oui' 
				       AND id  = '$id'";
		}
		else{
			$query  = "SELECT * FROM $table 
				       WHERE id = '$id'";
		}

		$sth = $this->MyPDO->prepare($query);
		$sth->execute();
		$result = $sth->fetch(PDO::FETCH_ASSOC);
		return $result;
	}
	// get a specific field from a row
	public function getFieldInfo($row, $field){
		$fieldInfo = array();
		$i = 0;
		foreach($row as $key=>$value){
			if($key == $field){
				$fieldInfo[$i] = $value;
				$i++;
			}
		}
		return $fieldInfo;
	}
	// get a name from id and field
	public function getName($field, $id){
		if($field != "path01" &&  $field != "path02" && $field != "path03"){
			if($field == "entreprise"){
				$table = "company"; // cas particulier
			}
			else{
				$table = $field;
			}
		}
		else{
			$table = "activite";
		}
		//query
		$query  = "SELECT $field FROM $table 
				   WHERE id = '$id'";
		$stm = $this->MyPDO->query($query);
		$stm->execute();
		$result = $stm->fetch(PDO::FETCH_ASSOC);
		return $result; // returns a row
	}
}
$response = "";
$getAData = new GetAData;
// posted value
//$field = "path03";
//$companyInfo = "SODEPA, DEIDO - 10";
 $companyInfo = $_POST["companyInfo"];
 $field = $_POST["companyField"];// set the field 

if($field != "path01" &&  $field != "path02" && $field != "path03"){ // if is not a one to many relation field
	$fieldNameInRow = $field."Id"; // exemple: rubriqueId
	$type = "foreignKey";
}
else{
	$fieldNameInRow = $field;      // exemple: path03
	$type = "simple";
}
// extract company id
if($getAData->extractId($companyInfo)){
	$companyId = $getAData->extractId($companyInfo);
	// 
	$getAData->connect();
	$table = "activite";
	if($getAData->getRow($table, $companyId)){ // row of the company with that id
		// get company repository
		$companyRow = $getAData->getRow($table, $companyId);  // get array of properties for the company with that id
		// get field repository if foreign key
		if($getAData->getFieldInfo($companyRow, $fieldNameInRow)){
			$field_tab = $getAData->getFieldInfo($companyRow, $fieldNameInRow);
			$fieldNameInRow_value  = $field_tab[0];
			if( $type == "simple" ){
				$response = $fieldNameInRow_value;
			}
			else{
				// rubrique name of the company
				if($getAData->getName($field, $fieldNameInRow_value)){
					$fieldNameRow   = $getAData->getName($field, $fieldNameInRow_value); // get array for the rubrique with that id
					// rubrique value
					if($getAData->getFieldInfo($fieldNameRow, $field)){
						$fieldName_tab  = $getAData->getFieldInfo($fieldNameRow, $field);
						$field_value    = $fieldName_tab[0];
						$response = $field_value;
					}
					else{
						$response = false;
					}
				}
				else{
					$response = false;
				}
			}
		}
		else{
			$response = false;
		}
	}
	else{
		$response = false;
	}
}
else{
	$response = false;
}
// send back to ajax
echo $response;

//echo "<pre>";
//	var_dump($response);
//echo "<pre>";