<?php

// recup�ration de la chaine des entr�es � suprimer
$todeletestring = $_POST["todelete"];

// Suppr�ssion avec le controller URL du controlleur de Delete
//$server = $_SERVER['HTTP_HOST'];
//$url = "http://".$server."/doualazoom/web/app.php/zoom/activite/supprimer/".$todeletestring;
//$reponse = file_get_contents($url);

// suppression avec une connexion externe au framework
include_once("connexionTableActivite.php"); 
    // fabrication de l' Array des id � supprimer
$todeletearray = explode(",",$todeletestring);
$deteted = 0;
foreach ($todeletearray as $id)
{
    if($id != "")
	{
	    $query = "DELETE FROM $table WHERE  (id = '$id')";
	    $conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
        if (mysqli_query($conn, $query))  
	    {
            $deteted++;
			$reponse = $deteted." entreprise(s) suprim�es";
        } 
	    else
	    {
            $reponse."Erreur";
        }
    }
}

echo $reponse;


