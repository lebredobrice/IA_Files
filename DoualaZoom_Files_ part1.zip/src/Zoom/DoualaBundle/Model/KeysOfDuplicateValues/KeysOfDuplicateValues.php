<?php
/**
	Return an array of keys to delete from an array. 
	Those keys are picked randomly in an array of duplicated values, for every duplicated value.
	At the end we return an array of key to delete, to have an array without no duplicated value.
**/

namespace Zoom\DoualaBundle\Model\KeysOfDuplicateValues;
	
//header('Content-type: text/html; charset=ISO-8859-1');
//ini_set("display_errors","1"); 

//ERROR_REPORTING(E_ALL);

class KeysOfDuplicateValues
{
	// Return an array of 
	function getDuplicatedKey( $my_arr ){	
		$duplicatedIdArea = array();
		$length = count($my_arr);
		$j = 0;
		$i = 0;
		// array of this array's values with consecutive key
		$valuesArray = array();
		foreach( $my_arr as $value ){
			$valuesArray[$j] = $value;
			$j++;
		}
		// array of this array's keys with consecutive key
		$j = 0;
		$keyArray = array();
		foreach( $my_arr as $key=>$value ){
			$keyArray[$j] = $key;
			$j++;
		}
		// get key of duplicated values in an array
		foreach( $my_arr as $key01 => $value01 ){
			$xtime = 0;
			$match = array();
			$m = 0;
			for( $j = 0;  $j < $length; $j++ ){
				if( $value01 == $valuesArray[$j] ){
					$match[$value01][$m] = $keyArray[$j];
					$m++;
					$xtime++;
				}
			}
			$registered = false; 
			// test if this value is already registered  and register
			if( $xtime > 1 ){ // registration
				foreach( $duplicatedIdArea as $key02 => $value02 ){ // test if already registered
					if( array_key_exists( $value01, $value02 )){
						$registered = true;
					}
				}
				if( $registered != true){	
					array_push( $duplicatedIdArea, $match );
				}
			}
		}
// echo "<pre>";
// 	var_dump($duplicatedIdArea);
// echo "</pre>";
		// get an array of random ($total - 1) elements from every sub array
		$selectedAr = array();
		$n = 0;
		foreach( $duplicatedIdArea as $key => $value ){
			$arr = $value; // sub array to use
			foreach( $arr as $k => $v ){
				$totalNumberToPick = count( $v ) - 1;
				$chosenKey = array_rand( $v, $totalNumberToPick ); 
				if( !is_array( $chosenKey ) ){
					$selectedAr[$n] = $v[$chosenKey];
					$n++;
				}
				else{
					foreach( $chosenKey as $y => $e ){
						$selectedAr[$n] = $v[$e];
						$n++;
					}
				}
			}
		}
// echo "<pre>";
// 	var_dump($selectedAr);
// echo "</pre>";
		// get an array 
		return $selectedAr;
	}
}
// [0]=> int(328) [1]=> int(240) [2]=> int(344) [3]=> int(344) 
//$arrayofkeys = new KeysOfDuplicateValues;
//$my_array = [0=>328, 1=>240, 2=>344, 3=>344];
//$result = $arrayofkeys->getDuplicatedKey($my_array);
//echo "<pre>";
//	var_dump($result);
//echo "</pre>";