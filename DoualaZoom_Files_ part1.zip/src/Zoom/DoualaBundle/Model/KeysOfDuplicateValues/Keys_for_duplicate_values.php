<?php
/**
	Return an array of keys to delete from an array. 
	Those keys are picked randomly in an array of duplicated values, for every duplicated value.
	At the end we return an array of key to delete, to have an array without no duplicated value.
**/

namespace Zoom\DoualaBundle\Model\ArrayFunction;
	
header('Content-type: text/html; charset=ISO-8859-1');
ini_set("display_errors","1"); 

ERROR_REPORTING(E_ALL);

class Keys_for_duplicate_values
{
	// Return an array of 
	function getDuplicatedKey( $my_arr ){	
		$duplicatedIdArea = array();
		$length = count($my_arr);
		$j = 0;
		$i = 0;
		// array of this array's values with consecutive key
		$valuesArray = array();
		foreach( $my_arr as $value ){
			$valuesArray[$j] = $value;
			$j++;
		}
		// array of this array's keys with consecutive key
		$j = 0;
		$keyArray = array();
		foreach( $my_arr as $key=>$value ){
			$keyArray[$j] = $key;
			$j++;
		}
		// get key of duplicated values
		foreach( $my_arr as $key01 => $value01 ){
			$xtime = 0;
			$match = array();
			$m = 0;
			for( $j = 0;  $j < $length; $j++ ){
				if( $value01 == $valuesArray[$j] ){
					$xtime = $xtime + 1;
					$match[$value01][$m] = $keyArray[$j];
					$m++;
				}
			}
			$m = 0;
			$registered = false; // test array is already registered
			if($xtime > 1){ // registration
				foreach($duplicatedIdArea as $key02=>$value02){ // test if already registered
					if( array_key_exists($value01, $value02) ){
						$registered = true;
					}
				}
				if( $registered!= true){	
					array_push( $duplicatedIdArea, $match );
				}
			}
			$xtime = 0;
		}
		// get random ($total - 1) elements from every sub array
		$selectedAr = array();
		$n = 0;
		foreach($duplicatedIdArea as $key=>$value){
			$arr = $value; // sub array to use
			foreach($arr as $k=>$v){
				$totalNumberToPick = count($v) - 1;
				$selectedAr[$n] = array_rand($v, $totalNumberToPick); 
			}
			$n++;
		}
		// make it an unidimentional array of all values
		$selected = array();
		foreach($selectedAr as $val01){
			if(!is_array($val01)){
				array_push($selected, $val01);
			}
			else{
				foreach($val01 as $val02){
					array_push($selected, $val02);
				}
			}
		}
		// get an array 
		return $selected;
	}
}

// $arrayofkeys = new Keys_for_duplicate_values;
// $my_array = [10=>'a', 11=>'b', 12=>'c', 13=>'a', 14=>'b', 15=>'b'];
// $result = $arrayofkeys->getDuplicatedKey($my_array);
// echo "<pre>";
//	 var_dump($result);
// echo "</pre>";