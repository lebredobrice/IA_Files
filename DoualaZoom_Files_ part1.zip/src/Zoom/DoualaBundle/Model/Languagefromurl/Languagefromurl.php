<?php
/**
 Get url and retrieve language, then return it.
**/

namespace Zoom\DoualaBundle\Model\Languagefromurl;

header ('Content-type: text/html; charset=iso8859-15');

class Languagefromurl
{
	// Return curentlocal from url
	public function getLanguage(){
		// get URL
		$url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";// full url
		if(strpos($url,'/fr')){ // french is the current Local
			return 2; // 2 is the id of french in the language table
		}
		else if(strpos($url,'/en')){
			return 1; // 1 is the id of english in the language table
		}
		else if(strpos($url,'/cn')){ // chinese is the current Local
			return 3; // 3 is the id of chinese in the language table
		}
		else if(strpos($url,'/es')){
			return 4; // 4 is the id of spain in the language table
		}
		else if(strpos($url,'/ar')){ // arabic is the current Local
			return 5; // 5 is the id of french in the language table
		}
	}
}