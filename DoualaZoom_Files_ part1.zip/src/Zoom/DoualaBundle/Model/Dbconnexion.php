<?php

namespace Zoom\DoualaBundle\Model;

class Dbconnexion
{
	public function connect(){
		// parameters
		$dsn = 'mysql:dbname=abidjanzoom_doualazomdb;host=localhost';
		$user = 'abidjanzoom_dzoom';
		$password = 'YdQ=oESbhfI3'; 

		// connexion
    	try {
    		$dbh = new \PDO($dsn, $user, $password);
    		// echo 'Connexion reusie';
			return $dbh;
		} 
		catch (PDOException $e) {
    		echo 'Connexion �chou�e : ' . $e->getMessage();
		}
	}
}