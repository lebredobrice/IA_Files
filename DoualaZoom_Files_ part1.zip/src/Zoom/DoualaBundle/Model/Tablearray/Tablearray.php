<?php
/**
Take table id in argument and return an indexed array of data in main field
**/

namespace Zoom\DoualaBundle\Model\Tablearray;
use Zoom\DoualaBundle\Model\Dbconnexion;
use Zoom\DoualaBundle\Model\Tablename\Tablename;

class Tablearray
{
	// Return an array of data
	public function getTableArray($tableid){
		// Get table name
		$table = new Tablename;
		$tablename = strtolower($table->getTablename($tableid));
		// field name have the same name as table name
// echo $tablename;
		// build table array
		$connexion = new Dbconnexion;
		$dbh = $connexion->connect(); // database objec
		$sql = "SELECT id, $tablename FROM $tablename Limit 3";
		$stmt = $dbh->prepare($sql);
		$stmt->execute();
		//Fetch all of the values in form of a numeric array 
		$tableArrayBrut = $stmt->fetchAll(\PDO::FETCH_NUM);
		$tableArray = array();
		foreach($tableArrayBrut as $key=>$value){
			$tableArray[$value[0]] = $value[1];
		}
// echo "<pre>";
//			var_dump($tableArray);
// echo "<pre>";

		return $tableArray;
	}
}