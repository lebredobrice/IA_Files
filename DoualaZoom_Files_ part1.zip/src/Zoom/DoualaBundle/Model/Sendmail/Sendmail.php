<?php

namespace Zoom\DoualaBundle\Model\Sendmail;

class Sendmail
{
	public function __construct($templating, $mailer){ 
    	$this->templating = $templating;
    	$this->mailer = $mailer;
	}
	
	// 	Mail d'ajout / modification d'une entreprise à l'admin et au visiteur
	public function send($siteData, $visitoremail, $dzoomreceveur, $nom, $entreprise, $formDatas, $type, $photo, $video, $logo, $translator) 
    {
	     // Get site data values for email.txt.twig
		$sitetitle  = $siteData['title'];
		$siteurl    = $siteData['url'];
		$sitename   = $siteData['name'];
		
//		$translator = $this->get('translator');
 		$from_name  = $sitename;
		$from_email = "info@doualazoom.com";
		$from = array($from_email => $from_name);
		$to01 = $dzoomreceveur; // registration@doualazoom.com, configuré dans ajax/sendMailAjoutEntreprise.php
//		$to01 = "yaosoft@hotmail.com";
		$to02 = "courrier@abidjanzoom.com";
		$to = array($to01, $to02);
		// Ajout
		if($type === "ajout") {
			// message au administrateurs
			$message = \Swift_Message::newInstance() 
				->setSubject($nom.' a enregistré l\'entreprise '.$entreprise.'  sur '.$sitetitle)
				->setFrom($from)
				->setTo($to)
				->setBody($this->templating->render('ZoomDoualaBundle:Show:mailAjoutEntreprise.txt.twig', 
					array(
						'nom'   	   => $nom, 
						'message'      => $formDatas, 
						'entreprise'   => $entreprise, 
						'visitoremail' => $visitoremail,
						'siteurl'      => $siteurl,
						'sitetitle'    => $sitetitle,
						'sitename'     => $sitename,
					)
				) , 'text/html');
			// traitement des medias
			if($photo !='no'){
				$message->attach(\Swift_Attachment::fromPath(__DIR__.'/../../../../../web/uploads/documents/'.$photo));
			}
			if($video !='no'){
				$message->attach(\Swift_Attachment::fromPath(__DIR__.'/../../../../../web/uploads/documents/'.$video));
			}
			if($logo !='no'){
				$message->attach(\Swift_Attachment::fromPath(__DIR__.'/../../../../../web/uploads/documents/'.$logo));
			}
			$this->mailer->send($message);
			

			// message au visiteur
			$to = array($visitoremail);
			$message = \Swift_Message::newInstance() 
				->setSubject($translator->trans("Thank you for have add your company on ".$sitetitle))
				->setFrom($from)
				->setTo($to)
				->setBody($this->templating->render('ZoomDoualaBundle:Show:mailAjoutEntrepriseResponse.txt.twig', 	array
					(
						'nom'          => $nom, 
						'message'      => $formDatas, 
						'entreprise'   => $entreprise, 
						'visitoremail' => $visitoremail,
						'siteurl'      => $siteurl,
						'sitetitle'    => $sitetitle,
						'sitename'     => $sitename,
					)
				) , 'text/html'
			);
			$this->mailer->send($message);
		}
		
		// modification
		
		if ( $type === "modification" || $type === "modification_user" ){   
			// message aux administrateurs
            $title = ( $type === "modification" ) ? $nom.' demande la modification de l\'entreprise '.$entreprise.'  sur '.$sitetitle : $nom.' a modifé l\'entreprise '.$entreprise.'  sur '.$sitetitle;
			$message = \Swift_Message::newInstance()
				->setSubject( $title )
				->setFrom($from)
				->setTo($to)
				->setBody($this->templating->render('ZoomDoualaBundle:Show:mailModifEntreprise.txt.twig', 
					array(
					    'nom'          => $nom, 
					    'message'      => $formDatas, 
					    'entreprise'   => $entreprise, 
					    'visitoremail' => $visitoremail,
						'siteurl'      => $siteurl,
						'sitetitle'    => $sitetitle,
						'sitename'     => $sitename,
					)
				) , 'text/html'
			);
			// traitement des medias
			if($photo !='no'){
				$message->attach(\Swift_Attachment::fromPath(__DIR__.'/../../../../../web/uploads/documents/'.$photo));
			}
			if($video !='no'){
				$message->attach(\Swift_Attachment::fromPath(__DIR__.'/../../../../../web/uploads/documents/'.$video));
			}
			if($logo !='no'){
				$message->attach(\Swift_Attachment::fromPath(__DIR__.'/../../../../../web/uploads/documents/'.$logo));
			}
			$rep = $this->mailer->send($message);
			
			// message au visiteur
			$to = array($visitoremail);

			$message = \Swift_Message::newInstance() 
				->setSubject($translator->trans('Your request for modification on').' '.$sitetitle)
				->setFrom($from)
				->setTo($to)
				->setBody($this->templating->render('ZoomDoualaBundle:Show:mailModificationEntrepriseResponse.txt.twig', 
				array(
					'nom' 		   => $nom, 
					'message'      => $formDatas, 
					'entreprise'   => $entreprise, 
					'visitoremail' => $visitoremail,
					'siteurl'      => $siteurl,
					'sitetitle'    => $sitetitle,
					'sitename'     => $sitename,
				)
			) , 'text/html');
			$rep = $this->mailer->send($message);
			// echo $rep;
		}
	}
}
	
	
	
	
//		$from = array($from_email => $from_name);
//		$message = \Swift_Message::newInstance()
//        		->setSubject($textmail)
//       		->setFrom($from)
//         		->setTo($to)
//        		->setBody($this->templating->render('ZoomDoualaBundle:Email:groupmail.txt.twig', 
//	  				array('textmail'=>$textmail, )) , 'text/html');
//		try{
//	    	$send01 = $this->mailer->send($message, $errors); // envoie du mail des l'admin
//			return TRUE;
//		}
//		catch (\Swift_TransportException $STe)
//		{
//			//$string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
//			//echo "\n";
//			return FALSE;
//		}
//	}
//}