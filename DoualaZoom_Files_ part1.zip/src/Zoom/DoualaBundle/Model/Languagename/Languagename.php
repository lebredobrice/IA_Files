<?php
/**
Take language id and return language name
**/

namespace Zoom\DoualaBundle\Model\Languagename;
use Zoom\DoualaBundle\Model\Dbconnexion;

class Languagename
{
	// Return an array of data
	public function getLanguagename($languageid){
		$connexion = new Dbconnexion;
		$dbh = $connexion->connect(); // database objec
		$sql = "SELECT  name FROM languagelist
					 	WHERE id =:languageid";
		$stmt = $dbh->prepare($sql);
				
		$stmt->bindParam(':tableid', $tableid);
		
		$stmt->execute();
		
		$languageResultArray = $stmt->fetchAll();
//		var_dump($tableArray);		
		return $languageResultArray[0][0];
	}
}