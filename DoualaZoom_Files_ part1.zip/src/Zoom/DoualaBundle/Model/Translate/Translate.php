<?php
/**
- First method: one translation. Take 3 arguments, the id of the table, id of the word to find in the table and languageId. Also the language to find id.
Returns the translated word if found or NULL.

- Second method: Take 2 arguments [(int)tableId], [(int)languageId] and return an array with translation found or the same source word if no translation.
**/

namespace Zoom\DoualaBundle\Model\Translate;

header('Content-type: text/html; charset=UTF-8');

use Zoom\DoualaBundle\Model\Dbconnexion;
use Zoom\DoualaBundle\Model\Tablename\Tablename;


class Translate
{
	// Return a string with the transkated data
	public function getOneTranslation($tableid, $wordid, $languageid){
		// get the translation
		$table = 'translation';
		$connexion = new Dbconnexion;
		$dbh = $connexion->connect(); // database object
		$dbh->exec("set names utf8");
		$sql = "SELECT translation FROM translation 
								   WHERE table_id=:tableid 
								   AND language_id=:languageid  
								   AND translatedid =:wordid LIMIT 1";
		$stmt = $dbh->prepare($sql);
		$stmt->bindParam(':tableid', $tableid);
		$stmt->bindParam(':wordid', $wordid);
		$stmt->bindParam(':languageid', $languageid);
		$stmt->execute();

		//Fetch all of the values in form of a numeric array 
		$result = $stmt->fetchAll(\PDO::FETCH_NUM);
		if($result){
			foreach($result as $key=>$value){
				$translation = $value[0];
			}
		}
		else{
			$translation = NULL;
		}
// echo "<pre>";
//			var_dump($translation);
// echo "<pre>";
		return $translation;
	}

	// Return an array with the translated area
	public function getTableTranslation($tableid, $languageid){
		// Get table name

		$table = new Tablename;
		$tablename = strtolower($table->getTablename($tableid));
		// table field have the same name as the table
		$field = $tablename;
// echo $field;
		// get data to translate
		$sql = "SELECT id, $field FROM $tablename ORDER BY $field ASC";
		$connexion = new Dbconnexion;
		$dbh = $connexion->connect(); // database objec
		$stmt = $dbh->prepare($sql);
		$stmt->execute();
		// Fetch all of the values in form of a numeric array 
		$tableArrayBrut = $stmt->fetchAll(\PDO::FETCH_NUM);
//echo "<pre>";
//	var_dump($tableArrayBrut);
//echo "</pre>";
		// get array of translated data
		$tableArray = array();
//		$i = 0;
		foreach($tableArrayBrut as $key=>$value){
			if($this->getOneTranslation($tableid, $value[0], $languageid)){ // si la traduction existe on l'insere
				$translated =  $this->getOneTranslation($tableid, $value[0], $languageid);
				$tableArray[$value[0]] =  html_entity_decode(htmlentities($translated, 0, 'UTF-8'));
			}
			else{// si la traduction n'existe pas, on remet la même valeur
				$tableArray[$value[0]] = utf8_encode($value[1]); 
			}
		}
		asort($tableArray,SORT_ASC); // reindexing
//		 echo "<pre>";
//			var_dump($tableArray);
//		 echo "</pre>";
		
		return $tableArray;
	}
}