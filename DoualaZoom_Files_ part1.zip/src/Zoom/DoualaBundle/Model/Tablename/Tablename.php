<?php
/**
Take table id in and return table name
**/

namespace Zoom\DoualaBundle\Model\Tablename;
use Zoom\DoualaBundle\Model\Dbconnexion;

header ('Content-type: text/html; charset=iso8859-15');

class Tablename
{
	// Return an array of data
	public function getTablename($tableid){
		$connexion = new Dbconnexion;
		$dbh = $connexion->connect(); // database objec
		$sql = "SELECT  name FROM tablelist
					 	WHERE id =:tableid";
		$stmt = $dbh->prepare($sql);
				
		$stmt->bindParam(':tableid', $tableid);
		
		$stmt->execute();
		
		$tableArray = $stmt->fetchAll();
//		var_dump($tableArray);		
		return $tableArray[0][0];
	}
}