<?php
/**
 * Get the translated word id
 * Take 2 argument [(string)name], [(int)table_id] and return wordid or null.
**/

namespace Zoom\DoualaBundle\Model\Reversetranslate;
use Zoom\DoualaBundle\Model\Dbconnexion;
use Zoom\DoualaBundle\Model\Tablename\Tablename;

header ('Content-type: text/html; charset=iso8859-15');

class Reversetranslate
{
	// Return a string with the transkated data
	public function getReverseTranslation($word, $table_id){
		// Get table name
		// $table = new Tablename;
		// $tablename = strtolower($table->getTablename($tableid));
		// get the translation
		$table = 'translation';
		$connexion = new Dbconnexion;
		$dbh = $connexion->connect(); // database objec
		$sql = "SELECT translatedid FROM translation WHERE translation=:word AND table_id=:table_id LIMIT 1";
		$stmt = $dbh->prepare($sql);
		$stmt->bindParam(':word', $word);
		$stmt->bindParam(':table_id', $table_id);
		$stmt->execute();

		//Fetch all of the values in form of a numeric array 
		$result = $stmt->fetchAll(\PDO::FETCH_NUM);
		
		if($result){
			foreach($result as $key=>$value){
				$wordid = $value[0];
			}
		}
		else{
			$wordid = NULL;
		}
		
// var_dump($wordid);
// echo "<pre>";
//			var_dump($result);
// echo "<pre>";
		return $wordid;
	}
}