<?php
namespace Zoom\DoualaBundle\Entity; 
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Doctrine\Common\Collections\ArrayCollection;
 
/**
* @ORM\Entity 
* @ORM\Table(name="activite")
*/
class Activite
{ 
    
	public function __toString() 
    {
        return $this->entreprise;
    }
    /**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
     private $id;
     
    /**
     * @ORM\Column(type="string",length=255)
     * @Assert\NotBlank()
     */    
     private $entreprise;
	/**
     * @ORM\Column(type="string",length=255)
     * @Assert\NotBlank()
     */  
	   private $rubriqueId;
	/**
     * @ORM\Column(type="string",length=80,nullable=true)
     */    
      private $bp;
	/**
      * @ORM\Column(type="string",length=255,nullable=false)
      * @Assert\Regex(
      * pattern="/\d/",
      * match=true,
      * message="Seule les nombres sont permis svp"
      * )
      */ 
       private $telephone01;
	  /**
       * @ORM\Column(type="string",length=255,nullable=true)
       * @Assert\Regex(
       * pattern="/\d/",
       * match=true,
       * message="Seule les nombres sont permis svp"
       * )
       */    
        private $telephone02;
	/**
     * @ORM\Column(type="string",length=255,nullable=true)
     * @Assert\Regex(
     * pattern="/\d/",
     * match=true,
     * message="Seule les nombres sont permis svp"
     * )
     */   
	  private $fax; 
	/** 
     * @ORM\Column(type="string",length=255, nullable=true)
     * 
     */    
	  private $email;
	/** 
     * @ORM\Column(type="string",length=255,nullable=true)
     * 
     */    
     private $web;
	
	/**
     * @ORM\Column(type="string",length=255,nullable=true)
     */ 
	  private $villeId;
     /**
     * @ORM\Column(type="string",length=255, nullable=true)
     */ 
	  private $quartierId;
	/**
     * @ORM\Column(type="string",length=255,nullable=true)
     */ 
	  private $rueId;
	  
	/**
     * @ORM\Column(type="string",length=255,nullable=true)
     */
	private $repereId;
	/**
     * @ORM\Column(type="string",length=255,nullable=true)
     */
	  private $place;
	/**
     * @ORM\Column(type="string",length=500, nullable=true))
     */ 
    private $map;
	/**
     * @ORM\Column(type="string",length=255,nullable=true)
     */  
	  private $contact;
	/**
     * @ORM\Column(type="string",length=255,nullable=true)
     */  
	  private $fonctionId;
	
	/**
     * @ORM\Column(type="date",length=255)
     */  
	private $date;
	
	/** 
     * @ORM\Column(type="string",length=255, nullable=true)
     * 
     */    
	 private $repereId_primary_key;

	/** 
     * @ORM\Column(type="string",length=255, nullable=true)
     * 
     */    
	 private $rueId_primary_key;
	
    /**
     * @ORM\Column(type="string",length=10)
     * @Assert\NotBlank()
     */    
    private $activated;
	
    /**
     * @ORM\Column(type="string",length=255, nullable=true)
     * 
     */    
    private $adsizeId;

    /**
     * @ORM\Column(type="string",length=255, nullable=true)
     * 
	 * @Assert\File()
     */ 
    private $path01;

    /**
     * @ORM\Column(type="string",length=255, nullable=true)
	 *
     * @Assert\File()
     */ 
    private $path02;

    /**
     * @ORM\Column(type="string",length=255, nullable=true)
     * 
     * @Assert\File() 
     */ 
    private $path03;


   /**
    * @ORM\OneToMany(targetEntity="Zoom\DoualaBundle\Entity\CompanyRep", mappedBy="entrepriseId")
	*/
	private $activiteCompanyrep;

   /**
    * @ORM\OneToMany(targetEntity="Zoom\DoualaBundle\Entity\CompanyRegistration", mappedBy="entrepriseId")
	*/
	private $activiteCompanyregistration;

    /**
     * @ORM\ManyToMany(targetEntity="Zoom\DoualaBundle\Entity\Tag", inversedBy="activites", cascade={"persist"})
     */
    protected $tags;

    /**
     * @ORM\ManyToMany(targetEntity="Zoom\StoreBundle\Entity\Image", inversedBy="activites", cascade={"persist"})
     */
    protected $images;
    
    /**
     * Constructor
     */
    public function __construct()
    {	
        $this->activiteCompanyrep = new ArrayCollection();
        $this->activiteCompanyregistration = new ArrayCollection();
        $this->tags = new ArrayCollection();
        $this->images = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set entreprise
     *
     * @param string $entreprise
     * @return Activite
     */
    public function setEntreprise($entreprise)
    {
        $this->entreprise = $entreprise;
        return $this;
    }

    /**
     * Get entreprise
     *
     * @return string 
     */
    public function getEntreprise()
    {
        return $this->entreprise;
    }

    /**
     * Set rubriqueId
     *
     * @param string $rubriqueId
     * @return Activite
     */
    public function setRubriqueId($rubriqueId)
    {
        $this->rubriqueId = $rubriqueId;
    
        return $this;
    }

    /**
     * Get rubriqueId
     *
     * @return string 
     */
    public function getRubriqueId()
    {
        return $this->rubriqueId;
    }

    /**
     * Set bp
     *
     * @param string $bp
     * @return Activite
     */
    public function setBp($bp)
    {
        $this->bp = $bp;
    
        return $this;
    }

    /**
     * Get bp
     *
     * @return string 
     */
    public function getBp()
    {
        return $this->bp;
    }

    /**
     * Set telephone01
     *
     * @param string $telephone01
     * @return Activite
     */
    public function setTelephone01($telephone01)
    {
        $this->telephone01 = $telephone01;
    
        return $this;
    }

    /**
     * Get telephone01
     *
     * @return string 
     */
    public function getTelephone01()
    {
        return $this->telephone01;
    }

    /**
     * Set telephone02
     *
     * @param string $telephone02
     * @return Activite
     */
    public function setTelephone02($telephone02)
    {
        $this->telephone02 = $telephone02;
    
        return $this;
    }

    /**
     * Get telephone02
     *
     * @return string 
     */
    public function getTelephone02()
    {
        return $this->telephone02;
    }

    /**
     * Set fax
     *
     * @param string $fax
     * @return Activite
     */
    public function setFax($fax)
    {
        $this->fax = $fax;
    
        return $this;
    }

    /**
     * Get fax
     *
     * @return string 
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Activite
     */
    public function setEmail($email)
    {
        $this->email = $email;
    
        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set web
     *
     * @param string $web
     * @return Activite
     */
    public function setWeb($web)
    {
        $this->web = $web;
    
        return $this;
    }

    /**
     * Get web
     *
     * @return string 
     */
    public function getWeb()
    {
        return $this->web;
    }

    /**
     * Set villeId
     *
     * @param string $villeId
     * @return Activite
     */
    public function setVilleId($villeId)
    {
        $this->villeId = $villeId;
    
        return $this;
    }

    /**
     * Get villeId
     *
     * @return string 
     */
    public function getVilleId()
    {
        return $this->villeId;
    }

    /**
     * Set quartierId
     *
     * @param string $quartierId
     * @return Activite
     */
    public function setQuartierId($quartierId)
    {
        $this->quartierId = $quartierId;
    
        return $this;
    }

    /**
     * Get quartierId
     *
     * @return string 
     */
    public function getQuartierId()
    {
        return $this->quartierId;
    }

    /**
     * Set rueId
     *
     * @param string $rueId
     * @return Activite
     */
    public function setRueId($rueId)
    {
        $this->rueId = $rueId;
    
        return $this;
    }

    /**
     * Get rueId
     *
     * @return string 
     */
    public function getRueId()
    {
        return $this->rueId;
    }
	/**
     * Get adsizeId
     *
     * @return string 
     */
    public function getAdsizeId()
    {
        return $this->adsizeId;
    }
	
	/**
     * Set adsizeId
     *
     * @param string $adsizeId
     * @return Activite
     */
    public function setAdsizeId($adsizeId)
    {
        $this->adsizeId = $adsizeId;
    
        return $this;
    }
	/**
     * Set repereId
     *
     * @param string $repereId
     * @return Activite
     */
    public function setRepereId($repereId)
    {
        $this->repereId = $repereId;
    
        return $this;
    }
    
    /**
     * Get repereId
     *
     * @return string 
     */
    public function getRepereId()
    {
        return $this->repereId;
    }

    /**
     * Set contact
     *
     * @param string $contact
     * @return Activite
     */
    public function setContact($contact)
    {
        $this->contact = $contact;
    
        return $this;
    }

    /**
     * Get contact
     *
     * @return string 
     */
    public function getContact()
    {
        return $this->contact;
    }

    /**
     * Set fonctionId
     *
     * @param string $fonctionId
     * @return Activite
     */
    public function setFonctionId($fonctionId)
    {
        $this->fonctionId = $fonctionId;
    
        return $this;
    }

    /**
     * Get fonctionId
     *
     * @return string 
     */
    public function getFonctionId()
    {
        return $this->fonctionId;
    }
	/**
     * Set place
     *
     * @param string $place
     * @return Activite
     */
    public function setPlace($place)
    {
        $this->place = $place;
    
        return $this;
    }

    /**
     * Get place
     *
     * @return string 
     */
    public function getPlace()
    {
        return $this->place;
    }
	
    /**
     * Set map
     *
     * @param string $mapRue
     * @return Rue
     */
    public function setMap($map)
    {
        $this->map = $map;
    
        return $this;
    }

    /**
     * Get map
     *
     * @return string 
     */
    public function getMap()
    {
        return $this->map;
    }


    /**
     * Set date
     *
     * @param \DateTime $date
     * @return Activite
     */
    public function setDate($date)
    {
        $this->date = $date;
    
        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set rueId_primary_key
     *
     * @param string $rueIdPrimaryKey
     * @return Activite
     */
    public function setRueIdPrimaryKey($rueIdPrimaryKey)
    {
        $this->rueId_primary_key = $rueIdPrimaryKey;
    
        return $this;
    }

    /**
     * Get rueId_primary_key
     *
     * @return string 
     */
    public function getRueIdPrimaryKey()
    {
        return $this->rueId_primary_key;
    }
	
	/**
     * Set repereId_primary_key
     *
     * @param string $repereIdPrimaryKey
     * @return Activite
     */
    public function setRepereIdPrimaryKey($repereIdPrimaryKey)
    {
        $this->repereId_primary_key = $repereIdPrimaryKey;
    
        return $this;
    }

    /**
     * Get repereId_primary_key
     *
     * @return string 
     */
    public function getRepereIdPrimaryKey()
    {
        return $this->repereId_primary_key;
    }
	
	
    /**
     * Set activated
     *
     * @param string $activated
     * @return string
     */
    public function setActivated($activated)
    {
        $this->activated = $activated;

        return $this;
    }

    /**
     * Get activated
     *
     * @return string 
     */
    public function getActivated()
    {
        return $this->activated;
    }
	
   /**
    * Set path01
    *
    */
    public function setPath01($path01)
    {
        $this->path01 = $path01;

        return $this;
    }

   /**
    * Get path01
    *
    */
    public function getPath01()
    {
        return $this->path01;
    }

   /**
    * Set path02
    *
    */
    public function setPath02($path02)
    {
        $this->path02 = $path02;

        return $this;
    }

   /**
    * Get path02
    *
    */
    public function getPath02()
    {
        return $this->path02;
    }

   /**
    * Set path03
    *
    */
    public function setPath03($path03)
    {
        $this->path03 = $path03;

        return $this;
    }

    /**
     * Get path03
     *
     */
    public function getPath03()
    {
        return $this->path03;
    }


    /**
     * Add activiteCompanyrep
     *
     * @param Zoom\DoualaBundle\Entity\CompanyRep $activiteCompanyrep
     *
     * @return activiteCompanyrep
     */
    public function activiteCompanyrep($activiteCompanyrep)
    {
        $this->activiteCompanyrep = $activiteCompanyrep;

        return $this;
    }

    /**
     * Remove userCompanyrep
     *
     * @param Zoom\DoualaBundle\Entity\CompanyRep $activiteCompanyrep
     */
    public function removeActiviteCompanyrep($activiteCompanyrep)
    {
        $this->activiteCompanyrep->removeElement($activiteCompanyrep);
    }

    /**
     * Get activiteCompanyrep
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getActiviteCompanyrep()
    {
        return $this->userActiviteCompanyrep;
    }
	

    /**
     * Add activiteCompanyregistration
     *
     * @param Zoom\DoualaBundle\Entity\CompanyRep $activiteCompanyregistration
     *
     * @return activiteCompanyregistration
     */
    public function activiteCompanyregistration($activiteCompanyregistration)
    {
        $this->activiteCompanyregistration = $activiteCompanyregistration;

        return $this;
    }

    /**
     * Remove activiteCompanyregistration
     *
     * @param Zoom\DoualaBundle\Entity\Companyregistration $activiteCompanyregistration
     */
    public function removeActiviteCompanyregistration($activiteCompanyregistration)
    {
        $this->activiteCompanyregistration->removeElement($activiteCompanyregistration);
    }

    /**
     * Get activiteCompanyregistration
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getActiviteCompanyregistration()
    {
        return $this->userActiviteCompanyrgistration;
    }
	
    /**
     * Add tag
     *
     * @param \Zoom\DoualaBundle\Entity\Tag $tag
     *
     * @return Activite
     */
    public function addTag(\Zoom\DoualaBundle\Entity\Tag $tag)
    {
        $this->tags[] = $tag;
 
        return $this;
    }
 
    /**
     * Remove tag
     *
     * @param \Zoom\DoualaBundle\Entity\Tag $tag
     */
    public function removeTag(\Zoom\DoualaBundle\Entity\Tag $tag)
    {
        $this->tags->removeElement($tag);
    }
 
    /**
     * Get tags
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTags()
    {
        return $this->tags;
    }
    
    /**
     * Add image
     *
     * @param \Zoom\StoreBundle\Entity\Image $image
     *
     * @return Activite
     */
    public function addImage(\Zoom\StoreBundle\Entity\Image $image)
    {
        $this->images[] = $image;
 
        return $this;
    }
 
    /**
     * Remove image
     *
     * @param \Zoom\StoreBundle\Entity\Image $image
     */
    public function removeImage(\Zoom\StoreBundle\Entity\Image $image)
    {
        $this->images->removeElement($image);
    }
 
    /**
     * Get images
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getImages()
    {
        return $this->images;
    }
    
	// validations constraint/////////////////////////////////////////////////
	public static function loadValidatorMetadata(ClassMetadata $metadata)
    {
       // validation path (photo entreprise) ///////////////////////////////////////////
	    $metadata->addPropertyConstraint('path01',new Assert\Image(array(
             'minWidth' => 50,
             'maxWidth' => 1800,
             'minHeight' => 50,
             'maxHeight' => 1800,
             'maxSize' => 3024000, //moins de 3mo
			 'mimeTypes' => array(
             'image/jpg',
			 'image/jpeg',
			 'image/pjpeg',
             'image/gif',
             'image/png',
			 ),
            'mimeTypesMessage' => 'Votre photo n\'est pas valide (JPG, Gif, Png, min width: 100px, max width: 1500px, min height: 100px, max height: 1500px, max size: 3mo)',
        )));
		/// validation path03 (logo) ///////////////////////////////////////////
	    $metadata->addPropertyConstraint('path03',new Assert\Image(array(
             'minWidth' => 40,
             'maxWidth' => 1500,
             'minHeight' => 40,
             'maxHeight' => 1500,
             'maxSize' => 3024000, //moins de 3mo
			 'mimeTypes' => array(
             'image/gif',
             'image/png',
			 'image/jpg',
			 'image/jpeg',
			 'image/pjpeg',
			 'image/jpeg',
             'image/gif',
			 ),
            'mimeTypesMessage' => 'Votre loog n\est pas valide (JPG, Gif, JPG, PNG min width: 45px, max width: 1500px, min height: 43px, max height: 1500px, max size: 3mo)',
        )));
       /// validation constraint path02 (video) ///////////////////////////////////////////
		    $metadata->addPropertyConstraint('path02',new Assert\File(array(
             'maxSize' => 20024000, //moins de 10mo
			 'mimeTypes' => array(
             'audio/x-ms-wmv',
			 'video/x-flv',
			 'video/mp4',
			 'video/x-msvideo',
			 'video/x-ms-wmv',
			 ),
            'mimeTypesMessage' => 'Votre ficher n\est pas valide (Mp4, Flv, WMV de moins de 20 Mo)',
		)));
    }
///////////////////////////////////////////////////////////////////////////// end validation /// 

}
