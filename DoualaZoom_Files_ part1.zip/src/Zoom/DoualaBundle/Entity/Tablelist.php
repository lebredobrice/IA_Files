<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
/**
* @ORM\Entity
* @ORM\Table(name="tablelist")
*/
class Tablelist
{   	
    public function __toString() {
    	return $this->name;
    } 

	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
	
    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $name;
	
   /**
    * @ORM\Column(type="string",length=500)
    */ 
    private $description;

	/**
	 * @ORM\OneToMany(targetEntity="Translation", mappedBy="tableid"))
     */ 
    private $translationtable;


    public function __construct()
    {
        $this->translationtable = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * Set name
     *
     * @param string $name
     *
     * @return Tablelist
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Tablelist
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add translationtable
     *
     * @param \Zoom\DoualaBundle\Entity\Translation $translationtable
     *
     * @return Tablelist
     */
    public function addTranslationtable(\Zoom\DoualaBundle\Entity\Translation $translationtable)
    {
        $this->translationtable[] = $translationtable;

        return $this;
    }

    /**
     * Remove translationtable
     *
     * @param \Zoom\DoualaBundle\Entity\Translation $translationtable
     */
    public function removeTranslationtable(\Zoom\DoualaBundle\Entity\Translation $translationtable)
    {
        $this->translationtable->removeElement($translationtable);
    }

    /**
     * Get translationtable
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTranslationtable()
    {
        return $this->translationtable;
    }
}
