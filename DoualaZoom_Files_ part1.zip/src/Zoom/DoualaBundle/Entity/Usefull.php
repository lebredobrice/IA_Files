<?php 
namespace Zoom\DoualaBundle\Entity; 

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="usefull")
 */
class Usefull
{
	public function __toString()
	{
    	return (string)($this->getId());
	}
   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    protected $id;
	
   /**
    * @var string
    *
    * @ORM\Column(name="usefull", type="string", length=250)
    */
	protected $usefull;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $telephone01;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $telephone02;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $telephone03;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $fax;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $email;


   /**
 	* @ORM\Column(type="string")
 	*/
    protected $web;

   /**
 	* @ORM\Column(type="string")
    */
	protected $lieu;

   /**
 	* @ORM\Column(type="string")
    */
	protected $detail;

    /**
     * @ORM\ManyToOne(targetEntity="Usefulltype", inversedBy="usefulltypeInversed")
     * @ORM\JoinColumn(name="usefullype_id", referencedColumnName="id")
     */
	protected $usefulltypeUsefull;

///////////// GETTER / SETTER ///////////////////
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set usefull
     *
     * @param string $usefull
     *
     * @return Usefull
     */
    public function setUsefull($usefull)
    {
        $this->usefull = $usefull;

        return $this;
    }

    /**
     * Get usefull
     *
     * @return string
     */
    public function getUsefull()
    {
        return $this->usefull;
    }

    /**
     * Set telephone01
     *
     * @param string $telephone01
     *
     * @return Usefull
     */
    public function setTelephone01($telephone01)
    {
        $this->telephone01 = $telephone01;

        return $this;
    }

    /**
     * Get telephone01
     *
     * @return string
     */
    public function getTelephone01()
    {
        return $this->telephone01;
    }

    /**
     * Set telephone02
     *
     * @param string $telephone02
     *
     * @return Usefull
     */
    public function setTelephone02($telephone02)
    {
        $this->telephone02 = $telephone02;

        return $this;
    }

	
    /**
     * Get telephone02
     *
     * @return string
     */
    public function getTelephone02()
    {
        return $this->telephone02;
    }

	/**
     * Set telephone03
     *
     * @param string $telephone03
     *
     * @return Usefull
     */
    public function setTelephone03($telephone03)
    {
        $this->telephone03 = $telephone03;

        return $this;
    }

    /**
     * Get telephone03
     *
     * @return string
     */
    public function getTelephone03()
    {
        return $this->telephone03;
    }

	/**
     * Set email
     *
     * @param string $email
     *
     * @return Usefull
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

	/**
     * Set fax
     *
     * @param string $fax
     *
     * @return Usefull
     */
    public function setFax($fax)
    {
        $this->fax = $fax;

        return $this;
    }

    /**
     * Get fax
     *
     * @return string
     */
    public function getFax()
    {
        return $this->fax;
    }

	/**
     * Set web
     *
     * @param string $web
     *
     * @return Usefull
     */
    public function setWeb($web)
    {
        $this->web = $web;

        return $this;
    }

    /**
     * Get web
     *
     * @return string
     */
    public function getWeb()
    {
        return $this->web;
    }

	/**
     * Set lieu
     *
     * @param string $lieu
     *
     * @return Usefull
     */
    public function setLieu($lieu)
    {
        $this->lieu = $lieu;

        return $this;
    }

    /**
     * Get lieu
     *
     * @return string
     */
    public function getLieu()
    {
        return $this->lieu;
	}

	/**
     * Set detail
     *
     * @param string $detail
     *
     * @return Usefull
     */
    public function setDetail($detail)
    {
        $this->detail = $detail;

        return $this;
    }

    /**
     * Get detail
     *
     * @return string
     */
    public function getDetail()
    {
        return $this->detail;
	}

	/**
     * Set usefulltypeUsefull
     *
     * @param \DoualaBundle\Entity\Usefulltype $usefulltypeUsefull
     *
     * @return usefulltypeUsefull
     */
    public function setUsefulltypeUsefull( $usefulltypeUsefull = null )
    {
        $this->usefulltypeUsefull = $usefulltypeUsefull;

        return $this;
    }

    /**
     * Get usefulltypeUsefull
     *
     * @return \DoualaBundle\Entity\Usefulltype
     */
    public function getUsefulltypeUsefull()
    {
        return $this->usefulltypeUsefull;
    }

}
