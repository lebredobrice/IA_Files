<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
/**
* @ORM\Entity
* @ORM\Table(name="language")
*/
class Language
{   	
    public function __toString() {
    	return (string)$this->language;
    } 

	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
	
    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $language;
	
	/**
	 * @ORM\OneToMany(targetEntity="Translation", mappedBy="languageid"))
     */ 
    private $translationlanguage;
	
	

    public function __construct()
    {
        $this->translationlanguage = new ArrayCollection();
    }
	
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * Set language
     *
     * @param string $language
     *
     * @return Language
     */
    public function setLanguage($language)
    {
        $this->language = $language;

        return $this;
    }

    /**
     * Get language
     *
     * @return string
     */
    public function getLanguage()
    {
        return $this->language;
    }

    /**
     * Add translationlanguage
     *
     * @param \Zoom\DoualaBundle\Entity\Translation $translationlanguage
     *
     * @return Language
     */
    public function addTranslationlanguage(\Zoom\DoualaBundle\Entity\Translation $translationlanguage)
    {
        $this->translationlanguage[] = $translationlanguage;

        return $this;
    }

    /**
     * Remove translationlanguage
     *
     * @param \Zoom\DoualaBundle\Entity\Translation $translationlanguage
     */
    public function removeTranslationlanguage(\Zoom\DoualaBundle\Entity\Translation $translationlanguage)
    {
        $this->translationlanguage->removeElement($translationlanguage);
    }

    /**
     * Get translationlanguage
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTranslationlanguage()
    {
        return $this->translationlanguage;
    }
}
