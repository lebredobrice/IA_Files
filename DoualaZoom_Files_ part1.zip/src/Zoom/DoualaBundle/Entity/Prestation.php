<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
/**
* @ORM\Entity
* @ORM\Table(name="prestation")
*/
class Prestation
{   	
    public function __toString() {
    return $this->prestation;
    } 

	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $prestation;

    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $prix;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set prestation
     *
     * @param string $prestation
     * @return Prestation
     */
    public function setPrestation($prestation)
    {
        $this->prestation = $prestation;
    
        return $this;
    }

    /**
     * Get prestation
     *
     * @return string 
     */
    public function getPrestation()
    {
        return $this->prestation;
    }

    /**
     * Set prix
     *
     * @param string $prix
     * @return prix
     */
    public function setPrix($prix)
    {
        $this->prix = $prix;
    
        return $this;
    }
}
