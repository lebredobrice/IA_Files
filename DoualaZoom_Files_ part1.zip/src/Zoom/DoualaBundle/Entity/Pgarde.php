<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;

/**
* @ORM\Entity
* @ORM\Table(name="pgarde")
*/
class Pgarde 
{   	
    public function __toString() {
    return $this->pgardeid;
    } 

	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
	
    /**
     * @ORM\Column(type="integer")
     */    
    private $pgardeid;
	
	/**
     * @ORM\Column(type="date")
     */ 
    private $datedebut;
	
	
	/**
     * @ORM\Column(type="date")
     */ 
    private $datefin;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set pgardeid
     *
     * @param string $pgardeid
     * @return Pgardeid
     */
    public function setPgardeid($pgardeid)
    {
        $this->pgardeid = $pgardeid;
    
        return $this;
    }

    /**
     * Get pgardeid
     *
     * @return string 
     */
    public function getPgardeid()
    {
        return $this->pgardeid;
    }

    /**
     * Set datedebut
     *
     * @param date $datedebut
     * @return Pgardeid
     */
    public function setDatedebut($datedebut)
    {
        $this->datedebut = $datedebut;
    
        return $this;
    }

    /**
     * Get datedebut
     *
     * @return date 
     */
    public function getDatedebut()
    {
        return $this->datedebut;
    }
	
    /**
     * Set datefin
     *
     * @param string $datefin
     * @return Datefin
     */
    public function setDatefin($datefin)
    {
        $this->datefin = $datefin;
    
        return $this;
    }

    /**
     * Get datefin
     *
     * @return date 
     */
    public function getDatefin()
    {
        return $this->datefin;
    }

}
