<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
/**
* @ORM\Entity
* @ORM\Table(name="adsize")
*/
class Adsize
{   	
    public function __toString() {
    return $this->adsize;
    } 

	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
	
    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $adsize;
	
   /**
    * @ORM\Column(type="string",length=500)
    */ 
    private $description;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set adsize
     *
     * @param string $adsize
     * @return Adsize
     */
    public function setAdsize($adsize)
    {
        $this->adsize = $adsize;
    
        return $this;
    }

    /**
     * Get adsize
     *
     * @return string 
     */
    public function getAdsize()
    {
        return $this->adsize;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Adsize
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

}
