<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
/**
* @ORM\Entity
* @ORM\Table(name="translation")
*/
class Translation
{   	
    public function __toString() {
    	return $this->translation;
    } 

	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
	
    /**
     * @ORM\Column(type="string",length=1024)
     */    
    private $translation;
	
    /**
     * @ORM\Column(type="integer", length=11)
     */    
    private $translatedid;
	
	/**
	 * @ORM\ManyToOne(targetEntity = "Language", inversedBy="translationlanguage")
     * @ORM\JoinColumn(name="language_id", referencedColumnName="id")
     */ 
    private $languageid;
	
	/**
	 * @ORM\ManyToOne(targetEntity = "Tablelist", inversedBy="translationtable")
     * @ORM\JoinColumn(name="table_id", referencedColumnName="id")
     */ 
    private $tableid;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * Set translation
     *
     * @param string $translation
     *
     * @return Translation
     */
    public function setTranslation($translation)
    {
        $this->translation = $translation;

        return $this;
    }

    /**
     * Get translation
     *
     * @return string
     */
    public function getTranslation()
    {
        return $this->translation;
    }

    /**
     * Set translatedid
     *
     * @param integer $translatedid
     *
     * @return Translation
     */
    public function setTranslatedid($translatedid)
    {
        $this->translatedid = $translatedid;

        return $this;
    }

    /**
     * Get translatedid
     *
     * @return integer
     */
    public function getTranslatedid()
    {
        return $this->translatedid;
    }

    /**
     * Set languageid
     *
     * @param \Zoom\DoualaBundle\Entity\Language $languageid
     *
     * @return Translation
     */
    public function setLanguageid(\Zoom\DoualaBundle\Entity\Language $languageid = null)
    {
        $this->languageid = $languageid;

        return $this;
    }

    /**
     * Get languageid
     *
     * @return \Zoom\DoualaBundle\Entity\Language
     */
    public function getLanguageid()
    {
        return $this->languageid;
    }

    /**
     * Set tableid
     *
     * @param \Zoom\DoualaBundle\Entity\Tablelist $tableid
     *
     * @return Translation
     */
    public function setTableid(\Zoom\DoualaBundle\Entity\Tablelist $tableid = null)
    {
        $this->tableid = $tableid;

        return $this;
    }

    /**
     * Get tableid
     *
     * @return \Zoom\DoualaBundle\Entity\Tablelist
     */
    public function getTableid()
    {
        return $this->tableid;
    }
}
