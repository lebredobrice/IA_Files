<?php
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Doctrine\Common\Collections\ArrayCollection;

use Zoom\DoualaBundle\Model\Translate\Translate;
use Zoom\DoualaBundle\Model\Languagefromurl\Languagefromurl;
/**
* @ORM\Entity
* @ORM\Table(name="rubrique")
*/
class Rubrique
{
	public function __toString() {
		return $this->rubrique;
    }
   /**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
    
    /**
     * @ORM\Column(type="string",length=500)
     * @Assert\NotBlank()
     */    
    private $rubrique;
 
	/**
     * @ORM\Column(type="string",length=500)
     * @Assert\NotBlank()
     */    
    private $description;

   /**
    * @ORM\OneToMany(targetEntity="Zoom\DoualaBundle\Entity\CompanyRep", mappedBy="rubriqueId")
	*/
	private $companyrepRubrique;

   /**
    * @ORM\OneToMany(targetEntity="Zoom\DoualaBundle\Entity\CompanyRegistration", mappedBy="rubriqueId")
	*/
	private $companyregistrationRubrique;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->companyrepRubrique = new ArrayCollection();
		$this->companyregistrationRubrique = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set rubrique
     *
     * @param string $rubrique
     * @return rubrique
     */
    public function setRubrique($rubrique)
    {
        $this->rubrique = $rubrique;

        return $this;
    }

    /**
     * Get rubrique
     *
     * @return string 
     */
    public function getRubrique()
    {
//        $language = new Languagefromurl;
//		$translate = new Translate;
//		$rubriqueId = $this->getId();
//		$translated = $translate->getOnetranslation(1, $rubriqueId, $language->getLanguage()); // 1 is the id of the table Rubrique in tables table
//		if($translated){
//			return $translated;
//		}
//		else{
			return $this->rubrique;
//		}
    }

  /**
     * Set description
     *
     * @param string $description
     * @return rubrique
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add companyrepRubrique
     *
     * @param Zoom\DoualaBundle\Entity\Rubrique $companyrepRubrique
     *
     * @return companyrepRubrique
     */
    public function companyrepRubrique($companyrepRubrique)
    {
        $this->companyrepRubrique = $companyrepRubrique;

        return $this;
    }
	
    /**
     * Remove companyrepRubrique
     *
     * @param Zoom\DoualaBundle\Entity\companyRep $companyrepRubrique
     */
    public function removeCompanyrepRubrique($companyrepRubrique)
    {
        $this->userCompanyrepRubrique->removeElement($companyrepRubrique);
    }

    /**
     * Get companyrepRubrique
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCompanyrepRubrique()
    {
        return $this->companyrepRubrique;
    }


    /**
     * Add companyregistrationRubrique
     *
     * @param Zoom\DoualaBundle\Entity\CompanyRegistration $companyregistrationRubrique
     *
     * @return companyregistrationRubrique
     */
    public function companyregistrationRubrique($companyregistrationRubrique)
    {
        $this->companyregistrationRubrique = $companyregistrationRubrique;

        return $this;
    }
	
    /**
     * Remove companyregistrationRubrique
     *
     * @param Zoom\DoualaBundle\Entity\companyRegistration $companyregistrationRubrique
     */
    public function removeCompanyregistrationRubrique($companyregistrationRubrique)
    {
        $this->userCompanyregistrationRubrique->removeElement($companyregistrationRubrique);
    }

    /**
     * Get companyregistrationRubrique
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCompanyregistrationRubrique()
    {
        return $this->companyregistrationRubrique;
    }
}
