<?php

namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
/**
 * @ORM\Entity 
 * @ORM\Table(name="adstatus")
 */
class Adstatus
{
	public function __toString() {
    	return $this->adstatus;
	}
   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    private $id;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $adstatus;

   /**
    * @ORM\OneToMany(targetEntity="Ads", mappedBy="status")
	*/
	private $adstatusAds;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->adstatusAds = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return int 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set adstatusAds
     *
     * @param string $adstatusAds
     *
     * @return adstatusAds
     */
    public function setAdstatusAds($adstatusAds)
    {
        $this->adstatusAds = $adstatusAds;

        return $this;
    }

    /**
     * Get adstatusAds
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAdstatusAds()
    {
        return $this->adstatusAds;
    }

    /**
     * Add adstatusAds
     *
     * @param \DoualaBundle\Entity\Ads $adstatusAds
     *
     * @return Adstatus
     */
    public function adstatusAds($adstatusAds)
    {
        $this->adstatusAds = $adstatusAds;

        return $this;
    }

    /**
     * Remove adstatusAds
     *
     * @param \DoualaBundle\Entity\User $adstatusAds
     */
    public function removeAdstatusAds($adstatusAds)
    {
        $this->adstatusAds->removeElement($adstatusAds);
    }

   /**
    * Set adstatus
    *
    */
    public function setAdstatus($adstatus)
    {
        $this->adstatus = $adstatus;

        return $this;
    }

    /**
     * Get adstatus
     *
     */
    public function getAdstatus()
    {
        return $this->adstatus;
    }
}

