<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
/**
* @ORM\Entity
* @ORM\Table(name="place")
*/
class Place 
{   
    public function __toString() {
    return $this->place;
    } 
	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
	/**
     * @ORM\Column(type="string",length=500)
     */ 
    private $place;
    /**
     * @ORM\Column(type="string",length=255)
	 * @Assert\Blank()
     */    
    private $quartierId;
    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $villeId;
	/**
     * @ORM\Column(type="string",length=500)
     */    
    private $map_quartier;
	/**
     * @ORM\Column(type="string",length=500)
     */ 
    private $map_rue;
	/**
     * @ORM\Column(type="string",length=500)
     */ 
    private $map_place;
	 /**
     * @ORM\Column(type="string",length=500)
     */ 
     private $description;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set rueId
     *
     * @param string $rueId
     * @return Rue
     */
    public function setRueId($rueId)
    {
        $this->rueId = $rueId;
    
        return $this;
    }

    /**
     * Get rueId
     *
     * @return string 
     */
    public function getRueId()
    {
        return $this->rueId;
    }

    /**
     * Set quartierId
     *
     * @param string $quartierId
     * @return Rue
     */
    public function setQuartierId($quartierId)
    {
        $this->quartierId = $quartierId;
    
        return $this;
    }

    /**
     * Get quartierId
     *
     * @return string 
     */
    public function getQuartierId()
    {
        return $this->quartierId;
    }

    /**
     * Set villeId
     *
     * @param string $villeId
     * @return Rue
     */
    public function setVilleId($villeId)
    {
        $this->villeId = $villeId;
    
        return $this;
    }

    /**
     * Get villeId
     *
     * @return string 
     */
    public function getVilleId()
    {
        return $this->villeId;
    }

    /**
     * Set map_quartier
     *
     * @param string $mapQuartier
     * @return Rue
     */
    public function setMapQuartier($mapQuartier)
    {
        $this->map_quartier = $mapQuartier;
    
        return $this;
    }

    /**
     * Get map_quartier
     *
     * @return string 
     */
    public function getMapQuartier()
    {
        return $this->map_quartier;
    }

    /**
     * Set map_rue
     *
     * @param string $mapRue
     * @return Rue
     */
    public function setMapRue($mapRue)
    {
        $this->map_rue = $mapRue;
    
        return $this;
    }

    /**
     * Get map_rue
     *
     * @return string 
     */
    public function getMapRue()
    {
        return $this->map_rue;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Rue
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set rue
     *
     * @param string $rue
     * @return Rue
     */
    public function setRue($rue)
    {
        $this->rue = $rue;
    
        return $this;
    }

    /**
     * Get rue
     *
     * @return string 
     */
    public function getRue()
    {
        return $this->rue;
    }

    /**
     * Set place
     *
     * @param string $place
     * @return Place
     */
    public function setPlace($place)
    {
        $this->place = $place;
    
        return $this;
    }

    /**
     * Get place
     *
     * @return string 
     */
    public function getPlace()
    {
        return $this->place;
    }

    /**
     * Set map_place
     *
     * @param string $mapPlace
     * @return Place
     */
    public function setMapPlace($mapPlace)
    {
        $this->map_place = $mapPlace;
    
        return $this;
    }

    /**
     * Get map_place
     *
     * @return string 
     */
    public function getMapPlace()
    {
        return $this->map_place;
    }
}
