<?php 

namespace Zoom\DoualaBundle\Entity;

use FOS\UserBundle\Model\User as BaseUser;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="usefulltype")
 */ 
class Usefulltype
{
	public function __toString() {
    	return $this->usefulltype;
	}

   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    protected $id;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $description;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $usefulltype;

   /**
    * @ORM\OneToMany(targetEntity="Usefull", mappedBy="usefulltypeUsefull")
	*/
	private $usefulltypeInversed;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->usefulltypemap = new ArrayCollection();
    }


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

   /**
    * Set description
    *
    */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     */
    public function getDescription()
    {
        return $this->description;
    }

   /**
    * Set usefulltype
    *
    */
    public function setUsefulltype($usefulltype)
    {
        $this->usefulltype = $usefulltype;

        return $this;
    }

    /**
     * Get usefulltype
     *
     */
    public function getUsefulltype()
    {
        return $this->usefulltype;
    }
}
