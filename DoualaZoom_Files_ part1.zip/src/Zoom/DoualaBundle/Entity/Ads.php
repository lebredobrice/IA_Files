<?php 
namespace Zoom\DoualaBundle\Entity; 

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="ads")
 */
class Ads
{
	public function __toString()
	{
    	return (string)($this->getId());
	}
   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    protected $id;
	
   /**
    * @var string
    *
    * @ORM\Column(name="client", type="string", length=40)
    */
	protected $client;

   /**
    * @ORM\Column(type="string",length=255, nullable=true)
    * 
	* @Assert\File()
    */ 
	protected $path;

   /**
    * @var string
    *
    * @ORM\Column(name="pathreplace", type="string", length=255, nullable=true)
    */
	protected $pathreplace;

   /**
    * @var string
    *
    * @ORM\Column(name="url", type="string", length=255, nullable=true)
    */
	protected $url;
	
   /**
    * @var string
    *
    * @ORM\Column(name="startdate", type="string", length=500, nullable=true)
    */
	protected $startdate;

    /**
     * @ORM\ManyToOne(targetEntity="Adstype", inversedBy="adtypeAds")
     * @ORM\JoinColumn(name="adtype_id", referencedColumnName="id")
     */
	protected $adtype;

    /**
     * @ORM\ManyToOne(targetEntity="Zoom\UserBundle\Entity\User", inversedBy="userAds")
     * @ORM\JoinColumn(name="client_id", referencedColumnName="id", nullable = false)
     */
	protected $user;

    /**
     * @ORM\ManyToOne(targetEntity="Adstatus", inversedBy="adstatusAds")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id", nullable = false)
     */
	protected $status;

   /**
    * @var string
    *
    * @ORM\Column(name="sell_id", type="string", length=40, nullable=true)
    */
	protected $sellid;

   /**
    * @var string
    *
    * @ORM\Column(name="duree", type="string", length=40)
    */
	protected $duree;

   /**
    * @var boolean
    * @ORM\column(type="boolean", options={"default"=0})
    */
	protected $active;

///////////// GETTER / SETTER ///////////////////
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set path
     *
     * @param string $path
     *
     * @return Ads
     */
    public function setPath($path)
    {
        $this->path = $path;

        return $this;
    }

    /**
     * Get path
     *
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }

    /**
     * Set url
     *
     * @param string $url
     *
     * @return Ads
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url
     *
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set startdate
     *
     * @param string $startdate
     *
     * @return Ads
     */
    public function setStartdate($startdate)
    {
        $this->startdate = $startdate;

        return $this;
    }

    /**
     * Get startdate
     *
     * @return string
     */
    public function getStartdate()
    {
        return $this->startdate;
    }

    /**
     * Set adtype
     *
     */
    public function setAdtype($adtype)
    {
        $this->adtype = $adtype;

        return $this;
    }

    /**
     * Get adtype
     *
     */
    public function getAdtype()
    {
        return $this->adtype;
    }

   /**
    * Set sellid
    *
    */
    public function setSellid($sellid)
    {
        $this->sellid = $sellid;

        return $this;
    }

    /**
     * Get sellid
     *
     */
    public function getSellid()
    {
        return $this->sellid;
    }
	
   /**
    * Set client
    *
    */
    public function setClient($client)
    {
        $this->client = $client;

        return $this;
    }

    /**
     * Get client
     *
     */
    public function getClient()
    {
        return $this->client;
    }

    /**
     * Set clientid
     *
     * @return Ads
     */
    public function setClientid($clientid)
    {
        $this->clientid = $clientid;

        return $this;
    }

    /**
     * Get clientid
     *
     */
    public function getClientid()
    {
        return $this->clientid;
    }

    /**
     * Set pathreplace
     *
     * @return Ads
     */
    public function setPathreplace($pathreplace)
    {
        $this->pathreplace = $pathreplace;

        return $this;
    }

    /**
     * Get pathreplace
     *
     */
    public function getPathreplace()
    {
        return $this->pathreplace;
    }

    /**
     * Set duree
     * @return Ads
     */
    public function setDuree($duree)
    {
        $this->duree = $duree;

        return $this;
    }

    /**
     * Get duree
     */
    public function getDuree()
    {
        return $this->duree;
    }

    /**
     * Set active
     *
     * @return Ads
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     */
    public function getActive()
    {
        return $this->active;
    }

	/**
     * Set user
     *
     * @param \UserBundle\Entity\User $user
     *
     * @return Ads
     */
    public function setUser($user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \UserBundle\Entity\user
     */
    public function getUser()
    {
        return $this->user;
    }

	/**
     * Set status
     *
     * @param \DoualaBundle\Entity\Adstatus $status
     *
     * @return Ads
     */
    public function setStatus($status = null)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return \DoualaBundle\Entity\Adstatus
     */
    public function getStatus()
    {
        return $this->status;
    }
///////  validations constraint/////////////////////////////////////////////////
	public static function loadValidatorMetadata(ClassMetadata $metadata)
    {
		/// validation path03 (logo) ///////////////////////////////////////////
	    $metadata->addPropertyConstraint('path',new Assert\Image(array(
             'maxSize' => '10M', // au plus 10 mega octet
			 'mimeTypes' => array(
             'image/gif',
             'image/png',
			 'image/jpg',
			 'image/jpeg',
			 'image/pjpeg',
			 'image/jpeg',
			 ),
            'mimeTypesMessage' => 'Votre image n\'est pas valide (JPG, Gif, JPG, PNG min width: 45px, max width: 1500px, min height: 43px, max height: 1500px, max size: 3mo)',
        )));
	}
}
