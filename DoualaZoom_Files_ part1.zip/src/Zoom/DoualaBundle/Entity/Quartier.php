<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
/**
* @ORM\Entity
* @ORM\Table(name="quartier")
* @UniqueEntity("quartier")
*/
class Quartier
{   	
    public function __toString() {
    return $this->quartier;
    } 

	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $quartier;

    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $villeId;

	/**
     * @ORM\Column(type="string",length=500,nullable=true)
     */    
    private $map;
     
	 /**
     * @ORM\Column(type="string",length=500)
     */ 
	   private $description;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set quartier
     *
     * @param string $quartier
     * @return Quartier
     */
    public function setQuartier($quartier)
    {
        $this->quartier = $quartier;
    
        return $this;
    }

    /**
     * Get quartier
     *
     * @return string 
     */
    public function getQuartier()
    {
        return $this->quartier;
    }

    /**
     * Set villeId
     *
     * @param string $villeId
     * @return Quartier
     */
    public function setVilleId($villeId)
    {
        $this->villeId = $villeId;
    
        return $this;
    }

    /**
     * Get villeId
     *
     * @return string 
     */
    public function getVilleId()
    {
        return $this->villeId;
    }

    /**
     * Set map
     *
     * @param string $mapQuartier
     * @return Quartier
     */
    public function setMap($map)
    {
        $this->map = $map;
    
        return $this;
    }

    /**
     * Get map
     *
     * @return string 
     */
    public function getMap()
    {
        return $this->map;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Quartier
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }
}
