<?php 
namespace Zoom\DoualaBundle\Entity; 

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="entreprise_model")
 */
class CompanyRep 
{
	public function __toString()
	{
    	return (string)($this->getId());
	}
   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    protected $id;
	
    /**
     * @ORM\ManyToOne(targetEntity="Zoom\DoualaBundle\Entity\Rubrique", inversedBy="companyrepRubrique")
     * @ORM\JoinColumn(name="rubrique_id", referencedColumnName="id")
     */
	protected $rubriqueId;

    /**
     * @ORM\ManyToOne(targetEntity="Zoom\UserBundle\Entity\User", inversedBy="userCompanyrep")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
	protected $companyrepUserid;

    /**
     * @ORM\ManyToOne(targetEntity="Zoom\DoualaBundle\Entity\Activite", inversedBy="activiteCompanyrep")
     * @ORM\JoinColumn(name="entreprise_id", referencedColumnName="id")
     */
	protected $entrepriseId;

   /**
    * @var string
    *
    * @ORM\Column(name="startdate", type="string", length=500, nullable=true)
    */
	protected $startdate;
	
   /**
    * @var string
    *
    * @ORM\Column(name="duree", type="string", length=40)
    */
	protected $duree;

   /**
    * @var string
    *
    * @ORM\Column(name="sell_id", type="string", length=40)
    */
	protected $sellid;

   /**
    * @var boolean
    * @ORM\column(name="active", type="boolean", options={"default"=0})
    */
	protected $active;

///////////// GETTER / SETTER ///////////////////
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set rubriqueId
     *
     * @param Zoom\DoualaBundle\Entity\Rubrique $rubriqueId
     *
     * @return Company_rep
     */
    public function setRubriqueId($rubriqueId)
    {
        $this->rubriqueId = $rubriqueId;

        return $this;
    }

    /**
     * Get rubriqueId
     *
     * @return string
     */
    public function getRubriqueId()
    {
        return $this->rubriqueId;
    }


    /**
     * Get companyrepUserid
     *
     * @return string
     */
    public function getCompanyrepUserid()
    {
        return $this->companyrepUserid;
    }

    /**
     * Set companyrepUserid
     *
     * @param \Zoom\DoualaBundle\Entity\Rubrique $companyrepUserid 
     *
     * @return CompanyRep
     */
    public function setCompanyrepUserid($companyrepUserid)
    {
        $this->companyrepUserid = $companyrepUserid;

        return $this;
    }

    /**
     * Set entrepriseId
     *
     * @param \Zoom\DoualaBundle\Entity\Activite $entrepriseId
     *
     * @return CompanyRep
     */
    public function setEntrepriseId($entrepriseId)
    {
        $this->entrepriseId = $entrepriseId;
		
		return $this;
    }

    /**
     * get entrepriseId
     *
     */
    public function getEntrepriseId()
    {
        return $this->entrepriseId;
    }

    /**
     * Get startdate
     *
     */
    public function getStartdate()
    {
        return $this->startdate;
    }

   /**
    * Set startdate
    *
    */
    public function setStartdate($startdate)
    {
        $this->startdate = $startdate;

        return $this;
    }

    /**
     * Get active
     *
     */
    public function getActive()
    {
        return $this->active;
    }
	
   /**
    * Set active
    *
    */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

   /**
    * Set sellid
    *
    */
    public function setSellid($sellid)
    {
        $this->sellid = $sellid;

        return $this;
    }

    /**
     * Get sellid
     */
    public function getSellid()
    {
        return $this->sellid;
    }


   /**
    * Set duree
    */
    public function setDuree($duree)
    {
        $this->duree = $duree;

        return $this;
    }

    /**
     * Get duree
     *
     */
    public function getDuree()
    {
        return $this->duree;
    }
}
