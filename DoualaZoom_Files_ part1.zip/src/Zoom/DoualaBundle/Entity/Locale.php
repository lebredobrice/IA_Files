<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
/**
* @ORM\Entity
* @ORM\Table(name="locale")
*/
class Locale
{   	
    public function __toString() {
    return $this->pays;
    } 

	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
	
    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $email;
	
    /**
     * @ORM\Column(type="string",length=255)
     */    
    private $phone;
	
	/**
     * @ORM\Column(type="string",length=5)
     */ 
    private $indicatif;
	
   /**
    * @ORM\Column(type="string",length=500)
    */ 
    private $description;
	
   /**
    * @ORM\Column(type="string",length=500)
    */ 
    private $ville;
	
   /**
    * @ORM\Column(type="string",length=500)
    */ 
    private $pays;
	
   /**
    * @ORM\Column(type="string",length=5)
    */ 
    private $code;
	
   /**
    * @ORM\Column(type="string",length=5)
    */ 
    private $curency;
	
   /**
    * @ORM\Column(type="string",length=100)
    */ 
    private $sitetitle;
	
   /**
    * @ORM\Column(type="string",length=100)
    */ 
    private $sitename;
	
   /**
    * @ORM\Column(type="string",length=100)
    */ 
    private $siteurl;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Locale
     */
    public function setEmail($email)
    {
        $this->email = $email;
    
        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Locale
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }
	
    /**
     * Set phone
     *
     * @param string $phone
     * @return Locale
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    
        return $this;
    }

    /**
     * Get phone
     *
     * @return string 
     */
    public function getPhone()
    {
        return $this->phone;
    }
	
    /**
     * Set indicatif
     *
     * @param string $indicatif
     * @return Locale
     */
    public function setIndicatif($indicatif)
    {
        $this->indicatif = $indicatif;
    
        return $this;
    }

    /**
     * Get indicatif
     *
     * @return string 
     */
    public function getIndicatif()
    {
        return $this->indicatif;
    }
	
    /**
     * Set ville
     *
     * @param string $ville
     * @return Locale
     */
    public function setVille($ville)
    {
        $this->ville = $ville;
    
        return $this;
    }

    /**
     * Get ville
     *
     * @return string 
     */
    public function getVille()
    {
        return $this->ville;
    }

    /**
     * Set pays
     *
     * @param string $pays
     * @return Locale
     */
    public function setPays($pays)
    {
        $this->pays = $pays;
    
        return $this;
    }

    /**
     * Get pays
     *
     * @return string 
     */
    public function getPays()
    {
        return $this->pays;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return Locale
     */
    public function setCode($code)
    {
        $this->code = $code;
    
        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set curency
     *
     * @param string $curency
     * @return Locale
     */
    public function setCurency($curency)
    {
        $this->curency = $curency;
    
        return $this;
    }

    /**
     * Get curency
     *
     * @return string 
     */
    public function getCurency()
    {
        return $this->curency;
    }

    /**
     * Set sitetitle
     *
     * @param string $sitetitle
     * @return Locale
     */
    public function setSitetitle($sitetitle)
    {
        $this->sitetitle = $sitetitle;
    
        return $this;
    }

    /**
     * Get sitetitle
     *
     * @return string 
     */
    public function getSitetitle()
    {
        return $this->sitetitle;
    }

    /**
     * Set sitename
     *
     * @param string $sitename
     * @return Locale
     */
    public function setSitename($sitename)
    {
        $this->sitename = $sitename;
    
        return $this;
    }

    /**
     * Get sitename
     *
     * @return string 
     */
    public function getSitename()
    {
        return $this->sitename;
    }

    /**
     * Set siteurl
     *
     * @param string $siteurl
     * @return Locale
     */
    public function setSiteurl($siteurl)
    {
        $this->siteurl = $siteurl;
    
        return $this;
    }

    /**
     * Get siteurl
     *
     * @return string 
     */
    public function getSiteurl()
    {
        return $this->siteurl;
    }
}
