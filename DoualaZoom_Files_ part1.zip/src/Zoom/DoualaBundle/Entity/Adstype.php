<?php 

namespace Zoom\DoualaBundle\Entity;

use FOS\UserBundle\Model\User as BaseUser;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="adstype")
 */ 
class Adstype
{
	public function __toString() {
    	return $this->adsname;
	}
   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    protected $id;

   /**
 	* @ORM\Column(type="integer")
 	*/
    protected $maxadstoanim;

   /**
 	* @ORM\Column(type="string")
 	*/
    protected $description;

   /**
 	* @ORM\Column(type="string")
	*/
    private $adsname;

   /**
 	* @ORM\Column(type="string")
	*/
    private $price;

   /**
 	* @ORM\Column(type="string")
	*/
    private $curency;

   /**
    * @ORM\OneToMany(targetEntity="Ads", mappedBy="adtype")
	*/
	private $adtypeAds;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->adtypeAds = new ArrayCollection();
    }


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

   /**
    * Set adsname
    *
    */
    public function setAdsname($adsname)
    {
        $this->adsname = $adsname;

        return $this;
    }

    /**
     * Get adsname
     *
     */
    public function getAdsname()
    {
        return $this->adsname;
    }

   /**
    * Set description
    *
    */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     */
    public function getDescription()
    {
        return $this->description;
    }

   /**
    * Set maxadstoanim
    *
    */
    public function setMaxadstoanim($maxadstoanim)
    {
        $this->maxadstoanim = $maxadstoanim;

        return $this;
    }

    /**
     * Get maxadstoanim
     *
     */
    public function getMaxadstoanim()
    {
        return $this->maxadstoanim;
    }


   /**
    * Set price
    *
    */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set curency
     *
     * @param string $curency
     * @return Locale
     */
    public function setCurency($curency)
    {
        $this->curency = $curency;
    
        return $this;
    }

    /**
     * Get curency
     *
     * @return string 
     */
    public function getCurency()
    {
        return $this->curency;
    }
}
