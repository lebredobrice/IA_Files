<?php 
namespace Zoom\DoualaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
/**
* @ORM\Entity
* @ORM\Table(name="rue")
* @UniqueEntity("rue")
*/
class Rue 
{   
    public function __toString() {
    return $this->rue;
    } 
	/**
     * @ORM\GeneratedValue
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    private $id;
	/**
     * @ORM\Column(type="string",length=255)
     */    
    private $rue;
    /**
     * @ORM\Column(type="string",length=255, nullable=true)
     */    
    private $quartierId;
    /**
     * @ORM\Column(type="string",length=255, nullable=true))
     */    
    private $villeId;
	/**
     * @ORM\Column(type="string",length=500, nullable=true))
     */ 
    private $map;
	 /**
     * @ORM\Column(type="string",length=500, nullable=true))
     */ 
     private $description;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set quartierId
     *
     * @param string $quartierId
     * @return Rue
     */
    public function setQuartierId($quartierId)
    {
        $this->quartierId = $quartierId;
    
        return $this;
    }

    /**
     * Get quartierId
     *
     * @return string 
     */
    public function getQuartierId()
    {
        return $this->quartierId;
    }

    /**
     * Set villeId
     *
     * @param string $villeId
     * @return Rue
     */
    public function setVilleId($villeId)
    {
        $this->villeId = $villeId;
    
        return $this;
    }

    /**
     * Get villeId
     *
     * @return string 
     */
    public function getVilleId()
    {
        return $this->villeId;
    }

    /**
     * Set map
     *
     * @param string $mapRue
     * @return Rue
     */
    public function setMap($map)
    {
        $this->map = $map;
    
        return $this;
    }

    /**
     * Get map
     *
     * @return string 
     */
    public function getMap()
    {
        return $this->map;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Rue
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set rue
     *
     * @param string $rue
     * @return Rue
     */
    public function setRue($rue)
    {
        $this->rue = $rue;
    
        return $this;
    }

    /**
     * Get rue
     *
     * @return string 
     */
    public function getRue()
    {
        return $this->rue;
    }
}
