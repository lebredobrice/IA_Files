<?php
namespace Zoom\DoualaBundle\Entity;
 
use Doctrine\ORM\Mapping as ORM;
 
/**
 * @ORM\Entity
 * @ORM\Table(name="tag")
 */
class Tag
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;
    
    /**
     * @ORM\Column(type="string")
     */
    protected $name;
        
    /**
     * @ORM\ManyToMany(targetEntity="Zoom\DoualaBundle\Entity\Activite", mappedBy="tags")
     */
    protected $activites;
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->activites = new \Doctrine\Common\Collections\ArrayCollection();
    }
 
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
 
    /**
     * Set name
     *
     * @param string $name
     *
     * @return Tag
     */
    public function setName($name)
    {
        $this->name = $name;
 
        return $this;
    }
 
    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }
 
    /**
     * Add activite
     *
     * @param \Zoom\DoualaBundle\Entity\Activite $activite
     *
     * @return Tag
     */
    public function addActivite(\Zoom\DoualaBundle\Entity\Activite $activite)
    {
        $this->activites[] = $activite;
 
        return $this;
    }
 
    /**
     * Remove activite
     *
     * @param \Zoom\DoualaBundle\Entity\Activite $activite
     */
    public function removeProduct(\Zoom\DoualaBundle\Entity\Activite $activite)
    {
        $this->activites->removeElement($activite);
    }
 
    /**
     * Get activites
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getActivites()
    {
        return $this->activites;
    }
}

