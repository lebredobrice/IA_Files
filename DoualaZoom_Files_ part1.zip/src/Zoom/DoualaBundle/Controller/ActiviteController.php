<?php 
namespace Zoom\DoualaBundle\Controller;

use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Zoom\DoualaBundle\Entity\Activite;
use Zoom\DoualaBundle\Entity\Rue;
use Zoom\DoualaBundle\Entity\Repere;
use Zoom\DoualaBundle\Form\ActiviteForm;
use Zoom\DoualaBundle\Form\rechercheEntrepriseFormAdmin;
use Zoom\DoualaBundle\Form\rechercheRubriqueFormAdmin;
use Zoom\DoualaBundle\Form\rechercheQuartierFormAdmin;
use Zoom\DoualaBundle\Form\rechercheAlphabetiqueFormAdmin;
use Zoom\DoualaBundle\Form\rechercheActivatedFormAdmin;
use Symfony\Component\Form\FormError;

class ActiviteController extends Controller
{ 
//////////////////////////////// EDITER/AJOUTER ////////
	public function editerAction(Request $request, $id)
	{
		$em = $this->getDoctrine()->getManager();
		$rubrique = "";
		$message_new = "";
		// Test du formulaire: nouvelle entr�e ou mofification
		if ( $id ){ //... une modification

			$activite = $em->getRepository('ZoomDoualaBundle:Activite')->findOneById( $id );
			// Pour la valeurs par defaut des champs de type entity choice. Elle doit etre la valeur en base de donn�e
			// definition des cookies utilis�s dans les choice list de choicela class du formumaire quigarde oldRubriqueId
			// 
			if( !$activite ){
				die("Entreprise non trouv�");
			}
			//
			$file01 = $activite->getPath01();
			$file02 = $activite->getPath02();
			$file03 = $activite->getPath03();
			// Fin

			if (!$activite)
			{
				$message='Aucune activite trouv�e';
			}
			else
			{
				$form = $this->createForm(activiteForm::class, $activite);
				//$form->get('rubriqueId')->setData($oldRubriqueId);
			}
		}
		else //... une nouvelle insertion
		{ 
			$activite = new Activite();
			$form = $this->createForm(activiteForm::class, $activite );
		}

		$form->handleRequest($request);

		if ($form->isValid())  // formulaire envoy�
		{

			// Reperes: si le rep�re saisie n'existe pas encore dans la base de donn�e, on l'ajoute dans la table repere
			$repereSaisie = trim($form['repereId']->getData());
			// est ce que un repere a �t� saisie
			if($repereSaisie != "")
			{
				// est ce que ce repere existe d�ja sinon on le cr�e
				$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneByRepere($repereSaisie );
//var_dump($repereObj);
				$repereCount = sizeof($repereObj);
//echo $repereCount ;
				if($repereCount==0 && $form['repereId']->getData()!= '') //nouveau repere
				{
					$em01 = $this->getDoctrine()->getManager();
					//quartierId du repere en fonction du nom du quartier
					$quartier = trim($form['quartierId']->getData());
					$quartierObj = $em01->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
					$quartierId = $quartierObj->getId();
					// villeId du repere
					$ville = trim($form['villeId']->getData());
					$villeObj = $em01->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($ville);
					$villeId = $villeObj->getId();
					// repere
					$repere = new repere();
					$repere->setRepere($repereSaisie);
					$repere->setQuartierId($quartierId);
					$repere->setVilleId($villeId);
					//// on persist la base de donn?e avec le nouveau Repere
					$em->persist($repere);
					$em->flush($repere);
				}
			}
			// fin traitement des Reperes

			// Traitement des rues
			// Rue: si la rue saisie n'existe pas encore dans la base de donn�e, on l'ajoute dans la table Rue
			$rueSaisie = trim($form['rueId']->getData());
			// est ce que une rue a �t� saisie
			if($rueSaisie != "")
			{
				// est ce que cette rue repere existe d�ja sinon on la cr�e
				$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneByRue($rueSaisie );
//var_dump($repereObj);
				$rueCount = sizeof($rueObj);
//echo $repereCount ;
				if($rueCount==0 && $form['rueId']->getData()!= '') //nouveau repere
				{
					$em01 = $this->getDoctrine()->getManager();
					//quartierId du repere en fonction du nom du quartier
					$quartier = trim($form['quartierId']->getData());
					$quartierObj = $em01->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
					$quartierId = $quartierObj->getId();
					// villeId de la rue
					$ville = trim($form['villeId']->getData());
					$villeObj = $em01->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($ville);
					$villeId = $villeObj->getId();
					// repere
					$rue = new rue();
					$rue->setRue($rueSaisie);
					$rue->setQuartierId($quartierId);
					$rue->setVilleId($villeId);
					//// on persist la base de donn?e avec la nouvelle Rue
					$em->persist($rue);
					$em->flush($rue);
				}
			}
			// fin traitement des rues
			// Recup�rationdes Id en fonction des noms sur le formulaire avant de sauvegarder
			// Id de la ville � partir du nom de la ville
			$villeId = trim($form['villeId']->getData());
			$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($villeId);
			$ville = $villeObj->getId();
			$activite->setVilleId($ville);
			// Id de la quartier � partir du nom duu quartier
			$quartierId = trim($form['quartierId']->getData());
			$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartierId);
			$quartier = $quartierObj->getId();
			$activite->setQuartierId($quartier);
			// Id de la fonction � partir du nom de la fonction
			$fonctionId = trim($form['fonctionId']->getData());
			$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneByFonction($fonctionId);
			$fonction = $fonctionObj->getId();
			$activite->setFonctionId($fonction);
			// Id de la rubrique � partir du nom de la rubrique
			$rubriqueId = trim($form['rubriqueId']->getData());
			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneByRubrique($rubriqueId);
			$rubrique = $rubriqueObj->getId();
			$activite->setRubriqueId($rubrique);
			// Id de adsize � partir du nom de la adsize
			//$adsizeId = trim($form['adsizeId']->getData());
			//$adsizeObj = $em->getRepository('ZoomDoualaBundle:Adsize')->findOneByAdsize($adsizeId);
			//$adsize = $adsizeObj->getId();
			//$activite->setRubriqueId($rubrique);
			// la combo box jquery est trait�e ici
			// Id du repere � partir du nom du repere
			$repereId = trim($form['repereId']->getData());
			$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneByRepere($repereId);

			if(isset($repereObj))
			{
				$repere = $repereObj->getId();
				$activite->setRepereId($repere);
			}
			else // si aucun repere n'a �t� choisis, l'id du repere = 0
			{
				$activite->setRepereId(0);
			}
			// fin
			// la comboboxjquery de la rue est trait�e ici
			// Id de la rue � partir du nom de la rue
			$rueId = trim($form['rueId']->getData());
			$repereObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneByRue($rueId);
			// la combo box jquery de la rue est trait�e ici
			if(isset($rueObj))
			{
				$rue = $rueObj->getId();
				$activite->setRueId($rue);
			}
			else // si aucun repere n'a �t� choisis, l'id du repere = 0
			{
				$activite->setRueId(0);
			}
			///
			///////////////// Messages d'erreur de validation et contraintes suppl�mentaires du formlaire d'ajout modification d'activit�s /////
			$validation = "";
			// Validation de la rubrique
			$data01 = $form['rubriqueId']->getData(); // on verifie que le champ rubrique a �t� modifi� avant de persister
			$rubriqueformId = $data01->getId();
			if($rubriqueformId == 0) // la rubrique n'a pas bien �t� chang�e
			{
				$validation = 1; // Veuillez selectionner une rubrique
			}
			// Validation du num�ro de telephone01
			$telephone01 = $form['telephone01']->getData();
			// nombre de caracteres du num�ro
			$telephone01_len = strlen($telephone01);
			if($telephone01_len < 6 || $telephone01_len > 16)
			{
				$validation = 2; // Le num�ro T�l�phone01 est invalide
			}
			// Validation du num�ro de telephone02
			$telephone02 = $form['telephone02']->getData();
			// nombre de caracteres du num�ro
			$telephone02_len = strlen($telephone02);
			if($telephone02_len !=0 && $telephone02_len < 6)
			{
				$validation = 3; // Le num�ro T�l�phone02 est invalide
			}
			// Validation du num�ro du fax
			$fax = $form['fax']->getData();
			// nombre de caracteres du num�ro
			$fax_len = strlen($fax);
			if($fax_len!=0 && $fax_len < 6)
			{
				$validation = 4; // Le num�ro Fax est invalide
			}
			// Validation du nom de l'activit�
			// nombre de caracteres de l'activt�
			$entreprise = $form['entreprise']->getData();
			$activite_len = strlen($entreprise);
			if($activite_len < 3)
			{
				$validation = 5; // Le nom de l'activit� est invalide
			}
			// Validation du quartier
			$data02 = $form['quartierId']->getData(); // on verifie que le champ rubrique a �t� modifi� avant de persister
			$quartierformId = $data02->getId();
			if($quartierformId == 0) // la rubrique n'a pas bien �t� chang�e
			{
				$validation = 6; // Veuillez selectionner une rubrique
			}
			// Validation de l'unicit� de EntrepriseRubriqueRue
			// Collection de toutes Id les entreprises qui ont deja ce nom

			$entrepriseAInserer = trim($activite->getEntreprise());
			$entrepriseAInsererRubrique = trim($activite->getRubriqueId());
			$entrepriseAInsererRueId = trim($activite->getRueId());
// echo id . ' - ' . $entrepriseAInserer  . ' - ' . $entrepriseAInsererRubrique . ' - ' . $entrepriseAInsererRueId;
			$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a WHERE a.entreprise =:entrepriseAInserer AND a.id !=:id AND a.rubriqueId =:entrepriseAInsererRubrique AND a.rueId =:entrepriseAInsererRueId AND a.rueId != 0') // si la rue existe, rueId != 0
			->setParameters(array(
				'entrepriseAInserer' => $entrepriseAInserer,
				'entrepriseAInsererRubrique' => $entrepriseAInsererRubrique,
				'id' => $id,
				'entrepriseAInsererRueId' => $entrepriseAInsererRueId,));
			$entreprisesDejaObj = $query->getResult();
			if( !is_null( $entreprisesDejaObj ) ) 
			{
				// $validation = 7;  // This option should be reviewed
			}
			///////////// Fin des messages de validations ///

			///////////// validations /// 
			if($validation == "") // Tout va bien
			{
				// new file path
				$formPath01 = $form['path01']->getData();
				$formPath02 = $form['path02']->getData();
				$formPath03 = $form['path03']->getData();
				
				if($formPath01)
				{ 
					$path01 = $this->get('app.file_uploader')->upload($formPath01);				
					$activite->setPath01($path01);
				}
				//else if($file01) 
				//{
				//	$activite->setPath01($file01);
				//}
				
				if($formPath02)
				{
					$path02 = $this->get('app.file_uploader')->upload($formPath02);				
					$activite->setPath02($path02);
				}
				//else  if($file02)
				//{
				//	$activite->setPath02($file02);
				//}
				
				if($formPath03)
				{
					$path03 = $this->get('app.file_uploader')->upload($formPath03);				
					$activite->setPath03($path03);
				}
				//else  if($file03)
				//{
				//	$activite->setPath03($file03);
				//}
                
//var_dump( $activite->getTags() ); 
//die();
				$em->persist($activite); 
				$em->flush();

				// reaffichage du formulaire de modif et son messages
				if ($id)
				{
					$nom=$activite->getEntreprise();
					$message_modif = $nom;
                    // get company's tag
                    $company_tags = $activite->getTags();
                    
// var_dump( $company_tags );
                    
					return $this->render('ZoomDoualaBundle:Activite:insererActivitePageAdmin.html.twig', array(
                        'tags'  =>  $company_tags,
						'formajouter'   		=>  $form->createView(),
						'message_modif' 		=>  $message_modif,
						'oldRubriqueId' 		=> trim($activite->getRubriqueId()),
						'oldFonctionId' 		=> trim($activite->getFonctionId()),
						'oldQuartierId' 		=> trim($activite->getQuartierId()),
						'oldRueId' 				=> trim($activite->getRueId()),
						'oldRepereId'			=> trim($activite->getRepereId()),
						'oldAdsizeId' 			=> trim($activite->getAdsizeId()),
						'oldActivated' 			=> $activite->getActivated(),
						'oldDate_value'   		=> $activite->getDate(),
						'combobox02Url_cookievalue' => "modif",
					));				
                }
				else{   // after insert the new company, Edit
					$message_new = true;
					$id = $activite->getId();
					return $this->redirect($this->generateUrl('zoom_douala_admin_activite_modifier', array(
						'id' => $id,
					)));
				}
			}
			else if($validation == 1) // rubrique requise
			{
				$message = "Veuillez selectionner une rubrique";
				$dateError = new FormError($message);
				$form->get('rubriqueId')->addError($dateError);
			}
			else if ($validation == 2) // T�l�phone01  est invalide
			{
				$message = "Le num�ro de T�l�phone01 est invalide";
				$dateError = new FormError($message);
				$form->get('telephone01')->addError($dateError);
			}
			else if ($validation == 3) // T�l�phone02  est invalide
			{
				$message = "Le num�ro de T�l�phone02 est invalide";
				$dateError = new FormError($message);
				$form->get('telephone02')->addError($dateError);
			}
			else if ($validation == 4) // Fax est invalide
			{
				$message = "Le num�ro de Fax est invalide";
				$dateError = new FormError($message);
				$form->get('fax')->addError($dateError);
			}
			else if ($validation == 5) // Nom de l'entreprise incorrect
			{
				$message = "Le nom de l'entreprise doit avoir au moins de 3 caract�re";
				$dateError = new FormError($message);
				$form->get('entreprise')->addError($dateError);
			}
			else if ($validation == 6) // quartier non requis
			{
				$message = "Choisissez un quartier";
				$dateError = new FormError($message);
				$form->get('quartierId')->addError($dateError);
			}
			else if ($validation == 7)
			{
				$message = "Cette entreprise existe d�ja dans la rue ". $form['rueId']->getData();
				$dateError = new FormError($message); // quartier non choisis
				$form->get('entreprise')->addError($dateError);
			}
			// return for the case when an error occured during the form post
			return $this->render('ZoomDoualaBundle:Activite:insererActivitePageAdmin.html.twig', array(
				'formajouter' 			=> $form->createView(),
				'id'					=> $id,
				'oldRubriqueId' 		=> trim($activite->getRubriqueId()),
				'oldFonctionId' 		=> trim($activite->getFonctionId()),
				'oldQuartierId' 		=> trim($activite->getQuartierId()),
				'oldRueId' 				=> trim($activite->getRueId()),
				'oldRepereId'			=> trim($activite->getRepereId()),
				'oldAdsizeId' 			=> trim($activite->getAdsizeId()),
				'oldActivated' 			=> $activite->getActivated(),
				'oldDate_value'   		=> $activite->getDate(),
				'combobox02Url_cookievalue' => "modif",
			));
		}
		else // Affichage du formulaire d'ajout ou de modification
		{

			if($id != 0){	// modif
// var_dump( $activite->getTags()->toArray() );
				$company_tags = $activite->getTags();
				return $this->render('ZoomDoualaBundle:Activite:insererActivitePageAdmin.html.twig', array(
					'tags'  				=> ( $company_tags ) ? $company_tags : '',
					'formajouter' 			=> $form->createView(),
					'id'					=> $id,
					'oldRubriqueId' 		=> trim($activite->getRubriqueId()),
					'oldFonctionId' 		=> trim($activite->getFonctionId()),
					'oldQuartierId' 		=> trim($activite->getQuartierId()),
					'oldRueId' 				=> trim($activite->getRueId()),
					'oldRepereId'			=> trim($activite->getRepereId()),
					'oldAdsizeId' 			=> trim($activite->getAdsizeId()),
					'oldActivated' 			=> $activite->getActivated(),
					'oldDate_value'   		=> $activite->getDate(),
					'combobox02Url_cookievalue' => "modif",
				));
			}
			else{ // ajout
				return $this->render('ZoomDoualaBundle:Activite:insererActivitePageAdmin.html.twig', 
					array(
						'formajouter' 				=> $form->createView(),
						'oldRubriqueId' 			=> '',
						'oldFonctionId' 			=> '',
						'oldQuartierId' 			=> '',
						'oldRueId' 					=> '',
						'oldRepereId'				=> '',
						'oldAdsizeId' 				=> '',
						'oldActivated' 				=> '',
						'oldDate_value'   			=> '',
						'combobox02Url_cookievalue' => 'insert',
					)
				);
			}
			//return $this->redirect($this->generateUrl('zoom_douala_admin_activite_modifier'));	
		}
	}
////////////////////////// LISTER LES ACTIVITES  - 030915 - 1348///////////////////////// PAGE ADMIN - LISTER /////////////////
	public function listerAction(Request $request)
	{	
// echo "travaux en cours sur cette page... 98%"; 
		$message = "";
		$rubrique = "";
		$activated = "";
		$quartier = "";
		$motcle = "";
		$nombre = "";
		$entreprise = "";
		$alphabet = "";
		$pagination="";
		$query = "";
		$videoPath = ""; // le Path de la video � utiliser avec Jquery sur les vues
		$idzero = 0;
		$activite = new Activite();
		$form01 = $this->createForm(rechercheEntrepriseFormAdmin::class);
		$form02 = $this->createForm(rechercheRubriqueFormAdmin::class);
		$form03 = $this->createForm(rechercheAlphabetiqueFormAdmin::class); 
		$form04 = $this->createForm(rechercheQuartierFormAdmin::class);
		$form05 = $this->createForm(rechercheActivatedFormAdmin::class);
		$form01->handleRequest($request);
		$form02->handleRequest($request);
		$form03->handleRequest($request);
		$form04->handleRequest($request);
		$form05->handleRequest($request);
		
		// recuperation des valeurs cl?s sur les formulaires
		$em = $this->getDoctrine()->getManager();
		if ($form01->isSubmitted() && $form01->isValid()) // formulaire de recherche par mot cle
		{
			$motcle = trim($request->get('motcle'));
// echo $motcle;
			// recuperation du nom de l'entreprise et de son Id
			$motcleTab = explode(",", $motcle);
			$entrepriseNom = trim($motcleTab[0]); // entrepriseNom
			$entrepriseIdTab = explode("-", $motcleTab[1]);
			$entrepriseId = intval(trim($entrepriseIdTab[0])); // entrepriseId
			$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a WHERE a.id !=:id AND a.entreprise LIKE :entrepriseNom ORDER BY a.entreprise ASC')
				->setParameters(array('entrepriseNom'=>'%'.$entrepriseNom.'%', 'id' => $idzero));
			$entreprise = $query->getResult();
			$count = sizeof($entreprise);
			$message = "recherche de l'entreprise ".$entrepriseNom;
			if($count>0)
			{
				// message
				if ($count == 1)
				{
					$nombre = " ".$count."trouv�e";// nombre d'entreprise trouv?(s)
				}
				else if ($count > 1)
				{
					$nombre = " ".$count."trouv�es";// nombre d'entreprise trouv?(s)
				}
				// IDs to Names
				foreach($entreprise AS $values)
				{
					// noms des villes � partir des villeId
					$villeId = $values->getVilleId();
					// patch pour Gandi qui ne voit pas l'index Id = 0
					if($villeId != 0)
					{
						$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
						$ville = $villeObj->getVille();
					}
					else
					{
						$ville = "Aucune";
					}
					// fin patch pour Gandi qui ne voit pas l'index Id = 0
					$values->setVilleId($ville);
						// nom des quartiers � partir des quartierId
					$quartierId = intval(trim($values->getQuartierId()));
					// patch pour Gandi qui ne voit pas l'index Id = 0
					if($quartierId != 0)
					{
						$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
						$quartier = $quartierObj->getQuartier();
					}
					else
					{
						$quartier = "Aucun";
					}
					// fin patch pour Gandi qui ne voit pas l'index Id = 0
					$values->setQuartierId($quartier);
					// nom des rues � partir des rueId
					$rueId = $values->getRueId();
					// patch pour Gandi qui ne voit pas l'index Id = 0
					if($rueId != 0)
					{
						$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
						$rue = $rueObj->getRue();
					}
					else
					{
						$rue = "Aucun";
					}
					// fin patch pour Gandi qui ne voit pas l'index Id = 0
					$values->setRueId($rue);
					// nom des fonctions � partir des fonctionId
					$fonctionId = $values->getFonctionId();
					// patch pour Gandi qui ne voit pas l'index Id = 0
					if($fonctionId != 0)
					{
						$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);
						$fonction = $fonctionObj->getFonction();
					}
					else
					{
						$fonction = "Aucun";
					}
					// fin patch pour Gandi qui ne voit pas l'index Id = 0 
					$values->setFonctionId($fonction);
					// nom des rubriques � partir des rubriqueId
					$rubriqueId = $values->getRubriqueId();
					// patch pour Gandi qui ne voit pas l'index Id = 0 
					if($rubriqueId != 0)
					{
						$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
						$rubrique = $rubriqueObj->getRubrique();
					}
					else
					{
						$rubrique = "Aucune";
					}
					// fin patch pour Gandi qui ne voit pas l'index Id = 0 
					$values->setRubriqueId($rubrique);
					// nom des reperes � partir des repereId
					$repereId = $values->getRepereId();
					// patch pour Gandi qui ne voit pas l'index Id = 0 
					if($repereId != 0)
					{
						$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId);
						$repere = $repereObj->getRepere();
					}
					else
					{
						$repere = "Aucun";
					}
					// fin patch pour Gandi qui ne voit pas l'index Id = 0 
					$values->setRepereId($repere);
				}
			}
			else
			{
				$nombre = ": ".$count."trouv�"; // zero entreprise trouv�e
			}
			$paginator  = $this->get('knp_paginator');	////// Pagination	   
			$pagination = $paginator->paginate($entreprise, $request->query->get('page', 1)/*page number*/, 500/*limit per page*/);
			return $this->render('ZoomDoualaBundle:Activite:lister.html.twig', array(
					'formEntreprise' => $form01->createView(),
					'formRubrique' => $form02->createView(),
					'formAlphabetique' => $form03->createView(),
					'formQuartier' => $form04->createView(),
					'formActivated' => $form05->createView(),
					'message' => $message,
					'pagination' => $pagination,
					'nombre' => $nombre,
			));
			
		}
		else if ($form02->isSubmitted() && $form02->isValid()) // formulaire de recherche par rubrique 
		{	
			$rubrique = intval($request->get('rubrique'));// la variable numerique est de type string
			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->find($rubrique);
			//retrouver l' ID  de la rubrique 
			$rubriqueId = $rubriqueObj->getId();
			$rubriqueNom = $rubriqueObj->getRubrique();
			//var_dump($rubriqueObj);
			$message = "recherche des entreprises de la rubrique ".$rubriqueNom;
			$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a WHERE a.id !=:id AND a.rubriqueId =:rubriqueId ORDER BY a.entreprise ASC')
					->setParameters(array('rubriqueId'=>$rubriqueId, 'id' => $idzero));
			$entreprise = $query->getResult();
			//echo $rubrique;
			$count = sizeof($entreprise);
			if($count>0)
			{
				// message
				if ($count == 1)
				{
					$nombre = " ".$count."trouv�e";// nombre d'entreprise trouv?(s)
				}
				else if ($count > 1)
				{
					$nombre = " ".$count."trouv�es";// nombre d'entreprise trouv?(s)
				}
				//IDs to Names
				foreach($entreprise AS $values)
				{
				// noms des villes � partir des villeId
					$villeId = $values->getVilleId();
					$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
					$ville = $villeObj->getVille();
					$values->setVilleId($ville);
					// nom des quartiers � partir des quartierId
					$quartierId = $values->getQuartierId();
					$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
					$quartier = $quartierObj->getQuartier();
					$values->setQuartierId($quartier);
					// nom des rues � partir des rueId
//					$rueId = $values->getRueId();
//					$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
//					$rue = $rueObj->getRue();
//					$values->setRueId($rue);
//					// nom des fonctions � partir des fonctionId
//					$fonctionId = intval($values->getFonctionId());
//					$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);
//					if($fonctionObj){
//						$fonction = $fonctionObj->getFonction();
//						$values->setFonctionId($fonction);						
//					}
//					else{
//						$values->setFonctionId($fonctionId);
//					}
//

//					// nom des rubriques � partir des rubriqueId
					$rubriqueId = $values->getRubriqueId();
					if($rubriqueObj){
						$rubrique = $rubriqueObj->getRubrique();
						$values->setRubriqueId($rubrique);						
					}
					else{
						$values->setRubriqueId($rubriqueId);
					}
					// nom des reperes � partir des repereId
//					$repereId = $values->getRepereId();
//					$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId);
//					// patch
//					if($repereObj)
//					{
//						$repere = $repereObj->getRepere();	
//					}
//					else 
//					{
//						$repere = "Aucun";
//					}
//					$values->setRepereId($repere);
				}
			}
			else // zero entreprise trouv�e
			{
				$nombre = " ".$count."trouv�"; 
			}
			$paginator  = $this->get('knp_paginator');	////// Pagination	   
			$pagination = $paginator->paginate($entreprise, $request->query->get('page', 1)/*page number*/, 500/*limit per page*/);
			return $this->render('ZoomDoualaBundle:Activite:lister.html.twig', array(
					'formEntreprise' => $form01->createView(),
					'formRubrique' => $form02->createView(),
					'formAlphabetique' => $form03->createView(),
					'formQuartier' => $form04->createView(),
					'formActivated' => $form05->createView(),
					'message' => $message,
					'entreprise' => $entreprise,
					'pagination' => $pagination,
					'nombre' => $nombre,
			));	
		}
		else if ($form03->isSubmitted() && $form03->isValid()) // formulaire de recherche par lettre
		{	
			$alphabet = trim($request->get('alphabet'));
			$message = "recherche des entreprises commen�ant par la lettre ".ucfirst($alphabet)."";
			$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a WHERE a.entreprise LIKE :alphabet AND a.id !=:id ORDER BY a.entreprise ASC')
					->setParameters(array('alphabet'=>$alphabet.'%', 'id' => $idzero));
			$entreprise = $query->getResult();
			$count = sizeof($entreprise);
			if($count>0)
			{
				// message
				if ($count == 1)
				{
					$nombre = " ".$count."trouv�e";// nombre d'entreprise trouv?(s)
				}
				else if ($count > 1)
				{
					$nombre = " ".$count."trouv�es";// nombre d'entreprise trouv?(s)
				}
				//IDs to Names
				foreach($entreprise AS $values)
				{
					// noms des villes � partir des villeId
					$villeId = $values->getVilleId();
					$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
					$ville = $villeObj->getVille();
					$values->setVilleId($ville);
					// nom des quartiers � partir des quartierId
					$quartierId = $values->getQuartierId();
					$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
					$quartier = $quartierObj->getQuartier();
					$values->setQuartierId($quartier);
					// nom des rues � partir des rueId
//					$rueId = $values->getRueId();
//					// patch pour Gandi qui ne voit pas l'index Id = 0 
//					if($rueId != 0)
//					{
//						$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
//						// var_dump($rueObj);
//						$rue = ucfirst(strtolower($rueObj->getRue()));
//						//echo $rue;
//					}
//					else
//					{
//						$rue = "";
//					}
//					// fin patch pour Gandi qui ne voit pas l'index Id = 0 
//					$values->setRueId($rue);
//					// nom des fonctions � partir des fonctionId
//					$fonctionId = $values->getFonctionId();
					// patch pour Gandi qui ne voit pas l'index Id = 0
//					if($fonctionId != 0)
//					{
//						$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);
//						$fonction = ucfirst(strtolower($fonctionObj->getFonction()));
//					}
//					else
//					{
//						$fonction = "Aucune";
//					}
//					// fin patch pour Gandi qui ne voit pas l'index Id = 0
//					$values->setFonctionId($fonction);

					// nom des rubriques � partir des rubriqueId

					$rubriqueId = $values->getRubriqueId();
					if($rubriqueObj){
						$rubrique = $rubriqueObj->getRubrique();
						$values->setRubriqueId($rubrique);						
					}
					else{
						$values->setRubriqueId($rubriqueId);
					}
					// nom des reperes � partir des repereId
//					$repereId = $values->getRepereId();
//					// patch pour Gandi qui ne voit pas l'index Id = 0
//					if($repereId != 0)
//					{
//						$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId);
//						// var_dump($fonctionObj);
//						$repere = ucfirst(strtolower($repereObj->getRepere()));
//						//echo $repere;
//					}
//					else
//					{
//						$repere = "Aucun";
//					}
//					// fin patch pour Gandi qui ne voit pas l'index Id = 0
//					$values->setRepereId($repere);
				}
			}
			else
			{
				$nombre = " ".$count."trouv�";
			}
			$paginator  = $this->get('knp_paginator');	////// Pagination	   
			$pagination = $paginator->paginate($entreprise, $request->query->get('page', 1)/*page number*/, 3000/*limit per page*/);
			return $this->render('ZoomDoualaBundle:Activite:lister.html.twig', array(
				'formEntreprise' => $form01->createView(),
				'formRubrique' => $form02->createView(),
				'formAlphabetique' => $form03->createView(),
				'formQuartier' => $form04->createView(),
				'formActivated' => $form05->createView(),
				'message' => $message,
				'entreprise' => $entreprise,
				'pagination' => $pagination,
				'nombre' => $nombre,
			));
		}
		else if ($form04->isSubmitted() && $form04->isValid()) // formulaire de recherche par quartier 
		{		
			$quartier = $request->get('quartier');
			$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a WHERE a.id !=:id AND a.quartierId =:quartierId ORDER BY a.entreprise ASC')
					->setParameters(array('quartierId'=>$quartier, 'id' => $idzero));
			$entreprise = $query->getResult();
			$count = sizeof($entreprise);
			if($count>0)
			{
				// message
				if ($count == 1)
				{
					$nombre = " ".$count."trouv�e";// nombre d'entreprise trouv?(s)
				}
				else if ($count > 1)
				{
					$nombre = " ".$count."trouv�es";// nombre d'entreprise trouv?(s)
				}
				// IDs to Names
				foreach($entreprise AS $values)
				{
// echo($values->getEntreprise());
					// noms des villes � partir des villeId
					$villeId = $values->getVilleId();
					$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
					$ville = $villeObj->getVille();
					$values->setVilleId($ville);
					// nom des rues � partir des rueId
//					$rueId = $values->getRueId();
//					// patch pour Gandi qui ne voit pas l'index Id = 0
//					if($rueId != 0)
//					{
//						$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
//						$rue = ucfirst(strtolower($rueObj->getRue()));
//					}
//					else
//					{
//						$rue = "Aucune";
//					}
//					// fin patch pour Gandi qui ne voit pas l'index Id = 0
//					$values->setRueId($rue);
//					// nom des fonctions � partir des fonctionId
//					$fonctionId = $values->getFonctionId();
//					// patch pour Gandi qui ne voit pas l'index Id = 0
//					if($fonctionId != 0)
//					{
//						$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);
//						$fonction = ucfirst(strtolower($fonctionObj->getFonction()));
//					}
//					else
//					{
//						$fonction = "Aucune";
//					}
//					// fin patch pour Gandi qui ne voit pas l'index Id = 0
//					$values->setFonctionId($fonction);
//					// nom d'une rubrique � partir dune rubriqueId
//					$rubriqueId = $values->getRubriqueId();
//					if($rubriqueObj){
//						$rubrique = $rubriqueObj->getRubrique();
//						$values->setRubriqueId($rubrique);						
//					}
//					else{
//						$values->setRubriqueId($rubriqueId);
//					}

					// nom d'un quartier � partir du quartierId
					$quartierId = $values->getQuartierId();
					$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
					$quartier = $quartierObj->getQuartier();
					$values->setQuartierId($quartier);
					// nom des reperes � partir des repereId
					$repereId = $values->getRepereId();
					$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId);
					// patch pour Gandi qui ne voit pas l'index Id = 0
//					if($repereId != 0)
//					{
//						$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId);
//						// var_dump($fonctionObj);
//						$repere = ucfirst(strtolower($repereObj->getRepere()));
//						//echo $repere;
//					}
//					else
//					{
//						$repere = "";
//					}
					$values->setRepereId($repere);
					// fin patch pour Gandi qui ne voit pas l'index Id
					// message
					$message = "recherche des entreprises du quartier ".$quartier;
  			} // fin foreach
			}
			else
			{
				$nombre = " ".$count."trouv�";
			}
			$paginator  = $this->get('knp_paginator');	////// Pagination	   
			$pagination = $paginator->paginate($entreprise, $request->query->get('page', 1)/*page number*/, 3000/*limit per page*/);
			return $this->render('ZoomDoualaBundle:Activite:lister.html.twig', array(
				'formEntreprise' => $form01->createView(),
				'formRubrique' => $form02->createView(),
				'formAlphabetique' => $form03->createView(),
				'formQuartier' => $form04->createView(),
				'quartier' => $form04->createView(),
				'formActivated' => $form05->createView(),
				'message' => $message,
				'entreprise' => $entreprise,
				'pagination' => $pagination,
				'nombre' => $nombre,
			));
		}
		else if ($form05->isSubmitted() && $form05->isValid()) // formulaire de recherche par entreprises non activ�s 
		{	
			$activated = $request->get('activated');			
			// recherche par entreprises non activ�s
			//retrouver les entreprises en fonction de son index alphabetique
			$isActivated = "oui";
			$message = "recherche des entreprises non activ�es";
			$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a WHERE a.id !=:id AND a.activated !=:isActivated ORDER BY a.entreprise ASC')
				->setParameters(array('isActivated'=>$isActivated, 'id' => $idzero));
			$entreprise = $query->getResult();
			$count = sizeof($entreprise);
			if($count>0)
			{
				// message
				if ($count == 1)
				{
					$nombre = " ".$count."trouv�e";// nombre d'entreprise trouv?(s)
				}
				else if ($count > 1)
				{
					$nombre = " ".$count."trouv�es";// nombre d'entreprise trouv?(s)
				}
					//IDs to Names
				foreach($entreprise AS $values)
				{   
					// noms des villes � partir des villeId
					$villeId = $values->getVilleId();
// echo $values->getId(); 
					$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
					$ville = $villeObj->getVille();
					$values->setVilleId($ville);
					// nom des quartiers � partir des quartierId
					$quartierId = $values->getQuartierId();
					$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
					$quartier = $quartierObj->getQuartier();
					$values->setQuartierId($quartier);
//					// nom des rues � partir des rueId
//					$rueId = $values->getRueId();
//					// patch pour Gandi qui ne voit pas l'index Id = 0 
//					if($rueId != 0)
//					{
//						$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
//  					// var_dump($rueObj);
//						$rue = ucfirst(strtolower($rueObj->getRue()));
//						//echo $rue;
//					}
//					else
//					{
//						$rue = "";
//					}
//					// fin patch pour Gandi qui ne voit pas l'index Id = 0 
//					$values->setRueId($rue);
//					// nom des fonctions � partir des fonctionId
//					$fonctionId = $values->getFonctionId();
//					// patch pour Gandi qui ne voit pas l'index Id = 0
//					if($fonctionId != 0)
//					{
//						$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);
//						$fonction = ucfirst(strtolower($fonctionObj->getFonction()));
//					}
//					else
//					{
//						$fonction = "Aucune";
//					}
//					// fin patch pour Gandi qui ne voit pas l'index Id = 0
//					$values->setFonctionId($fonction);

					// nom des rubriques � partir des rubriqueId
					$rubriqueId = $values->getRubriqueId();
					$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
					if($rubriqueObj){
						$rubrique = $rubriqueObj->getRubrique();
						$values->setRubriqueId($rubrique);						
					}
					else{
						$values->setRubriqueId($rubriqueId);
					}
					// nom des reperes � partir des repereId
//					$repereId = $values->getRepereId();
//					// patch pour Gandi qui ne voit pas l'index Id = 0
//					if($repereId != 0)
//					{
//						$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId);
//						// var_dump($fonctionObj);
//						$repere = ucfirst(strtolower($repereObj->getRepere()));
//						//echo $repere;
//					}
//					else
//					{
//						$repere = "Aucun";
//					}
//					// fin patch pour Gandi qui ne voit pas l'index Id = 0
//					$values->setRepereId($repere);
//					// 
				}
			}
			else
			{
				$nombre = " ".$count."trouv�";
			}
			$paginator  = $this->get('knp_paginator');	////// Pagination	   
			$pagination = $paginator->paginate($entreprise, $request->query->get('page', 1)/*page number*/, 500/*limit per page*/);
			return $this->render('ZoomDoualaBundle:Activite:lister.html.twig', array(
				'formEntreprise' => $form01->createView(),
				'formRubrique' => $form02->createView(),
				'formAlphabetique' => $form03->createView(),
				'formQuartier' => $form04->createView(),
				'formActivated' => $form05->createView(),
				'message' => $message,
				'entreprise' => $entreprise,
				'pagination' => $pagination,
				'nombre' => $nombre,
			));
		}
		// fin entreprises non activ�s
		else // page par defaut
		{ 
			$em = $this->getDoctrine()->getManager();
 
			$isActivated = "oui";
			$message = "recherche des entreprises activ�es";
			$query = $em->createQuery('SELECT a.id, a.entreprise, a.rubriqueId, a.telephone01, a.email, a.web, a.contact, a.path01, a.path02, a.path03, a.quartierId, a.activated  FROM ZoomDoualaBundle:Activite a 
									   ORDER BY a.entreprise ASC');
			$entreprise = $query->getResult(); 

			$count = count($entreprise);

 
			if( $count > 0 ){
				// message
				if ( $count == 1 ){
					$nombre = " ".$count."trouv�e";// nombre d'entreprise trouv?(s)
				}
				else if ($count > 1)
				{
					$nombre = " ".$count."trouv�es";// nombre d'entreprise trouv?(s)
				}
				//IDs to Names
				//var_dump($entreprise );
				foreach($entreprise AS &$values)
				{
					// nom des quartiers � partir des quartierId
					$quartierId = trim( $values['quartierId'] );
// echo $quartierId .  '-';
//die;
					$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')
                                      ->findOneById($quartierId);
					$quartier = $quartierObj->getQuartier();
					$values['quartierId'] = $quartier;

					// nom des rubriques � partir des rubriquesId
					$rubriqueId = $values['rubriqueId'];
					if($rubriqueId){
						$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
						if($rubriqueObj){
							$rubrique = $rubriqueObj->getRubrique();
							$values['rubriqueId'] = utf8_encode($rubrique);
						}
						else{
//							echo $values->getEntreprise()." - ".$rubriqueId."<br>";
							$values['rubrique'] = $rubriqueId;
						}
					}
					else{
						$values['rubrique'] = "Pas de rubrique";
					}
				}
			}
			else
			{
				$nombre = " ".$count."trouv�";
			}

			$paginator  = $this->get('knp_paginator');	////// Pagination
			$pagination = $paginator->paginate($entreprise, $request->query->get('page', 1)/*page number*/, 500/*limit per page*/);
			
			$message = " ".$motcle; 
			return $this->render('ZoomDoualaBundle:Activite:lister.html.twig', array(
				'formEntreprise'   => $form01->createView(),
				'formRubrique'     => $form02->createView(),
				'formAlphabetique' => $form03->createView(),
				'formQuartier'     => $form04->createView(),
				'formActivated'    => $form05->createView(),
				'message'          => $message,
				'entreprise'       => $entreprise,
				'pagination'       => $pagination,
				'nombre'           => $nombre,
			));
		}
	}
/////////////////////////////// SUPRIMER UNE ACTIVITE///////////
	public function supprimerAction($todelete)
	{
		$em = $this->getDoctrine()->getManager();
		$todeletearray = explode(",",$todelete);
		foreach ($todeletearray as $id)
		{
			$activite = $em->find('ZoomDoualaBundle:Activite', $id);
			if (!$activite)
			{
				echo "Activite non trouvee";
			}
			else
			{
				$message = $activite->getEntreprise();
				$em->remove($activite);
				$em->flush();
				echo "Entreprise supprim�e";
			}
		}
	}
	// return new Response();


	public function rechercheActivitesRubriqueAdminAction()
	{
		$message = "recherche";
		$form02 = $this->createForm(new rechercheParRubriquesFormAdmin());
		$request = $this->container->get('request');
		$form02->handleRequest($request);
		// recherche par rubrique
		if ($form02->isValid())
		{
			$categorie = $request->get('categorie');
			if($categorie != '')
			{
				$em = $this->getDoctrine()->getManager();
				$entreprises = $em->getRepository('ZoomDoualaBundle:Activite')->findByCategory('$categorie');
				return $this->render('ZoomDoualaBundle:Activite:rechercheActivitesRubriqueAdmin.html.twig',  array('entreprise' => $entreprises, 'message'=>$message));
			}
		}
		// fin recherche par rubrique
		//return $this->redirect('zoom_douala_admin_activite_lister');
	}
}
