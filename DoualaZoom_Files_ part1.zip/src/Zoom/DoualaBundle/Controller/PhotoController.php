<?php
namespace Zoom\DoualaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Filesystem\Filesystem;
use Zoom\DoualaBundle\Entity\Activite;

class PhotoController extends Controller
{    
//// Afficher une photo //////////////////////////////////////////////////////////
    public function showAction($photoPath = null)
	{
	    $em = $this->getDoctrine()->getManager();
		// nom de l'entreprise qui a cette video
		$entrepriseObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneByPath($photoPath);
		$entreprise = $entrepriseObj->getEntreprise();
        return $this->render('ZoomDoualaBundle:Photo:show.html.twig', array(
		    'photoPath' => $photoPath,
		    'entreprise' => $entreprise,
			 ));
    }
//// Supprimer une photo //////////////////////////////////////////////////////////
    public function supprimerAction($photoPath)
	{
		$photoPath = trim($photoPath);
	    //echo $photoPath;
	   	$em = $this->getDoctrine()->getManager();
		// Update � id=Null  des  path02 des activit�s ayant pour video $photoPath, et suppression de la video
		$query = $em->createQuery('UPDATE ZoomDoualaBundle:Activite a
	             SET a.path =  NULL WHERE a.path =:photoPath')->setParameters(array('photoPath' => $photoPath,));
		$result = $query->getResult();
		$count = sizeof($result);
		//var_dump($videoPath); 
		//echo ($result);
		if($count == 1) // video updat� dans l'Activit�
		{
		    //update
			$activites = $query->getResult();  
			//var_dump($activites );
			// suppresssion du fichier video
		    //$fs = new Filesystem();
		    //$fs->remove(array('file', '../../../../../uploads/documents/', $videoPath));
			// url
			$url = __DIR__."/../../../../web/uploads/documents/".$photoPath;
			unlink($url);
			$message = $photoPath;
			return $this->render('ZoomDoualaBundle:Photo:remove.html.twig',  array( 'message'=>$message));
		}
		else
		{
		    echo "image non trouv�e";
		}
		   
	}	
}
