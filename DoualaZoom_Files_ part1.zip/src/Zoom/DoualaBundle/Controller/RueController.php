<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\Rue;
use Zoom\DoualaBundle\Form\RueForm;
use Symfony\Component\Form\FormError;

class RueController extends Controller  
{    
//////////////////////////////////////////////////////////////
   
////////////////////////////////////////////////////////////////////
    public function listerAction(Request $request)
	{
	    $em = $this->container->get('doctrine')->getManager();
        $query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Rue a'); // exclut l'index 0
	    $rues = $query->getResult();
	    $count = sizeof($rues);
	    if($count>0)
	    {
	        // message
		    $nombre = " ".$count."trouvés";// nombre de rues trouvés(s)	
		    //IDs to Names
		    foreach($rues AS $values)
		    {
				// noms des quartier- à partir des quartierId
			    $quartierId = $values->getQuartierId(); 
				// echo $quartierId." -" ;
			    // $quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
			    // patch pour Gandi qui ne voit pas l'index Id = 0 
					if($quartierId != 0)
					{
						$quartierIdObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
						// var_dump($quartierIdObj);
						$quartier = ucfirst(strtolower($quartierIdObj->getQuartier()));
						//echo $quartierId;
					}
					else
					{
						$quartier = "";
					}
				// fin patch pour Gandi qui ne voit pas l'index Id = 0
			    $values->setQuartierId($quartier); // cette variable change de type
		       
				// noms des villes à partir des villeId
			    $villeId = $values->getVilleId(); 
				//echo $villeId." -" ;
			    $villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
			    $ville = $villeObj->getVille();
			    $values->setVilleId($ville); // cette variable change de type
			}	
        }
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    // var_dump($rues);
		$pagination = $paginator->paginate($rues, $request->query->get('page', 1)/*page number*/, 1000/*limit per page*/);
	    
	    return $this->render('ZoomDoualaBundle:Rue:lister.html.twig', array(
	    'rues' => $rues,
		'pagination' => $pagination,
		'count' => $count,
		));
	}
////////////////////////////////////////////////////////////////////
///////// Rue ajouter/modifier
    public function modifierAction(Request $request, $id = null)
	{
   	    $message="";
		
		$em = $this->getDoctrine()->getManager();
		if (isset($id)) //... une edition
		{   $rue = $em->find('ZoomDoualaBundle:Rue', $id);
		    // Pour la valeur par defaut du quartier dans le formulaire
				// nom de la quartier de l'entité $activite
			$oldQuartierId =  trim($rue->getQuartierId());
		    $oldQuartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($oldQuartierId);
			$oldQuartier = $oldQuartierObj->getQuartier();
			     // Fin
				 // Cookie utilisé dans la class du formumaire quigarde oldRubriqueId
			$php_oldQuartier_cookie = "php_oldQuartier_cookie";
			$php_oldQuartier_cookievalue = $oldQuartier;
            //echo $oldRubrique." ---";
			$php_oldQuartier_cookie = "php_oldQuartier_cookie";
		    setcookie($php_oldQuartier_cookie, $php_oldQuartier_cookievalue, time() + (86400 * 30), '/');
			//echo $_COOKIE[$php_oldRubrique_cookie];
			// on verifie que le cookie nouveau cookie a deja été mis sur le server sinon on recharge la page pour le faire
			if( $oldQuartier != $_COOKIE[$php_oldQuartier_cookie] )
			{
				return $this->redirect($this->generateUrl('zoom_douala_admin_rue_modifier', array('id' => $id,)));
			}
			// Fin
			// creation du formulaire
			if (!$rue)
			{
				$message='Aucune rue trouvée';
			}
			else
			{
			    $form = $this->createForm(rueForm::class, $rue);
			}
		}
		else //... une nouvelle insertion
		{
			$rue = new Rue();
			$form = $this->createForm(rueForm::class, $rue );
		}

		$form->handleRequest($request);

		if ($form->isValid())  // insertion
		{  	
            $data01 = $form['quartierId']->getData(); // on verifie que le champ Quartier a été modifié avant de persister
			$rubriqueformId = $data01->getId();        
			if($rubriqueformId != 0) // rubrique est obligatoire
			{
			    
				// Id des quartier à partir du nom du quartier avant de flush
			    $quartier = trim($form['quartierId']->getData());
			    $quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
			    $quartierId = $quartierObj->getId();
			    $rue->setQuartierId($quartierId);
				//// on persist la base de donn?e avec les infos du formulaire de modif ou d'ajout
				$rue->setvilleId("1"); //Douala
				$em->persist($rue); 
				$em->flush();
		    
			    // affichage des messages
				if (isset($id))     // insertion nouveau
				{   $nom=$rue->getRue();
					$message_modif = $nom;
					return $this->render('ZoomDoualaBundle:Rue:insererRuePageAdmin.html.twig', array('formajouter' => $form->createView(),'message_modif' => $message_modif));
				}
				else               // modification
				{
					$nom=$rue->getRue();
					$message_new = $nom;
					return $this->render('ZoomDoualaBundle:Rue:insererRuePageAdmin.html.twig', array('formajouter' => $form->createView(),'message_new' => $message_new));
				}
			}
			else
			{
				$dateError = new FormError("choisissez un quartier ici!"); // rubrique non choisis
				$form->get('quartierId')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Rue:insererRuePageAdmin.html.twig', array(
				'formajouter' => $form->createView(),
				)); 
			}
		}
		else
		{
            return $this->render('ZoomDoualaBundle:Rue:insererRuePageAdmin.html.twig', array('formajouter' => $form->createView(),'message' => $message));
		}
	}
///////// Fin rue ajouter/modifier   
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id)
	{
	    $em = $this->container->get('doctrine')->getManager();
	    $rue = $em->find('ZoomDoualaBundle:Rue', $id);
	    if (!$rue) 
		{
            throw new NotFoundHttpException("Rue non trouvée");
        }
        $message = $rue->getRue();
	    $rueId = $id;
		// Update à id=0  des  rueId des activités ayant pour rue id, avant de supprimer
		$query = $em->createQuery('UPDATE ZoomDoualaBundle:Activite a
	             SET a.rueId = 0 WHERE a.rueId = :rueId')->setParameters(array('rueId' => $rueId,));
		$activites = $query->getResult();
		// suppression de la rue
		$em->remove($rue);
        $em->flush();
        return $this->render('ZoomDoualaBundle:Rue:supprimer.html.twig', array('message' => $message));
    }
}