<?php
namespace Zoom\DoualaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\Content;
use Zoom\DoualaBundle\Form\ContentForm;

class ContentController extends Controller
{    
    public function editerAction(Request $request, $id = null)
	{
	    $message='';
		$em = $this->getDoctrine()->getManager();
		if (isset($id)) 
		{
		// modification d'une content existante : on recherche ses donn�es
			$content = $em->find('ZoomDoualaBundle:Content', $id);
			if (!$content)
			{
				$message='Aucune Content trouvee';
			}
		}
		else 
		{
			//... ou ajout d'une nouvelle
			$content = new Content();
		}
		$form = $this->createForm(contentForm::class, $content);	
		$form->handleRequest($request);
		if ($form->isValid())
		{	
			$em->persist($content);
			$em->flush();
			if (isset($id)) 
			{
				$message_modif= $content->getContent();
				return $this->render('ZoomDoualaBundle:Content:modifier.html.twig', array('form' => $form->createView(),'message_modif' => $message_modif));
			}
			else
			{
				$message_new= $content->getContent();
				return $this->render('ZoomDoualaBundle:Content:modifier.html.twig', array('form' => $form->createView(),'message_new' => $message_new));
			}
		}
		else
		{
			return $this->render('ZoomDoualaBundle:Content:modifier.html.twig', array('form' => $form->createView(),'message' => $message));
		}
	}	
	//////////////////////////////////////////
    public function listerAction(Request $request)
	{
	    $em = $this->container->get('doctrine')->getManager();
		$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Content a 
								   WHERE  a.id != 0 
								   ORDER BY a.content ASC');
	    $contents = $query->getResult();
		
// var_dump($contents);
		$count = sizeof($contents);
		
	    if($count>0)
	    {
	        // message
		    $nombre = " ".$count."trouv�s";// nombre de fonctions trouv�s(s)	
		    //IDs to Names
        }
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
		$pagination = $paginator->paginate($contents, $request->query->get('page', 1)/*page number*/, 150/*limit per page*/);
	
	    return $this->render('ZoomDoualaBundle:Content:lister.html.twig', array(
	    'contents' => $contents,
		'pagination' => $pagination,
		'count' => $count,
		));
    }
	//////////////////////////////////////////
    public function supprimerAction($id)
	{
		$em = $this->container->get('doctrine')->getManager();
		$content = $em->find('ZoomDoualaBundle:Content', $id);
	    if (!$content) 
		{
    		throw new NotFoundHttpException("Content non trouv�e");
    	}
   		$message = $content->getContent();
		$contentId = $id;
		// Update � id=0  des activit�s ayant pour content cette content id
		$query = $em->createQuery('UPDATE ZoomDoualaBundle:Activite a
	             SET a.contentId = 0 WHERE a.contentId = :contentId')->setParameters(array('contentId' => $contentId,));
		$activites = $query->getResult();
		//  
   		$em->remove($content);
   		$em->flush();
        return $this->render('ZoomDoualaBundle:Content:supprimer.html.twig', array('message' => $message));
    }
}
