<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\Ads;
use Zoom\DoualaBundle\Form\AdsForm;
use Zoom\StoreBundle\Model\AddDate\AddDate;

class AdsController extends Controller  
{
//////////////////////////////////////////////////////////////
   
////////////////////////////////////////////////////////////////////
    public function listerAction(Request $request)
	{
		$em = $this->container->get('doctrine')->getManager();
		$adsObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Ads a');
		$ads = $adsObj->getResult();
		$count = sizeof($ads);
		
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    // var_dump($ads);
		$pagination = $paginator->paginate($ads, $request->query->get('page', 1)/*page number*/, 50/*limit per page*/);
		
	    if($count > 0)
	    {

		
			// calcul de la duree restante pour chaque ad and put it in an array
			$datesObj = $em->createQuery('SELECT a.startdate, a.duree FROM ZoomDoualaBundle:Ads a') ;
			$dates = $datesObj->getResult();
			$remainingDaysArray = array(); 
			$dateAdd = new AddDate;
			$i = 0;
			$datedepart = 0;
			foreach($dates as $value){
				$datedepart = $value["startdate"];
				$duree = $value["duree"];
				$dateFin = $dateAdd->endCycle($datedepart, $duree);
				$datefinSecondes = strtotime($dateFin);
				$datedujourSecondes =  strtotime(\date('d-m-Y'));
				$reminingSeconde = $datefinSecondes - $datedujourSecondes;
				$remainingDaysArray[$i] = $reminingSeconde / 86400;
				$i++;
			}
		}
		else{
			$remainingDaysArray = array();
			$ads =  array();
		}
		//
	    return $this->render('ZoomDoualaBundle:Ads:lister.html.twig', array(
	    'ads'                => $ads,
		'remainingDaysArray' => $remainingDaysArray,
		'pagination'         => $pagination,
		'count'              => $count,
		));
	}
////////////////////////////////////////////////////////////////////
///////// Ads ajouter/modifier
    public function modifierAction(Request $request, $id = null)
	{
   	    $message = "";
		$titre = "";
		$curentAd =  "";
		$message_new =  "";
		$message_modif =  "";
		$description =  "";

		$em = $this->getDoctrine()->getManager();
		if (isset($id)){ //... une edition
		    $ads = $em->find('ZoomDoualaBundle:Ads', $id);
			$titre="Modifier";
			$curentAd = $ads->getPath();
			$description = $ads->getAdtype()->getDescription();
			if (!$ads)
			{
				$message='Aucune ads trouv�e';
			}
		}
		else{ //... une nouvelle insertion
			$titre = "Ajouter";
			$ads = new Ads();
		}
		// date de debut
		if (!isset($id)){
			$date = \date('d-m-Y');
			$ads->setStartdate($date); 
		}
		// createthe form with the right ads object
		$form = $this->createForm(AdsForm::class, $ads );

		//	handleRequest
		$form->handleRequest($request);

		if ($form->isSubmitted() && $form->isValid()){  // insertion
			$formdataobj = $form->getData();
			// saving uploaded file
			// directory
			$dir = dirname(__FILE__)."/../../../../web/bundles/zoomdouala/images/ads/";
			// Adstype description
			if(isset($id)){
				$description =  $form['adtype']->getData();			
			}
			// file
			$file = $form['path']->getData();

			if($file){
				$originalname = $file->getClientOriginalName();
				// extension
				$ext = $file->guessExtension();
            	// Generate a unique name for the file before saving it
           	 	$fileName = md5(uniqid()).'.'.$ext;
				// current add to show on the page
				$curentAd = $fileName;
				// store the file
				$file->move($dir, $fileName);
				// update object with the new file name
				$formdataobj->setPath($fileName);

			}
			else{ // erreur: ajout d'une publicit� sans image
				if (!isset($id)){
					$message_new =  "Erreur. Veuillez uploader une image publicitaire.";
					return $this->render('ZoomDoualaBundle:Ads:inserer.html.twig', array('formajouter' => $form->createView(),'message' => $message, 'titre' => $titre, 'curent'=>$curentAd, 'description'=>$description, 'message_modif'=>$message_modif, 'message_new'=>$message_new));
				}
				else {
					$formdataobj->setPath($curentAd);
				}
			}
			// save
			$em = $this->getDoctrine()->getManager();
            $em->persist($formdataobj);
			$em->flush();
			// messages
			if (isset($id))     // modification
			{  
				// message � aficher
				$message_modif = "La publicite a bien ete modifiee.";
				$message_new = "";
			}
			else               // insertion nouveau
			{	
				$message_new = "La publicite a bien ete ajoutee.";
				$message_modif = "";
			}
			return $this->render('ZoomDoualaBundle:Ads:inserer.html.twig', array('formajouter' => $form->createView(),'message' => $message, 'titre' => $titre, 'curent'=>$curentAd, 'description'=>$description, 'message_modif'=>$message_modif, 'message_new'=>$message_new));
		}
		else{
            return $this->render('ZoomDoualaBundle:Ads:inserer.html.twig', array('formajouter' => $form->createView(),'message' => $message, 'titre' => $titre, 'curent'=>$curentAd, 'description'=>$description, 'message_modif'=>$message_modif, 'message_new'=>$message_new));
		}
	}
///////// Fin Ads ajouter/modifier   
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id)
	{
	    $em = $this->container->get('doctrine')->getManager();
	    $ads = $em->find('ZoomDoualaBundle:Ads', $id);
	    if (!$ads) 
		{
            throw new NotFoundHttpException("Ads non trouv�e");
        }
        $message = $ads->getAdtype();
	    $adsId = $id;

		//Reperes: Suppression � id=0  des  repereIds des adsId pour les reperes ayant pour ads id, avant de suprimer
		$query = $em->createQuery('DELETE ZoomDoualaBundle:Ads a
	              WHERE a.id = :adsId')->setParameters(array('adsId' => $adsId,));
		$activites = $query->getResult();
		// suppression de la publicit�
        $em->flush();
        return $this->render('ZoomDoualaBundle:Ads:supprimer.html.twig', array('message' => $message));
    }
}