<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;
use Symfony\Component\Serializer\Serializer;
use Zoom\DoualaBundle\Entity\Pgarde;
use Zoom\DoualaBundle\Form\pgardeForm;

class PgardeController extends Controller  
{    
    public function listerAction(Request $request)
	{
		$em = $this->container->get('doctrine')->getManager();
		$query = $em->createQuery('SELECT a.id, a.pgardeid, a.datedebut, a.datefin FROM ZoomDoualaBundle:Pgarde a'); 
	    $PgardesObj = $query->getResult();
		$count = sizeof($PgardesObj);
//echo '<pre>';
//var_dump($PgardesObj);
//echo '</pre>';
	    if($count>0)
	    {   // message
		    $nombre = " ".$count."trouvés"; // nombre de Pgardes trouvés(s)	
		    // creer un objet pgarde de garde pour afficher la liste des pharmacies de garde
		    $i = 0;
			$PgardesTab = array();
			// Array of pgardes
			foreach($PgardesObj AS $values){
				$PgardesTab[$i]['datedebut'] = $values['datedebut'];
				$PgardesTab[$i]['datefin'] = $values['datefin'];
				$PgardesTab[$i]['pgardeid'] = $values['pgardeid'];
				// noms des pharmacies à partir des Pgardeid
			    $activiteObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneById($values['pgardeid']);
			    $Pgarde = $activiteObj->getEntreprise(); // nom de la pharmacie de garde
				$PgardesTab[$i]['pgarde'] = $Pgarde;
				// quartier de la pharmacie
				$PgardeQuartierId = $activiteObj->getQuartierId();
				$PgardeQuartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($PgardeQuartierId);
				$PgardesTab[$i]['quartier'] = $PgardeQuartierObj->getQuartier();
				// id de la pharmacie dans la table Activite
				$PgardesTab[$i]['id'] = $values['id']; // id de la pgarde dans la table pgarde, pour la suppresion
				$i++;
			}
			if($PgardesTab){
				$paginator  = $this->get('knp_paginator');	////// Pagination	   
				$pagination = $paginator->paginate($PgardesTab, $request->query->get('page', 1)/*page number*/, 10/*limit per page*/);
			}	
			else {
				$pagination = NULL;
			}	
        }
	    return $this->render('ZoomDoualaBundle:Pgarde:lister.html.twig', array(
	    'Pgardes' => $PgardesTab,
		'pagination' => $pagination,
		'count' => $count,
		'id' => $id
		));
	}

///////// Pgarde ajouter/modifier
    public function modifierAction(Request $request, $pgardeid = NULL)
	{	
		$em = $this->getDoctrine()->getManager();
		// modification d'une pharmacie de garde
		if (isset($pgardeid)){ 
			$pgardeArray = $em->getRepository('ZoomDoualaBundle:Pgarde')->findByPgardeid($pgardeid);
			if (!$pgardeArray){ // pas de pharmacie vec cet pgardeid
				$message='La pharmacie de garde choisie n\'a pas été trouvée!';
				return new Response('<html><body>'.$message.'</body></html>');
			}
			else{
				// Nom de la pharmacie de garde à la place de son id
				$pgardename = $em->find('ZoomDoualaBundle:Activite', $pgardeid)->getEntreprise();
				$pgarde = $pgardeArray[0]; // on extrait l'objet repository de l'array trouvé plus haut
				$pgarde->setPgardeid($pgardename); // pour l'affichage du formulaire de modif

//				$datedebut = $pgarde->getDatedebut(); // date debut
//				$datedebutOk = $datedebut->format("Y-m-d"); 
//				$pgarde->setDatedebut($datedebutOk);
//				$datefin = $pgarde->getDatefin(); // date fin
//				$datefinOk = $datefin->format("Y-m-d");
//				$pgarde->setDatefin($datefinOk);

				$form = $this->createForm(pgardeForm::class, $pgarde);
	
				$form->handleRequest($request);
				// message à afficher
				// traitement du formulaire

				if ($form->isSubmitted() && $form->isValid()){
					// retrieve form datas
					$datedebut = $form->getData()->getDatedebut(); // date de debut de la garde
					$datefin = $form->getData()->getDatefin(); // date de fin de la garde
					
					// creation des objets des dates à persister
//					$serializer = new Serializer(array(new DateTimeNormalizer()));
//					$datedebutAsObject = $serializer->normalize(new \DateTime($datedebut));
//					$datefinAsObject = $serializer->normalize(new \DateTime($datefin));		
//					$pgarde->setDatedebut($datedebutAsObject); // on remet l'objet
//					$pgarde->setDatefin($datefinAsObject); // on remet l'objet

					$pgarde->setPgardeid($pgardeid); // on remet l'id à la place du nom
					$em->persist($pgarde); // persist
					$em->flush();
				
					$message = 'La pharmacie '.$pgardename.' a bien été modifiée.';
					return $this->render('ZoomDoualaBundle:Pgarde:modifier.html.twig', array('form' => $form->createView(),'message' => $message));
				}// affichage du formulaire
				else {
					$message = 'Modifier de la date de garde de la pharmacie '.$pgardename; 
					return $this->render('ZoomDoualaBundle:Pgarde:modifier.html.twig', array('form' => $form->createView(),'message' => $message));
				}
			}
		}
		else{ // ajout d'une pharmacie dans la liste des pharmacies de gardes
			if ($_POST['selection']){  // Traitement
            	// retrieve form datas
				$pgardename = $_POST['selection'];
				$tab01 = explode('-', $pgardename);
				$pgardeid = trim($tab01[count($tab01)-1]); // id de la pharmacie
				$datedebut = trim($_POST['datedebut']); // date de debut de la garde
				$datefin = trim($_POST['datefin']); // date de fin de la garde
				$datedebutOk = \DateTime::createFromFormat("Y-m-d", $datedebut); 
				$datefinOk = \DateTime::createFromFormat("Y-m-d", $datefin); // string to date
				$Pgarde = new Pgarde;// pgarde object setting
				$Pgarde->setPgardeid($pgardeid);
				$Pgarde->setDatedebut($datedebutOk); //convert string date to date
				$Pgarde->setDatefin($datefinOk);
				$em->persist($Pgarde); // persist
				// saving
				$em->flush();
				// message
				$message = 'La pharmacie de garde '.trim($_POST['selection']).' a été créée';
			}
			else {
				$message = 'definir une pharmacie de garde ici';
			}
			return $this->render('ZoomDoualaBundle:Pgarde:ajouter.html.twig', array('message' => $message));
			// Remarque: le formulaire d'ajout est créé dans la vue avec du Javacript 
		}
	}
///////// Fin Pgarde ajouter/modifier   
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id, $pgarde)
	{
		$em = $this->getDoctrine()->getManager();
		// Object entity to delete
		$todeleteObj = $em->getRepository('ZoomDoualaBundle:Pgarde')->findOneById($id);
		if (!$todeleteObj){
            $message = 'Pharmacie de garde '.$pgarde.' non trouvée';
			return new Response('<html><body>'.$message.'</body></html>');
        }
		else{
			// suppression de la pharmacie de garde
			$em->remove($todeleteObj);
        	$em->flush();
			$message = $pgarde;
        	return $this->render('ZoomDoualaBundle:Pgarde:supprimer.html.twig', array('message' => $message));
		}
    }
}