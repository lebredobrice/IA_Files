<?php
namespace Zoom\DoualaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\Rubrique;
use Zoom\DoualaBundle\Form\RubriqueForm;

class RubriqueController extends Controller
{    
    public function editerAction(Request $request, $id = null)
	{
	    $message='';
		$em = $this->getDoctrine()->getManager();
		if (isset($id)) 
		{
		// modification d'une rubrique existante : on recherche ses donn�es
			$rubrique = $em->find('ZoomDoualaBundle:Rubrique', $id);
			if (!$rubrique)
			{
				$message='Aucune Rubrique trouvee';
			}
		}
		else 
		{
			//... ou ajout d'une nouvelle
			$rubrique = new Rubrique();
		}
		$form = $this->createForm(rubriqueForm::class, $rubrique);	
		$form->handleRequest($request);
		if ($form->isValid())
		{	
			$em->persist($rubrique);
			$em->flush();
			if (isset($id)) 
			{
				$message_modif= $rubrique->getRubrique();
				return $this->render('ZoomDoualaBundle:Rubrique:modifier.html.twig', array('form' => $form->createView(),'message_modif' => $message_modif));
			}
			else
			{
				$message_new= $rubrique->getRubrique();
				return $this->render('ZoomDoualaBundle:Rubrique:modifier.html.twig', array('form' => $form->createView(),'message_new' => $message_new));
			}
		}
		else
		{
			return $this->render('ZoomDoualaBundle:Rubrique:modifier.html.twig', array('form' => $form->createView(),'message' => $message));
		}
	}	
	//////////////////////////////////////////
    public function listerAction(Request $request)
	{
	    $em = $this->container->get('doctrine')->getManager();
		$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Rubrique a 
								   WHERE  a.id != 0 
								   ORDER BY a.rubrique ASC');
	    $rubriques = $query->getResult();
		
// var_dump($rubriques);
		$count = sizeof($rubriques);
		
	    if($count>0)
	    {
	        // message
		    $nombre = " ".$count."trouv�s";// nombre de fonctions trouv�s(s)	
		    //IDs to Names
        }
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
		$pagination = $paginator->paginate($rubriques, $request->query->get('page', 1)/*page number*/, 150/*limit per page*/);
	
	    return $this->render('ZoomDoualaBundle:Rubrique:lister.html.twig', array(
	    'rubriques' => $rubriques,
		'pagination' => $pagination,
		'count' => $count,
		));
    }
	//////////////////////////////////////////
    public function supprimerAction($id)
	{
		$em = $this->container->get('doctrine')->getManager();
		$rubrique = $em->find('ZoomDoualaBundle:Rubrique', $id);
	    if (!$rubrique) 
		{
    		throw new NotFoundHttpException("Rubrique non trouv�e");
    	}
   		$message = $rubrique->getRubrique();
		$rubriqueId = $id;
		// Update � id=0  des activit�s ayant pour rubrique cette rubrique id
		$query = $em->createQuery('UPDATE ZoomDoualaBundle:Activite a
	             SET a.rubriqueId = 0 WHERE a.rubriqueId = :rubriqueId')->setParameters(array('rubriqueId' => $rubriqueId,));
		$activites = $query->getResult();
		//  
   		$em->remove($rubrique);
   		$em->flush();
        return $this->render('ZoomDoualaBundle:Rubrique:supprimer.html.twig', array('message' => $message));
    }
}
