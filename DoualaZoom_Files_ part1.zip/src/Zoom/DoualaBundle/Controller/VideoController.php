<?php
namespace Zoom\DoualaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Filesystem\Filesystem;
use Zoom\DoualaBundle\Entity\Activite;

class VideoController extends Controller
{    
//// Afficher une video //////////////////////////////////////////////////////////
    public function showAction($videoPath = null)
	{
	    $em = $this->getDoctrine()->getManager();
		// nom de l'entreprise qui a cette video
		$entrepriseObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneByPath02($videoPath);
		$entreprise = $entrepriseObj->getEntreprise();
        return $this->render('ZoomDoualaBundle:Video:show.html.twig', array(
		    'videoPath' => $videoPath,
		    'entreprise' => $entreprise,
			 ));
    }
//// Supprimer une video //////////////////////////////////////////////////////////
    public function supprimerAction($videoPath)
	{
		$videoPath = trim($videoPath);
	    //echo $videoPath;
	   	$em = $this->getDoctrine()->getManager();
		// Update � id=Null  des  path02 des activit�s ayant pour video $videoPath, et suppression de la video
		$query = $em->createQuery('UPDATE ZoomDoualaBundle:Activite a
	             SET a.path02 =  NULL WHERE a.path02 =:videoPath')->setParameters(array('videoPath' => $videoPath,));
		$result = $query->getResult();
		$count = sizeof($result);
		//var_dump($videoPath); 
		//echo $count;
		if($count == 1) // video updat� dans l'Activit�
		{
		    //update
			$activites = $query->getResult();  
			//var_dump($activites );
			// suppresssion du fichier video
		    //$fs = new Filesystem();
		    //$fs->remove(array('file', '../../../../../uploads/documents/', $videoPath));
			// url

			$url = __DIR__."/../../../../web/uploads/documents/".$videoPath;
			unlink($url);
			$message = $videoPath;
			return $this->render('ZoomDoualaBundle:Video:remove.html.twig',  array( 'message'=>$message));
		}
		else
		{
		    echo "Video non trouv�e";
		}
		   
	}	
}
