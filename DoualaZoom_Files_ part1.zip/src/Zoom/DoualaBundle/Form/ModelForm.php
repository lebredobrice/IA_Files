<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType; 
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class ModelForm extends AbstractType
{
	public function buildForm(FormBuilderInterface $builder, array $options)
    {   
		$builder
        ->add('rubriqueId', EntityType::class, array
					(
					  'label' => 'Rubrique',
					  'class' => 'ZoomDoualaBundle:Rubrique',
					  'query_builder' => function(EntityRepository $er) {
												return $er->createQueryBuilder('ss')
												->addOrderBy('ss.rubrique', 'ASC');
							 },
					)
			)
        ->add('entrepriseId', EntityType::class, array
					(
						'label' 		=> 'Modele',
						'attr'  		=> array
									(
										'placeholder' => 'Choisissez une entreprise',
										'class'       => 'ZoomUserBundle:User',
									),
						'class'  		=> 'ZoomDoualaBundle:Activite',
						'query_builder' => function(EntityRepository $er) {
												return $er->createQueryBuilder('ss')
												->addOrderBy('ss.entreprise', 'ASC');
							 },
					)
			)
        ->add('companyrepUserid', EntityType::class, array
					(
						'label' => 'Contact',
						'attr'  => array
								(
									'placeholder'=>'Email du contact',
									 'class' => 'ZoomUserBundle:User',
								),
						'class' => 'ZoomUserBundle:User',
					)
			)
        ->add('startdate', TextType::class,	array
					(
						'attr' => array
								(
								   'placeholder'=>'Debut',
								),
					)
			)
		->add('duree', ChoiceType::class, array
					(
						'label'  => 'Durée/mois',
						'choices'=> array
								(
									'1'=>'1', '2'=>'2',	'3'=>'3', '4'=>'4',	'5'=>'5', '6'=>'6', '7'=>'7', '8'=>'8', '9'=>'9', '10'=>'10', '11'=>'11', '12'=>'12'
								),
					)
			)
        ->add('sellid', TextType::class, array
								(
									'attr'=>array
										(
											'placeholder'=>'Id de la vente',
										),
								)
			)
        ->add('active', ChoiceType::class, array
					(
						'choices'=>array
								(
									'oui'=>'1', 'non'=>'0',
								),
					)
			)
		;
    }

	public function getBlockPrefix()
	{
    	return '';
	}
}