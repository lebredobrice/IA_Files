<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class rechercheForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
      $builder
            ->add('motcle', TextType::class, array('label' => false, 'attr' => array('size' => 50, 'style' => ('padding: 2px 2px; line-height: 2px; font-size:20px; border:thin; border-style:solid; border-color:#990000')),));
    }
    
    public function getName()
    {        
        return '';
    }
}