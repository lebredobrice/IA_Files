<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Translation\TranslatorInterface;

class layoutErrorForm extends AbstractType
{
    
	public function __construct(TranslatorInterface $translator = NULL)
    {
        $this->translator = $translator;
    }
	
	public function buildForm(FormBuilderInterface $builder, array $options)
    {    
        $builder
            ->add('nom', TextType::class, array( 'label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'nom',),))
            ->add('email', EmailType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'email',),))
            ->add('lien', TextType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'lien', 'placeholder'=>$_SERVER['SERVER_NAME']),))
		    ->add('message', TextareaType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilAreaForm', 'id'=>'message', 'placeholder'=>$this->translator->trans('Error description'),),))
			->add('verification', CheckboxType::class, array('label' =>false, 'attr'=>array('class'=>'layout_contact_form_verification', 'id'=>'verification',),));
    }

    public function getName()
    {
        return '';
    }
}
