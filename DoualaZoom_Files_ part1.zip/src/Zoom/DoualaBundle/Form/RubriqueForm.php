<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class RubriqueForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {   
		$placeholderRepresentant = 'Choisissez un representant'; 
		$placeholderRubrique = 'Saisissez une rubrique'; 
		$placeholderDescription = 'Description';     
        $builder
            ->add('rubrique', TextType::class, array(
            								   'label'=>false, 
											   'required' => false,
                                               'attr'=>array(
                                                	'placeholder' => $placeholderRubrique,
                                                 )
			  ))
            ->add('description', TextType::class, array(
            									'label'=>false,
												'required' => false,
                                                'attr'=>array(
                                                	 'placeholder' => $placeholderDescription,
                                                 )
			  ));
    }
    
    public function getName()
    {
        return 'Rubrique';
    }
}
