<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;

class layoutContactForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {   
        $builder
            ->add('nom', TextType::class, array( 'label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'nom',),))
            ->add('entreprise', TextType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'entreprise',),))
            ->add('email', EmailType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'email',),))
		    ->add('message', TextareaType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilAreaForm', 'id'=>'message',),))
			->add('verification', CheckboxType::class, array('label' =>false, 'attr'=>array('class'=>'layout_contact_form_verification', 'id'=>'verification',),));
    }
    public function getName()
    {
        return '';
    }
}