<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class TranslationForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {    
        $builder
        ->add('translation', TextType::class, array('label' => false))
		->add('languageid', EntityType::class, array('label' => 'Langue de traduction',
													 'class' => 'Zoom\DoualaBundle\Entity\Language'	))
		;
    }
    
    public function getName()
    {
        return '';
    }
}