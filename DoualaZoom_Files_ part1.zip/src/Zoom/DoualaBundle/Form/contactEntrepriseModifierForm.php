<?php
namespace Zoom\DoualaBundle\Form;

header('Content-type: text/html; charset=ISO-8859-1');

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Translation\TranslatorInterface;
use Zoom\DoualaBundle\Model\Translate\Translate;
use Zoom\DoualaBundle\Model\Languagefromurl\Languagefromurl;

use Zoom\DoualaBundle\Model\Tablearray\Tablearray;

class contactEntrepriseModifierForm extends AbstractType
{

	public function __construct(TranslatorInterface $translator = NULL)
    {
        // initialisation of symfony translator
		$this->translator = $translator;
		
		// initialisation of doualazoom translator
		$language = new Languagefromurl;
		$translate = new Translate;
		
		// valeur actuelle du quartier
		$cookiename = 'oldQuartier';
		$this->oldQuartier = $_COOKIE[$cookiename];
		// valeur actuelle de la rubrique
		$cookiename = 'oldRubrique';
		$this->oldRubrique = ucfirst($_COOKIE[$cookiename]);
		// valeur actuelle de la rubrique id
		$cookiename = 'oldRubriqueId';
		$this->oldRubriqueId = ucfirst($_COOKIE[$cookiename]);
		// nom de l'entreprise à modifier
		$cookiename = "nomEntreprise";
		$this->entrepriseName = $_COOKIE[$cookiename];
		// oldFonction
		$cookiename =  "oldFonction";
		$this->oldFonction = ucfirst($_COOKIE[$cookiename]);
		// valeur actuelle de la fonction id
		$cookiename = 'oldFonctionId';
		$this->oldFonctionId = ucfirst($_COOKIE[$cookiename]);
		// oldVille
		$cookiename =  "oldVille";
		$this->oldVille = $_COOKIE[$cookiename];
		// oldAdsize
		// $cookiename =  "oldAdsize";
		// $this->oldAdsize = ucfirst($_COOKIE[$cookiename]);
    }

	// rubrique translation 
    private function getRubriqueChoices()
    {
		// Create an array of activity sector to fill the choice list for the list box to select on the modification form
			// get current local
		$language = new Languagefromurl;
		$translate = new Translate;
		$choicearraybrut = $translate->getTabletranslation(1, $language->getLanguage()); // 1 is the id of the table Rubrique in tables table
		// get choicetype datas in the proper language
		$rubriqueChoicearray = $choicearraybrut;

			// old value should be first in the array
				
		$rubriqueId = $this->oldRubriqueId;
		$languageId = $language->getLanguage();
		$rubriqueTrans = $translate->getOnetranslation(1, $rubriqueId, $languageId); 
			// translate the previous value
		if($rubriqueTrans){
			$rubrique =  $rubriqueTrans;
		}
		else{ // original french
			$rubrique =  $this->oldRubrique;
		}
			// Actual value of activity sector at the begining of the array
		$oldRubriqueArray = array($rubrique => $this->oldRubriqueId );
		unset($rubriqueChoicearray[$this->oldRubrique]); // avoiding duplication of selected
		$rubriqueChoicearray = $oldRubriqueArray + array_flip($rubriqueChoicearray);
		unset($rubriqueChoicearray["NOUVELLE RUBRIQUE PAS EXISTANTE DANS LA LISTE A PROPOSER (MERCI)"]); // NOUVELLE RUBRIQUE PAS EXISTANTE DANS LA LISTE A PROPOSER (MERCI)
		unset($rubriqueChoicearray[""]); // Empty value)
		//
        return $rubriqueChoicearray;
    }

	// fonction translation 
    private function getFonctionChoices()
    {
		// Create an array of activity sector to fill the choice list for the list box to select on the modification form
			// get current local
		$language = new Languagefromurl;
		$translate = new Translate;
		$languageId = $language->getLanguage();
// echo $languageId;
		$choicearraybrut = $translate->getTabletranslation(2, $languageId); // 2 is the id of the table Fonction in tables table
		// get choicetype datas in the proper language
		$fonctionChoicearray = $choicearraybrut;

			// old value should be first in the array
				
		$fonctionId = $this->oldFonctionId;
		$fonctionTrans = $translate->getOnetranslation(2, $fonctionId, $language->getLanguage()); 
			// translate the previous value
		if($fonctionTrans){
			$fonction =  $fonctionTrans;
		}
		else{ // original french
			$fonction =  $this->oldFonction;
		}
			// Actual value of activity sector at the begining of the array
		$oldFonctionArray = array($fonction => $this->oldFonctionId );
		unset($fonctionChoicearray[$this->oldFonction]); // avoiding duplication of selected
		$fonctionChoicearray = $oldFonctionArray + array_flip($fonctionChoicearray);
		unset($fonctionChoicearray["NOUVELLE RUBRIQUE PAS EXISTANTE DANS LA LISTE A PROPOSER (MERCI)"]); // NOUVELLE RUBRIQUE PAS EXISTANTE DANS LA LISTE A PROPOSER (MERCI)
		unset($fonctionChoicearray[""]); // Empty value)
		//
        return $fonctionChoicearray;
    }

	// Adsize translation
    private function getAdsize()
    {
		$language = new Languagefromurl;
		$translate = new Translate;
		$languageId = $language->getLanguage();
		$choicearraybrut = $translate->getTabletranslation(4, $languageId); // 4 is the id of the table Adsize in tables table
		// get choicetype datas in the proper language
		$adsizeChoicearray = $choicearraybrut;

        // old value should be first
			// remove old value and replace it at the beguining
		//$adsizeId = $adsizeChoicearray[$this->oldAdsize];
		//$oldAdsizeArray = array($this->oldAdsize => $adsizeId);	
		//unset($adsizeChoicearray[$this->oldAdsize]);
		//$adsizeChoicearray = $oldAdsizeArray + array_flip($adsizeChoicearray);
        //return $adsizeChoicearray;
    }

	public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
          ->add('entreprise', TextType::class, array('label'=>false, 'data'=> $this->entrepriseName))
          ->add('bp', TextType::class, array('label'=>false, 'required' => false))
          ->add('telephone01', TextType::class,array('label'=>false, 'required' => true))
          ->add('telephone02', TextType::class, array('label'=>false, 'required' => false))
          ->add('fax', TextType::class, array('label'=>false, 'required' => false))
          ->add('email',  EmailType::class, array('label'=>false, 'required' => false))
          ->add('web',  TextType::class, array('label'=>false, 'required' => false))
          ->add('contact',  TextType::class, array('label'=>false,'required' => false))
		  ->add('fonctionId', ChoiceType::class, [  'choices' => $this->getFonctionChoices(),
													'label' =>false,
													'attr' => array('style' => ('float:left; text-transform:capitalize;')), 
												])
          ->add('villeId',  EntityType::class, array('label' => false, 'class' => 'ZoomDoualaBundle:Ville'))
          ->add('quartierId',  EntityType::class, array(
				'label'=>false, 
				'class' => 'ZoomDoualaBundle:Quartier', 
				'query_builder' => function(EntityRepository $er) {
					         $quartier = $this->oldQuartier;
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.quartier = :quartier THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
							 ->setParameters(array('quartier' => $quartier));
							 }
							 )) 
          ->add('rueId',  TextType::class, array('label'=>false, 'required' => false))
	      ->add('repereId',  TextType::class, array('label'=>false, 'required' => false, ))
		  ->add('rubriqueId', ChoiceType::class, [  'choices' => $this->getRubriqueChoices(),
													'label' =>false,
													'attr' => array('style' => ('float:left; 
																				text-transform:capitalize; '
																				)), 
																	 'placeholder' => null,
												])
          ->add('place', TextType::class, array('label'=>false, 'required' => false))
          ->add('map',  TextType::class, array('label'=>false, 'required' => false))
          ->add('date',  DateType::class, array('label'=>false, 'data' => new \DateTime(), 'widget' => 'single_text', 'format' => 'dd-MM-yyyy', 'attr' => array('style' => ('display:inline'))))
          ->add('rueId_primary_key',  HiddenType::class) // champ ajouté pour la combobox (listbox + textbox)
		  ->add('path01',  FileType::class,  array('attr'=>array('style'=>(' border:none')),'required' => false, 'data_class' =>NULL,'label' => ' '))
		  ->add('path02', FileType::class,  array('attr'=>array('style'=>(' border:none')), 'required' => false, 'data_class' =>NULL,'label' =>' '))
		  ->add('path03', FileType::class,  array('attr'=>array('style'=>(' border:none')),'required' => false, 'data_class' =>NULL,'label' => ' '))
		  ->add('activated', ChoiceType::class, array('attr' => array('style' => ('width:50px;')),'label'  => 'Activer', 'choices' => array('oui' => 'oui', 'non' => 'non') ,))
		  ->add('adsizeId', ChoiceType::class, array(
				'label' =>false,
				'required' => false,
				'choices' => array('0'.$this->translator->trans('month') => 0, 
								   '1'.$this->translator->trans('month') => 1,
								   '2'.$this->translator->trans('month') => 2,
								   '3'.$this->translator->trans('month') => 3,
								   '4'.$this->translator->trans('month') => 4,
								   '5'.$this->translator->trans('month') => 5,
								   '6'.$this->translator->trans('month') => 6,
								   '7'.$this->translator->trans('month') => 7,
								   '8'.$this->translator->trans('month') => 8,
								   '9'.$this->translator->trans('month') => 9,
								   '10'.$this->translator->trans('month') => 10,
								   '11'.$this->translator->trans('month') => 11,
								   '12'.$this->translator->trans('month') => 12,),
				'placeholder' => false,
		))
		->add('alaune', ChoiceType::class, array(
				'mapped'    => false,
				'label'     => false,
				'required'  => false,
				'choices'   => array('0'.$this->translator->trans('month') => 0, 
								   '1'.$this->translator->trans('month') => 1,
								   '2'.$this->translator->trans('month') => 2,
								   '3'.$this->translator->trans('month') => 3,
								   '4'.$this->translator->trans('month') => 4,
								   '5'.$this->translator->trans('month') => 5,
								   '6'.$this->translator->trans('month') => 6,
								   '7'.$this->translator->trans('month') => 7,
								   '8'.$this->translator->trans('month') => 8,
								   '9'.$this->translator->trans('month') => 9,
								   '10'.$this->translator->trans('month') => 10,
								   '11'.$this->translator->trans('month') => 11,
								   '12'.$this->translator->trans('month') => 12,),
				'placeholder' => false,
		))
		;
	
		// effacement du cookie de validation de creation ds cookies dans le contoller
		setcookie('entrepriseId', '', time() - (86400 * 30), '/'); 
    }
    
	
	public function getBlockPrefix()
	{
    	return '';
	}
}