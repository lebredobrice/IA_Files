<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Translation\TranslatorInterface;

use Zoom\DoualaBundle\Model\Translate\Translate;
use Zoom\DoualaBundle\Model\Languagefromurl\Languagefromurl;

use Zoom\DoualaBundle\Model\Tablearray\Tablearray;

class contactEntrepriseAjouterForm extends AbstractType
{
	public function __construct(TranslatorInterface $translator = NULL)
    {
        $this->translator = $translator;
    }

	// rubrique translation 
    private function getRubriqueChoices()
    {
		$language = new Languagefromurl;
		$translate = new Translate;
		$choicearraybrut = $translate->getTabletranslation(1, $language->getLanguage()); // 1 is the id of the table Rubrique in tables table
		// get choicetype datas in the proper language
		$rubriqueChoicearray = array_flip($choicearraybrut);
        // it should return key-value array, example:
        return $rubriqueChoicearray;
    }
	// Fonctions translation
    private function getFonctionChoices()
    {
		$language = new Languagefromurl;
		$translate = new Translate;
		$choicearraybrut = $translate->getTabletranslation(2, $language->getLanguage()); // 2 is the id of the table Fonction in tables table
		// get choicetype datas in the proper language
		$functionChoicearray = array_flip($choicearraybrut);
        // it should return key-value array, example:
        return $functionChoicearray;
    }

	
	public function buildForm(FormBuilderInterface $builder, array $options)
    {
		// quartier par defaut comme placeholder du champ quartier
		$placeholderQuartier = $this->translator->trans('select a district');
		// rubrique par defaut comme placeholder du champ rubrique
		$placeholderRubrique = $this->translator->trans('Select an activity sector');
		// fonction par defaut comme placeholder du champ fonction
		$placeholderFonction = $this->translator->trans('select a position');
		// adsize
		$placeholderAdsize  = $this->translator->trans('select an ad space');
		// nom de l'entreprise à ajouter
		$cookiename = "nomEntreprise";
		$entrepriseName = $_COOKIE[$cookiename];
		// label de la photo de l'entreprise
		$labelPhoto = $this->translator->trans('Picture or location plan of your company');
		// label du logo de l'entreprise
		$labelLogo =  $this->translator->trans('The logo of your company');
		// label de la video de l'entreprise
		$labelVideo =  $this->translator->trans('A video of your company');

        $builder
          ->add('entreprise', TextType::class, array('data'=>$entrepriseName, 'label' =>false))
          ->add('bp', TextType::class, array('label'=>false, 'required' => false))
          ->add('telephone01', TextType::class, array('label'=>false, 'required' => true))
          ->add('telephone02', TextType::class, array('label'=>false,'required' => false))
          ->add('fax', TextType::class, array('label'=>false, 'required' => false))
          ->add('email', EmailType::class, array('label'=>false,'required' => false))
          ->add('web', TextType::class, array('label'=>false, 'required' => false, 'data'=>'http://'))
          ->add('contact', TextType::class, array('label'        => false, 'required' => false))
		  ->add('fonctionId', ChoiceType::class, [ 'required'    => false,
		  										   'choices'     => $this->getFonctionChoices(),
												   'label'       => false,
												   'placeholder' => $placeholderFonction,
												   'attr'        => array('style' => ('float:left;'
																				)), 
												])
          ->add('villeId',  EntityType::class, array(
		  		'label' => false, 
				'class' => 'ZoomDoualaBundle:Ville', ))	
          ->add('quartierId',  EntityType::class, array(
				'label'=>false,
				'class' => 'ZoomDoualaBundle:Quartier', 
				'placeholder' => $placeholderQuartier,
				))
          ->add('rueId',  TextType::class, array('label' =>false, 'required' => false))	
	      ->add('repereId', TextType::class, array('label' =>false, 'required' => false, ))	
          
		  ->add('rubriqueId', ChoiceType::class, [  'choices' => $this->getRubriqueChoices(),
													'label' =>false,
													'placeholder' => $placeholderRubrique,
													'attr' => array('style' => ('float:left;'
																				)), 
												])
		  
          ->add('place', TextareaType::class, array('label' =>false, 'required' => false))
          ->add('map', TextType::class, array('label' =>false, 'required' => false, 'data' => '0, 0'))
          ->add('date', DateType::class, array('data' => new \DateTime(), 'widget' => 'single_text', 'format' => 'dd-MM-yyyy', 'attr' => array('style' => ('display:inline'))))
          ->add('rueId_primary_key', HiddenType::class) // champ ajouté pour la combobox (listbox + textbox)
		  ->add('path01', FileType::class,  array('attr'=>array('style'=>('border:none')),'required' => false, 'data_class' =>NULL,'label' => $labelPhoto.' (jpg, gif, png)'))
		  ->add('path02', FileType::class,  array('attr'=>array('style'=>('border:none')), 'required' => false, 'data_class' =>NULL,'label' => $labelVideo.' (flv, mp4)'))
		  ->add('path03', FileType::class,  array('attr'=>array('style'=>('border:none')),'required' => false, 'data_class' =>NULL,'label' => $labelLogo.' (jpg, gif, png)'))
          ->add('activated', TextType::class, array('required' => false, 'data' => 'no', 'attr' => array('style' => ('width:50px, visibility:hidden'))))
		  ->add('adsizeId', ChoiceType::class, array(
				'label' =>false,
				'required' => false,
				'choices' => array('0'.$this->translator->trans('month') => 0, 
								   '1'.$this->translator->trans('month') => 1,
								   '2'.$this->translator->trans('month') => 2,
								   '3'.$this->translator->trans('month') => 3,
								   '4'.$this->translator->trans('month') => 4,
								   '5'.$this->translator->trans('month') => 5,
								   '6'.$this->translator->trans('month') => 6,
								   '7'.$this->translator->trans('month') => 7,
								   '8'.$this->translator->trans('month') => 8,
								   '9'.$this->translator->trans('month') => 9,
								   '10'.$this->translator->trans('month') => 10,
								   '11'.$this->translator->trans('month') => 11,
								   '12'.$this->translator->trans('month') => 12,),
				'placeholder' => false,
		))
		->add('alaune', ChoiceType::class, array(
				'mapped'    => false,
				'label'     => false,
				'required'  => false,
				'choices'   => array('0'.$this->translator->trans('month') => 0, 
								   '1'.$this->translator->trans('month') => 1,
								   '2'.$this->translator->trans('month') => 2,
								   '3'.$this->translator->trans('month') => 3,
								   '4'.$this->translator->trans('month') => 4,
								   '5'.$this->translator->trans('month') => 5,
								   '6'.$this->translator->trans('month') => 6,
								   '7'.$this->translator->trans('month') => 7,
								   '8'.$this->translator->trans('month') => 8,
								   '9'.$this->translator->trans('month') => 9,
								   '10'.$this->translator->trans('month') => 10,
								   '11'.$this->translator->trans('month') => 11,
								   '12'.$this->translator->trans('month') => 12,),
				'placeholder' => false,
		));
		
		// effaçage des cookies
		setcookie('entrepriseId', '', time() - (86400 * 30), '/'); // effacement du cookie de validation de creation ds cookies dans le contoller
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}
} 