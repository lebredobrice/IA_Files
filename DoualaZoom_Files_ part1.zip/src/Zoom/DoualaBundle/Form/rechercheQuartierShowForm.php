<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Translation\TranslatorInterface;

class rechercheQuartierShowForm extends AbstractType
{

	public function __construct(TranslatorInterface $translator = NULL)
    {
        $this->translator = $translator;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    { 
	  $placeholder =  $this->translator->trans('select a district');
	  
      $builder
             ->add('quartier', EntityType::class, array(
			 			'label' =>false, 
						'attr' => array(
							'style' => ('float:left; text-transform:uppercase; font-size:11px; width:244px; height:31px; margin-left:0; line-height: 2px; border-style:solid; border-color:#fff')), 
							'class' => 'ZoomDoualaBundle:Quartier',
							'placeholder' => $placeholder,
							'label' => false,
							'query_builder' => function(EntityRepository $er) {
					    $quartier = "choisissez un quartier...";
                        return $er->createQueryBuilder('ss')
						->addSelect('CASE WHEN ss.quartier = :quartier THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
							 ->addOrderBy('ss.quartier', 'ASC')
							 ->setParameters(array('quartier' => $quartier));
							 },
						)
					);
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}
}