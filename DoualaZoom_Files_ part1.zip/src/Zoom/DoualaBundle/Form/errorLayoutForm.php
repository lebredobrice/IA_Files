<?php
namespace Zoom\YaoundeBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Bridge\Doctrine\Form\Type\EmailType;
use Symfony\Bridge\Doctrine\Form\Type\TextareaType;

class errorLayoutForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {    
        $builder
            ->add('nom', TextType::class, array( 'label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'nom',),))
            ->add('email', TextType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'nom',),))
            ->add('lien', EmailType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilForm', 'id'=>'nom',),))
		    ->add('message', TextareaType::class, array('label' =>false, 'attr'=>array('class'=>'contactAccueilAreaForm', 'id'=>'nom',),));
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}
}