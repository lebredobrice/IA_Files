<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Symfony\Component\Form\Extension\Core\Type\TextType;

class quartierForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {    

        $builder
            ->add('quartier', TextType::class)
            ->add('villeId', TextType::class, array('required' => false, 'label' => 'Ville', 'data' => 'Douala',))
            ->add('map',TextType::class, array('required' => false, 'data' => '0, 0'))
		    ->add('description',TextType::class, array('required' => false, 'data' => 'description'));
    }
    
    public function getName()
    {
        return '';
    }
}