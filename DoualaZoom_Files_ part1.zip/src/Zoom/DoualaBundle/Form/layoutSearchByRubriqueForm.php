<?php 
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class layoutSearchByRubriqueForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
      $builder
            ->add('rubrique', EntityType::class, array('label' => false, 'data' => 'cherchez une entreprise par rubrique', 'attr' =>  array('style' => ('float:left; width:180px; height:34px; padding-left: 5px; line-height: 2px; font-size:12px; border-style:solid; border-color:#fff; background-color:#FAF8C5; color:#330000, margin-top:0px, margin-left:0px')), 'class' => 'ZoomDoualaBundle:Rubrique', 'label' => false, ));
    }
    
    public function getName()
    {        
        return '';
    }
	
	public function configureOptions(OptionsResolver $resolver)
	{	
    	$resolver->setDefaults(array(
        'data_class' => 'Zoom\DoualaBundle\Entity\Rubrique\Rubrique',
    ));
	}
}