<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

class RueForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
        $builder
            ->add('rue')
            ->add('quartierId')
            ->add('villeId')
            ->add('map_quartier')
            ->add('map_rue')
			->add('map_rue')
			->add('map_quartier')
            ->add('description') ;
    }
    
    public function getName()
    {
        return '';
    }
}