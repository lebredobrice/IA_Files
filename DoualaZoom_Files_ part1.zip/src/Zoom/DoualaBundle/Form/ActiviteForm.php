<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
// use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType; 

use Doctrine\Common\Persistence\ObjectManager;
use Zoom\DoualaBundle\Form\TagsToCollectionTransformer;

class ActiviteForm extends AbstractType
{
    
    private $manager;

    public function __construct(ObjectManager $manager)
    {
        $this->manager = $manager;
    }
    
	public function buildForm(FormBuilderInterface $builder, array $options)
    {   
		$builder
          ->add('entreprise', TextType::class, array('label' =>'Nom'))
          ->add('tags', CollectionType::class, array(
                'entry_type' => 'Zoom\DoualaBundle\Form\TagForm',
                'allow_add' => true,
                'allow_delete' => true,
                'required' => false
           ))
          ->add('images', CollectionType::class, array(
                'entry_type' => 'Zoom\StoreBundle\Form\ImageForm',
                'allow_add' => true,
                'allow_delete' => true,
                'required' => false
           ))
          ->add('bp', TextType::class, array('required' => false))
          ->add('telephone01', TextType::class,array('required' => true))
          ->add('telephone02', TextType::class, array('required' => false))
          ->add('fax', TextType::class, array('required' => false))
          ->add('email', EmailType::class, array('required' => false))
          ->add('web', TextType::class, array('required' => false,))
          ->add('contact', TextType::class, array('label'=>'Nom du contact','required' => false))
          ->add('fonctionId', EntityType::class, array(
				'label' =>'Fonction',
				'class' => 'ZoomDoualaBundle:Fonction', 
			))	
          ->add('villeId',EntityType::class, array('label' =>'Ville', 'class' => 'ZoomDoualaBundle:Ville'))	
          ->add('quartierId', EntityType::class, array(
				'label' =>'Quartier',
				'class' => 'ZoomDoualaBundle:Quartier', 
							))
          ->add('rueId', EntityType::class, array(
				'label' =>'Rue',
				'class' => 'ZoomDoualaBundle:Rue', ))	
	      ->add('repereId', EntityType::class, array(
				'label' =>'Repere',
				'class' => 'ZoomDoualaBundle:Repere', ))	
          ->add('rubriqueId', EntityType::class, array(
				'label' =>'Rubrique',
				'class' => 'ZoomDoualaBundle:Rubrique', 
			))
          ->add('place', TextType::class, array('label' =>'Détail', 'required' => false))
          ->add('map', TextType::class, array('required' => false))
          ->add('date', DateType::class, array('widget' => 'single_text', 'format' => 'dd-MM-yyyy', 'attr' => array('style' => ('display:inline'))))
          ->add('rueId_primary_key', HiddenType::class) // champ ajouté pour la combobox (listbox + textbox)
		  ->add('path01', FileType::class,  array('attr'=>array('style'=>(' border:none')),'required' => false, 'data_class' =>NULL,'label' => 'Photo de l\'entreprise (.jpg)'))
		  ->add('path02', FileType::class, array('attr'=>array('style'=>(' border:none')), 'required' => false, 'data_class' =>NULL,'label' => 'Animation vidéo (.flv)'))
		  ->add('path03', FileType::class, array('attr'=>array('style'=>(' border:none')),'required' => false, 'data_class' =>NULL,'label' => 'Logo de l\'entreprise (.jpg, .gif)'))
		  ->add('activated', ChoiceType::class, array('attr' => array('style' => ('width:80px;')),
			    'label'  => 'Activer',
			    'choices' => array( 
					'oui' => 'oui', 
					'no' => 'no',
				)
		  ,));
          
        // Data Transformer
        $builder
            ->get('tags')
             ->addModelTransformer(new TagsToCollectionTransformer($this->manager));
    }
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Zoom\DoualaBundle\Entity\Activite',
        ));
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}

}