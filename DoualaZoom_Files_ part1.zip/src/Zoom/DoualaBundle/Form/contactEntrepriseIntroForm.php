<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class contactEntrepriseIntroForm extends AbstractType
{
	public function buildForm(FormBuilderInterface $builder, array $options)
    {   
        $builder
		    ->add('entreprise', TextType::Class, array('label' =>false));
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}
}