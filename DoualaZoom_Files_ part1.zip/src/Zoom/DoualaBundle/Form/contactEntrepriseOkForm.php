<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class contactEntrepriseOkForm extends AbstractType
{
	public function buildForm(FormBuilderInterface $builder, array $options)
    {   
	      $builder
          ->add('Prestation', EntityType::class, array(
													'label' =>false,
													'class' => 'ZoomDoualaBundle:Prestation',
													'required' => false,
													'expanded' => true,
													'multiple' => true,
												)
			)	;
    }
 
   
	public function getBlockPrefix()
	{
    	return '';
	}
}