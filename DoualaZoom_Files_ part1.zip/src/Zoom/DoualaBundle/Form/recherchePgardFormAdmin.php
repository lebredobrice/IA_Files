<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class rechercheQuartierFormAdmin extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
      $builder
             ->add('quartier', EntityType::class, array(
				'label'=>false,
				'attr' => array('class' => 'rechercheQuartierFormInputAdmin', 'id'=>'quartier', ),
				'class' => 'ZoomDoualaBundle:Quartier', 
				'query_builder' => function(EntityRepository $er) {
					         $quartier = "choisissez un quartier...";
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.quartier = :quartier THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
                             ->addOrderBy('ss.quartier', 'ASC')
							 ->setParameters(array('quartier' => $quartier));
							 }
							 ));
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}
}