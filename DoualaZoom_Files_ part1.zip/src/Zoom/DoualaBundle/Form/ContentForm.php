<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class ContentForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {   
		$placeholderContent = 'Saisissez un contenue'; 
		$placeholderPage    = 'page';     
        $builder
            ->add('content', TextType::class, array(
            								   'label'    => false, 
											   'required' => false,
                                               'attr'=>array(
                                                	'placeholder' => $placeholderContent,
													'cols'       => 30,
                                                 )
			  ))
            ->add('page', TextType::class, array(
            									'label'=>false,
												'required' => false,
                                                'attr'=>array(
                                                	 'placeholder' => $placeholderPage,
                                                 )
			  ));
    }
    
    public function getName()
    {
        return 'Content';
    }
}
