<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;

class PgardeForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {    
        $builder
            ->add('pgardeid', TextType::class, array(
				  							   'label'=>'Pharmacie',
				  							   'attr'=>(array(
											   			'readonly'=>'readonly'	
						                                ))
				  								))
            ->add('datedebut', DateType::class, array(
												'widget' => 'single_text',
												'html5' => true,
				  							    'label'=>'Date de debut', 
				  							    'attr'=>(array(
				  		                                'style'=>('width:13%;')
						                                ))
				  								))
            ->add('datefin', DateType::class, array(
												'widget' => 'single_text',
												'html5' => true,
				  							    'label'=>'Date de fin', 
				  							    'attr'=>(array(
				  		                                'style'=>('width:13%;')
						                                ))
				  								))
			;
    }
    
    public function getBlockPrefix()
    {
        return '';
    }
}
