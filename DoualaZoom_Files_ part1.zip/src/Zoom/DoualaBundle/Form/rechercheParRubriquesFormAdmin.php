<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class rechercheParRubriquesFormAdmin extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
      $builder
             ->add('rubriques', EntityType::class, array('label' =>'Choisissez une rubrique', 'class' => 'ZoomDoualaBundle:Rubrique', 'label' => false, 'attr' => array('class' => 'form_rechercheParRubrique', 'id'=>'rubriques', ),));
    }

    
	public function getBlockPrefix()
	{
    	return '';
	}
}