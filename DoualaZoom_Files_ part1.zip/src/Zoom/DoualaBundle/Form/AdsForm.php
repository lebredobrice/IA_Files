<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType; 
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class AdsForm extends AbstractType
{
	public function buildForm(FormBuilderInterface $builder, array $options)
    {   
		$builder
         ->add('path', FileType::class, array('attr'=>array('style'=>('border:none')), 'required' => false, 'data_class' =>NULL,'label' => 'Image publicitaire(.jpg)'))
          ->add('pathreplace', TextType::class, array('attr'=>array('style'=>('visibility:hidden')),  'required' => false,))
          ->add('url', TextType::class, array('required' => false, 'label' => 'Url sortant  ', 'attr'=>array('placeholder'=>'http://www...'),))
          ->add('startdate', TextType::class, array('attr'=>array(), 'required' => false, 'label' => 'Date de debut ',))
		  ->add('client', TextType::class, array('required' => true, 'label' => 'Nom sur la pub',))
          ->add('adtype')
          ->add('status')
		  ->add('user')
		  ->add('sell_id', TextType::class, array('required' => false,))
          ->add('duree', TextType::class, array('required' => true, 'label' => 'Duree(mois)',))
		  ->add('active');
    }

    
	public function getBlockPrefix()
	{
    	return '';
	}
}