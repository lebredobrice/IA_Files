<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;

class rechercheActivatedFormAdmin extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
      $builder
             ->add('activated', HiddenType::class, array('data' => 'non', 'label' => false,));
    }
	public function getBlockPrefix()
	{
    	return '';
	}
}