<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Translation\TranslatorInterface;
use Zoom\DoualaBundle\Model\Translate\Translate;
use Zoom\DoualaBundle\Model\Languagefromurl\Languagefromurl;

class rechercheRubriqueFormAdmin extends AbstractType
{
	
	public function __construct(TranslatorInterface $translator = NULL)
    {
        $this->translator = $translator;
    }

    private function getChoices()
    {
		$language = new Languagefromurl;
		$translate = new Translate;
		$choicearraybrut = $translate->getTabletranslation(1, $language->getLanguage()); // 1 is the id of the table Rubrique in tables table
		// get choicetype datas in the proper language
		$choicearray = array_flip($choicearraybrut);
        // it should return key-value array, example:
        return $choicearray;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {   
    	$placeholderRubrique = 'Trouvez une Rubrique'; 
		$builder
	  		->add('rubrique', ChoiceType::class, [  'choices' => $this->getChoices(),
													'label' =>false,
													'placeholder' => $placeholderRubrique,
													'attr' => array(
																'class' => 'form_rechercheParRubrique',
																), 
													],
								array(
									  'attr' => array('style' => ('float:left; text-transform:uppercase; font-size:11px; width:244px; height:31px; margin-left:0; line-height: 2px; border-style:solid; border-color:#fff'),), 
         ));
    }

	public function getBlockPrefix()
	{
    	return '';
	}
}