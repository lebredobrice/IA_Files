<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
class repereForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {    

        $builder
            ->add('repere', TextType::class)
            ->add('villeId', TextType::class, array('required' => false, 'label' => 'Ville', 'data' => 'Douala',))
			->add('quartierId', EntityType::class, array(
		                    'label' =>'Quartier',
		                    'class' => 'ZoomDoualaBundle:Quartier', 
		                    'query_builder' => function(EntityRepository $er) {
		                     $cookiename = "php_oldQuartier_cookie";
					         $quartier = $_COOKIE[$cookiename];	
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.quartier = :quartier THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
							 ->setParameters(array('quartier' => $quartier)); 
                             unset($_COOKIE[$cookiename]);
							 }
							 ))
            ->add('map',TextType::class, array('required' => false, 'data' => '0, 0'))
		    ->add('description',TextType::class, array('required' => false, 'data' => 'description'));
    }
    
    public function getName()
    {
        return '';
    }
}