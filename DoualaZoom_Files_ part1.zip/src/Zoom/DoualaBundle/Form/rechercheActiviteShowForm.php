<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Translation\TranslatorInterface;

class rechercheActiviteShowForm extends AbstractType
{
    
	public function __construct(TranslatorInterface $translator = NULL)
    {
        $this->translator = $translator;
    }
	
	public function buildForm(FormBuilderInterface $builder, array $options)
    {        
      $builder
            ->add('motcle', TextType::class, array('label' => false, 'attr' => array('placeholder'=>$this->translator->trans('type a company name'), 'style' => ('float:left; width:208px; padding-left: 5px; line-height: 2px; font-size:14px; border-style:solid; border-color:#fff')),));
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}
}