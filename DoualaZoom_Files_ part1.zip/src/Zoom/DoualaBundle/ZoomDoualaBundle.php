<?php

namespace Zoom\DoualaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ZoomDoualaBundle extends Bundle
{
}
