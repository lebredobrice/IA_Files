<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

class rechercheActivatedFormAdmin extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
      $builder
             ->add('activated', 'hidden', array('data' => 'non', 'label' => false,));
    }
    public function getName()
    {        
        return '';
    }
}