<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\Fonction;
use Zoom\DoualaBundle\Form\fonctionForm;
use Symfony\Component\Form\FormError;

class fonctionController extends Controller  
{    
//////////////////////////////////////////////////////////////
   
////Lister les fonctions////////////////////////////////////////////////////
    public function listerAction()
	{
	    $em = $this->container->get('doctrine')->getManager();
        $query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Fonction a 
	                   WHERE  a.id != 0'); // exclut l'index 0
	    $fonctions = $query->getResult();
	    $count = sizeof($fonctions);
	    if($count>0)
	    {
	        // message
		    $nombre = " ".$count."trouvés";// nombre de fonctions trouvés(s)	
		    //IDs to Names
        }
		$paginator  = $this->get('knp_paginator');	////// Pagination	   

		$pagination = $paginator->paginate($fonctions, $this->get('request')->query->get('page', 1)/*page number*/, 10/*limit per page*/);
	
	    return $this->render('ZoomDoualaBundle:Fonction:lister.html.twig', array(
	    'fonctions' => $fonctions,
		'pagination' => $pagination,
		'count' => $count,
		));
	}
////////////////////////////////////////////////////////////////////
///////// fonction ajouter/modifier
    public function modifierAction($id = null)
	{
   	    $message="";
		$em = $this->getDoctrine()->getManager();
		if (isset($id)) //... une edition
		{   $fonction = $em->find('ZoomDoualaBundle:Fonction', $id);
		    
			// creation du formulaire
			if (!$fonction)
			{
				$message='Aucun fonction trouvée';
			}
			else
			{
			    $form = $this->createForm(new fonctionForm(), $fonction);
			}
		}
		else //... une nouvelle insertion
		{
			$fonction = new fonction();
			$form = $this->createForm(new fonctionForm(), $fonction );
		}
		
		$request = $this->container->get('request');
		$form->handleRequest($request);

		if ($form->isValid())  // insertion
		{  	
            $em->persist($fonction); 
			$em->flush();
		    // affichage des messages
			if (isset($id))     // insertion nouveau
			{   
			    $nom=$fonction->getfonction();
				$message_modif = $nom;
				return $this->render('ZoomDoualaBundle:Fonction:insererFonctionPageAdmin.html.twig', array(
				'formajouter' => $form->createView(),
				'message_modif' => $message_modif));
			}
			else               // modification
			{
				$nom=$fonction->getfonction();
				$message_new = $nom;
				return $this->render('ZoomDoualaBundle:Fonction:insererFonctionPageAdmin.html.twig', array(
				'formajouter' => $form->createView(),
				'message_new' => $message_new));
			}
		}
		else
		{
            return $this->render('ZoomDoualaBundle:Fonction:insererFonctionPageAdmin.html.twig', array('formajouter' => $form->createView(),'message' => $message));
		}
	}
///////// Fin fonction ajouter/modifier   
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id)
	{
	    $em = $this->container->get('doctrine')->getManager();
	    $fonction = $em->find('ZoomDoualaBundle:Fonction', $id);
	    if (!$fonction) 
		{
            throw new NotFoundHttpException("fonction non trouvée");
        }
        $message = $fonction->getfonction();
	    $fonctionId = $id;
		// Update à id=0  des  fonctionId des activités ayant pour fonction id, avant de supprimer
		$query = $em->createQuery('UPDATE ZoomDoualaBundle:Activite a
	             SET a.fonctionId = 0 WHERE a.fonctionId =:fonctionId')->setParameters(array('fonctionId' => $fonctionId,));
		$activites = $query->getResult();
		// suppression de la fonction
		$em->remove($fonction);
        $em->flush();
        return $this->render('ZoomDoualaBundle:Fonction:supprimer.html.twig', array('message' => $message));
    }
}