<?php

namespace Zoom\UserBundle\Entity;

use FOS\UserBundle\Model\User as BaseUser;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="fos_user")
 */
class User extends BaseUser
{

   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    protected $id;

    /**
     * @ORM\Column(type="string", length=255)
     *
     * @Assert\NotBlank(message="Please enter your name.", groups={"Registration", "Profile"})
     * @Assert\Length(
     *     min=3,
     *     max=255,
     *     minMessage="The name is too short.",
     *     maxMessage="The name is too long.",
     *     groups={"Registration", "Profile"}
     * )
     */
    protected $name;

   /**
 	* @ORM\Column(type="string", nullable = true)
 	*/
    protected $company;

  /**
   * @ORM\Column(name="phone", type="string",nullable = false)
   */
    protected $phone;

   /**
    * @ORM\OneToMany(targetEntity="Zoom\DoualaBundle\Entity\Ads", mappedBy="user")
	*/
	private $userAds;

   /**
    * @ORM\OneToMany(targetEntity="Zoom\StoreBundle\Entity\Sell", mappedBy="userid")
	*/
	private $userSell;

   /**
    * @ORM\OneToMany(targetEntity="Zoom\DoualaBundle\Entity\CompanyRep", mappedBy="companyrepUserid")
	*/
	private $userCompanyrep;


   /**
    * @ORM\OneToMany(targetEntity="Zoom\DoualaBundle\Entity\CompanyAlaune", mappedBy="companyalauneUserid")
	*/
	private $userCompanyalaune;

   /**
    * @ORM\OneToMany(targetEntity="Zoom\DoualaBundle\Entity\CompanyRegistration", mappedBy="companyregistrationUserid")
	*/
	private $userCompanyregistration;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->userAds = new ArrayCollection();
		$this->userSell = new ArrayCollection();
		$this->userCompanyrep = new ArrayCollection();
		$this->userCompanyalaune = new ArrayCollection();
		$this->userCompanyregistration = new ArrayCollection();
		parent::__construct();
    }

   /**
    * Get id
    *
    * @return int
    */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set company
     *
     * @param string $company
     *
     * @return User
     */
    public function setCompany($company)
    {
        $this->company = $company;

        return $this;
    }

    /**
     * Get company
     *
     * @return string
     */
    public function getCompany()
    {
        return $this->company;
    }

    /**
     * Set state
     *
     * @param string $state
     *
     * @return User
     */
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return string
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return User
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return User
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Override setEmail to remove the username properti in fosuserbundle
     *
     */
    public function setEmail($email)
	{
    	$email = is_null($email) ? '' : $email;
   		parent::setEmail($email);
    	$this->setUsername($email);
    	return $this;
	}

    /**
     * Add userAds
     *
     * @param Zoom\DoualaBundle\Entity\Ads $userAds
     *
     * @return userAds
     */
    public function userAds($userAds)
    {
        $this->userAds = $userAds;

        return $this;
    }

    /**
     * Remove userAds
     *
     * @param Zoom\DoualaBundle\Entity\Ads $userAds
     */
    public function removeUserAds($userAds)
    {
        $this->userAds->removeElement($userAds);
    }

    /**
     * Get userAds
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUserAds()
    {
        return $this->userAds;
    }

    /**
     * Add userSell
     *
     * @param Zoom\StoreBundle\Entity\Sell $userSell
     *
     * @return userSell
     */
    public function userSell($userSell)
    {
        $this->userSell = $userSell;

        return $this;
    }

    /**
     * Remove userSell
     *
     * @param Zoom\StoreBundle\Entity\Sell $userSell
     */
    public function removeUserSell($userSell)
    {
        $this->userSell->removeElement($userSell);
    }

    /**
     * Get userSell
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUserSell()
    {
        return $this->userSell;
    }

    /**
     * Add userCompanyrep
     *
     * @param Zoom\DoualaBundle\Entity\CompanyRep $userCompanyrep
     *
     * @return userCompanyrep
     */
    public function userCompanyrep($userCompanyrep)
    {
        $this->userCompanyrep = $userCompanyrep;

        return $this;
    }

    /**
     * Remove userCompanyrep
     *
     * @param Zoom\StoreBundle\Entity\Sell $userCompanyrep
     */
    public function removeUserCompanyrep($userCompanyrep)
    {
        $this->userCompanyrep->removeElement($userCompanyrep);
    }

    /**
     * Get userCompanyrep
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUserCompanyrep()
    {
        return $this->userCompanyrep;
    }
	
    /**
     * Add userCompanyalaune
     *
     * @param Zoom\DoualaBundle\Entity\CompanyAlaune $userCompanyalaune
     *
     * @return userCompanyalaune
     */
    public function userCompanyalaune($userCompanyalaune)
    {
        $this->userCompanyalaune = $userCompanyalaune;

        return $this;
    }

    /**
     * Remove userCompanyalaune
     *
     * @param Zoom\StoreBundle\Entity\CompanyAlaune $userCompanyalaune
     */
    public function removeUserCompanyalaune($userCompanyalaune)
    {
        $this->userCompanyalaune->removeElement($userCompanyalaune);
    }

    /**
     * Get userCompanyalaune
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUserCompanyalaune()
    {
        return $this->userCompanyalaune;
    }

    /**
     * Add userCompanyregistration
     *
     * @param Zoom\DoualaBundle\Entity\CompanyRegistration $userCompanyregistration
     *
     * @return userCompanyregistration
     */
    public function userCompanyregistration($userCompanyregistration)
    {
        $this->userCompanyregistration = $userCompanyregistration;

        return $this;
    }

    /**
     * Remove userCompanyregistration
     *
     * @param Zoom\StoreBundle\Entity\Sell $userCompanyregistration
     */
    public function removeUserCompanyregistration($userCompanyregistration)
    {
        $this->userCompanyregistration->removeElement($userCompanyregistration);
    }

    /**
     * Get userCompanyregistration
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUsercompanyregistration()
    {
        return $this->userCompanyregistration;
    }
}
