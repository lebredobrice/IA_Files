<?php

namespace Zoom\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class TokenController extends Controller
{
	public function getTokenAction(){
    	return new Response($this->get('security.csrf.token_manager')->getToken('authenticate')->getValue());
	}
}