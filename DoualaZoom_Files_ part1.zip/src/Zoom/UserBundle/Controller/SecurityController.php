<?php

namespace Zoom\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;

class SecurityController extends Controller
{

    public $link;
	public $isadmin;
	public $login_check;
	
	public function __construct()
    {
		// admin or user login
		$this->link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";// full url
		$linktable = explode('/', $this->link);
		if(strpos($this->link,'admin')){
			$this->login_check = "admin_login_check";
			$this->isadmin = 'adminLogin';
		}
		else{
			$this->login_check = "login_check";
			$this->isadmin = 'login';
		}
    }

	public function loginAction(Request $request)
	{
        $authenticationUtils = $this->get('security.authentication_utils');
        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();
        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();
		return $this->render('ZoomUserBundle:Security:'.$this->isadmin.'.html.twig', 
		    	array(
                	// last username entered by the user
                	'last_username' => $lastUsername,
                	'error'         => $error,
					'login_check'   => $this->login_check,
        		)
    	);	
	}
}
