<?php 

namespace Zoom\UserBundle\EventListener;

use FOS\UserBundle\FOSUserEvents;
use FOS\UserBundle\Event\FilterUserResponseEvent;
use FOS\UserBundle\Event\FormEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Sensio\Bundle\FrameworkExtraBundle\EventListener\SecurityListener;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Listener to send notification to admin when user registration detected
 */
class RegistrationCompletedListener implements EventSubscriberInterface
{
    protected $mailer;

    public function __construct(\Swift_Mailer $mailer)
    {
        $this->mailer = $mailer;

    }

    /**
     * {@inheritDoc}
     */
    public static function getSubscribedEvents()
    {
        return array(
            FOSUserEvents::REGISTRATION_SUCCESS => 'onRegistrationSuccess',
        );
    }

    public function onRegistrationSuccess(FormEvent $event)
    {

		$user = $event->getForm()->getData();
        
		$from_email = "info@doualazoom.com";
        $from_name  = "DoualaZoom.com";
		$from = array($from_email => $from_name);
        
        // Mail to admin
        $to01 = "info@doualapages.com";
        $to02 = "yaosoft@hotmail.com";
        // $to = array($to01, $to02);
        $to = array($to01);
        $message = \Swift_Message::newInstance()
                ->setSubject($user->getName(). " has registered on doualazoom.com")
                ->setFrom( $from )
                ->setTo( $to )
                ->setBody("Hello admin, ".$user->getName(). " has registered on <a href='http://doualazoom.com'>doualazoom.com</a>")
			;
		$message->setContentType("text/html");
        $this->mailer->send($message);

		// Mail to the user
        $to01 = $user->getEmail();
        // $to02 = "yaosoft@hotmail.com";
        $to = array($to01);
        $message = \Swift_Message::newInstance()
                ->setSubject(" Welcome to DoualaZoom.com")
                ->setFrom( $from )
                ->setTo( $to )
                ->setBody("Hello ".$user->getName(). ", welcome to <a href='https://doualazoom.com'>doualazoom.com</a>")
			;
			$message->setContentType("text/html");
            $this->mailer->send($message);

    }
}