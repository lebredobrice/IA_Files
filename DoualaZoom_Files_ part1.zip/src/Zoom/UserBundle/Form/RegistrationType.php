<?php
 
namespace Zoom\UserBundle\Form;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class RegistrationType extends AbstractType
{
   public function buildForm(FormBuilderInterface $builder, array $options)
   {
       $builder->add('name');
       $builder->add('company', TextType::class, array(
	   										 'required'   => false,
	   ));
       $builder->add('email' );
       $builder->add('plainPassword', RepeatedType::class, array(
    		'type' => PasswordType::class,
    		'invalid_message' => 'The password fields must match.',
    		'required' => true,
		));

	   $builder->add('phone');
 	   $builder->remove('username');

   }
 
   public function getParent()
 
   {
       return 'FOS\UserBundle\Form\Type\RegistrationFormType';
   }
 
   public function getBlockPrefix()
 
   {
       return 'app_user_registration';
   }
}
