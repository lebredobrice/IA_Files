<?php

namespace Zoom\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ZoomUserBundle extends Bundle
{
    public function getParent(){
        return 'FOSUserBundle';
    }
}
