<?php
namespace Zoom\StoreBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType; 
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Translation\TranslatorInterface;
use Zoom\DoualaBundle\Model\Translate\Translate;
use Zoom\DoualaBundle\Model\Languagefromurl\Languagefromurl;
use Zoom\DoualaBundle\Entity\Activite;

class CompanyRepModifForm extends AbstractType
{

	public function __construct(TranslatorInterface $translator = NULL)
    {
        $this->translator = $translator;
    }

    private function getRubriqueChoices()
    {
		$language = new Languagefromurl;
		$translate = new Translate;
		$choicearraybrut = $translate->getTabletranslation(1, $language->getLanguage()); // 1 is the id of the table Rubrique in tables table
		// get choicetype datas in the proper language
		$rubriqueChoicearray = array_flip($choicearraybrut);
        // it should return key-value array, example:
        return $rubriqueChoicearray;
    }

	public function buildForm(FormBuilderInterface $builder, array $options)
    {   
		$builder
          ->add('rubriqueId', ChoiceType::class, array(
		  										 'placeholder' => '',
		  										 'choices'     => $this->getRubriqueChoices(),
												 'label'       => false,
												 'attr'        => array('style' => ('float:left; text-transform:uppercase;')), 
				))
          ->add('companyrepUserid')
          ->add('entrepriseId', EntityType::class, array( 
		  										   'class'       => Activite::class, ))
          ->add('startdate')
		  ->add('duree')
          ->add('sellid')
          ->add('active');
    }

    
	public function getBlockPrefix()
	{
    	return '';
	}
}