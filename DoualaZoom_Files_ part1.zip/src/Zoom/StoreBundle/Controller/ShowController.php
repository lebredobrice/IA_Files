<?php

namespace Zoom\StoreBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Translation\TranslatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Zoom\DoualaBundle\Entity\Ads;
use Zoom\DoualaBundle\Entity\CompanyRep;
use Zoom\StoreBundle\Entity\Sell;
use Zoom\StoreBundle\Model\AddDate\AddDate;
use Zoom\StoreBundle\Form\CompanyRepModifForm;
use Zoom\StoreBundle\Form\imageForm;
use Zoom\DoualaBundle\Entity\Activite;
use Zoom\StoreBundle\Entity\Image;

class ShowController extends Controller 
{
   public function showcaseAction()
    {
		$translator = $this->get('translator');
		
		$em = $this->getDoctrine()->getManager();
		// get name, price and description of showcased ads items. Ignore the other (model, registration)
		$namePriceArray = array();
		$adsNamePriceDescObj = $em->createQuery('SELECT a.adsname, a.price, a.description, a.curency
												 FROM ZoomDoualaBundle:Adstype a
												 WHERE a.maxadstoanim > 1'); // >1 to pick only ads (top, tour, ets)
		$adsNamePriceDesc = $adsNamePriceDescObj->getResult();
		// set descriptions translation
		foreach($adsNamePriceDesc as $key=>&$val01){
			$descriptionSource = trim(preg_replace( "/\r|\n/", "", $val01['description'] )); // remove line space
// 			var_dump($descriptionSource);
			$description = $translator->trans($descriptionSource);
			$val01['description'] = $description;
		}
		// locals datas
		$localObj = $em->createQuery('SELECT a.ville, a.pays, a.indicatif, a.email, a.phone, a.curency, a.code
									  FROM ZoomDoualaBundle:Locale a')
									  ->setMaxResults(1);
		$local = $localObj->getResult();
		if($_POST){
			$adsNamePriceDescObj = $em->createQuery('SELECT a.adsname, a.price, a.description, a.curency
												 FROM ZoomDoualaBundle:Adstype a'); // > pick all ad type
			$adsNamePriceDesc = $adsNamePriceDescObj->getResult();
			// array of items name
			$itemsName = array();
			foreach($adsNamePriceDesc as $key=>$value){
				array_push($itemsName, $value['adsname']);
			}
			// array of names of  selected ads
			$selectItems = array();
			foreach($itemsName as $key=>$value){
				if(isset($_POST['choice_'.$value])){
					array_push($selectItems, $value);
				}
			}
			// array of properties of each selected ad (adsname, startdate, duration, price/mount, amount)
			$checkoutLines = array();
			$i = 0;
			foreach( $selectItems as $key => $value ){
				$checkoutLines[$i]['adsname']   = $value;
				$checkoutLines[$i]['startdate'] = $_POST['date_'.$value];
				$checkoutLines[$i]['duration']  = $_POST['duration_'.$value];
				$checkoutLines[$i]['amount']    = intval(str_replace(' ', '', $_POST['choice_'.$value]))*intval(trim($_POST['duration_'.$value]));
				// price/month
				foreach($adsNamePriceDesc as $key01=>$value01){
					if($checkoutLines[$i]['adsname'] == $value01['adsname']){
						$checkoutLines[$i]['price'] = $value01['price'];
					}
				}// not found
				if(!$checkoutLines[$i]['adsname']){
					return new response("Price error. <a href='history.back()'>back</a>");
				}
				// case of model ad
				if( isset($_POST['company']) || isset($_POST['alaune']) ){
					// company id
					$companyString = $_POST['company'];
					$company_tab   = explode("-", $companyString);
					if(isset($company_tab[count($company_tab)-1])){
						$entreprise_id = trim($company_tab[count($company_tab)-1]);
						$checkoutLines[$i]['entreprise_id'] = $entreprise_id;
					}
					else{
						return new response("Company name error <a href='history.back()'>back</a>");
					}
				}
				// case of company representant store
				if( isset( $_POST['rubriqueId'] ) ){
					// rubrique id
					 $rubriqueId    = $_POST['rubriqueId'];
					 $checkoutLines[$i]['sector_id'] = $rubriqueId;
				}
				// case of a company registration 
				if( isset($_POST['registration']) ){
					$checkoutLines[$i]['registration'] = $_POST['registration'];
				}
				$i++;
			}
// var_dump($_POST);
// var_dump($checkoutLines);
// return new response("POST");
			// calcul du total
			$total = 0;
			foreach( $checkoutLines as $key=>$value ){
				$total += $value['amount'];
			}

			// serialisation des ligne d'achat avant leur envoie à la page de paiement pour affichage de la facture et insertion en base de donnée
			$serializedCheckout = serialize($checkoutLines);
			$serializedLocal    = serialize($local);
			$serializedTotal    = serialize($total);
			


			// chosen paiement methode
			if($_POST['paiementoption'] == 'mobile'){
				// list mobile money service
				$mobile    = "mobile";
				$activated = "yes";
				return $this->redirectToRoute('store_paymobile', array(
														  'total'           	=> $serializedTotal,
														  'local'           	=> $serializedLocal,
														  'checkoutLines'   	=> $serializedCheckout
				));
			}
			else if ($_POST['paiementoption'] == 'paypal'){
				//is user is authenticated
				return $this->redirectToRoute('store_paypaypal', array(
														  'total'           => $serializedTotal,
														  'local'           => $serializedLocal,
														  'checkoutLines'   => $serializedCheckout
				));
			}
			else if ($_POST['paiementoption'] == 'card'){
//				return $this->redirectToRoute('store_paycard',  
//										array('total'           => $serializedTotal,
//									  		  'local'           => $serializedLocal,
//											  'checkoutLines'   => $serializedCheckout
//				));

				return $this->redirectToRoute('store_paypaypal', 
										array('total'           => $serializedTotal,
									  		  'local'           => $serializedLocal,
											  'checkoutLines'   => $serializedCheckout
				));
			}
			else{
				return new response("Payement method error <a href='history.back()'>back</a>");
			}
		}
		else{
			return $this->render('ZoomStoreBundle:Show:showcase.html.twig', array(
								 'adsNamePriceDesc' => $adsNamePriceDesc,
								 'local'            => $local));
		}
    }

	// mobile paiement page
	public function paymobileAction($total, $local, $checkoutLines){
		// mobile paiement list and providers with their mackey and merchand id and other infos
		$em = $this->getDoctrine()->getManager();
		$mobilePaiementList    = array();
		$mobile    = "mobile";
		$activated = "yes";
		$mobilePaiementListObj = $em->createQuery('SELECT a 
												   FROM ZoomStoreBundle:Pmethod a 
												   WHERE  a.type   =:mobile
												   AND    a.activated  =:activated')
													   ->setParameters(array('mobile'    => $mobile,
													   						 'activated' => $activated)) ;
		$mobilePaiementList    = $mobilePaiementListObj->getResult();
//		$mackey = "R1RF1857PLB9ERS62TALORELCBHI4KJ1LGGMOLSKCASP7R29QBTL8DDJOT7RKQRCDE4753QHCPDIMEQJOPB39NM3NTTEPRQ9CTGH3D4E8G31TSKOO1R4OJ6II62E4SMFS821K6ESLHSLGJGA"; 
//		$merchantId           = 2657;
		$transactionReference = "REF".time();
		$itemId               = "ITEM".time();
		$itemName             = "ITEMNAME".time();
		$usermail   		  = $this->getUser()->getUsername();
		$username   		  = $this->getUser()->getName();
		// site datas (email, sitename, ...)
		$siteData = $this->getLocale();

		return $this->render('ZoomStoreBundle:Show:payMobile.html.twig', 
								array(
									  'total'    	  			=> unserialize($total),
									  'local'    	  			=> unserialize($local),
									  'checkoutLines' 			=> unserialize($checkoutLines),
									  'mobilePaiementList'		=> $mobilePaiementList,
									  'transactionReference'	=> $transactionReference,
									  'itemId'					=> $itemId,
									  'itemName'				=> $itemName,
									  'username'				=> $username,
									  'email'					=> $usermail,
									  'siteData'				=> $siteData,
									)
							);
	}
	// paypal paiemet page
	public function paypalAction($total, $local, $checkoutLines){
		//convert total in Euro for paypal with Fixer API
		//$acces_key "e91a2d8ab15c1c8728c7126cd5416146";
		$local   = unserialize($local);
		$from    = $local[0]["curency"]; // local currency
		$to      = "EUR"; // paypal account currency
		$amount  = unserialize($total);		
		//ssl security hole
		//$arrContextOptions=array(
    	//					"ssl"=>array(
        //								"verify_peer"=>false,
        //								"verify_peer_name"=>false,
   		//						 ),
		//);
		//$data = file_get_contents("http://data.fixer.io/api/?acces_key=$acces_key?amount=$amount&from=$from&to=$to", false, stream_context_create($arrContextOptions));
//		var_dump($data);
		//preg_match("/<span class=bld>(.*)<\/span>/",$data, $converted);
		//$total_euro = preg_replace("/[^0-9.]/", "", $converted[1]);
		$euRate     = 667;
		$total_euro = round($amount/$euRate,2);
		// frendly currency name
		if($from == "XAF"){
			$fancyCurency = "FCFA";
		}
		else{
			$fancyCurency = $local[0]["curency"];
		}
		//
		return $this->render('ZoomStoreBundle:Show:payPaypal.html.twig', 
								array('total'     	  => unserialize($total),
									  'local'    	  => $local,
									  'checkoutLines' => unserialize($checkoutLines),
									  'total_euro'    => $total_euro,
									  'fancyCurency'  => $fancyCurency,
		));
	}
	// card
	public function paycardAction($total, $local, $checkoutLines){
		return $this->render('ZoomStoreBundle:Show:payCard.html.twig', 
								array('total'    	  => unserialize($total),
									  'local'    	  => unserialize($local),
									  'checkoutLines' => unserialize($checkoutLines),
		));
	}

	// billing

	public function checkoutBillAction($checkoutLines, $local){
// var_dump($checkoutLines);
// return new response("checkoutLines...");
		return $this->render('ZoomStoreBundle:Show:checkoutBill.html.twig', 
								array('checkoutLines' => $checkoutLines,
									  'local'		  => $local,
							));
	}

public function checkoutAction(){
        // store the data in the 'sell' and the 'ad', the 'model' or the 'registration' table
		// create a sell id
		$em = $this->getDoctrine()->getManager();
		$characters = "0123456789abcdefghijklmnlopqrstuvwxyz";
		$random_string_length = 25;
 		$max = strlen($characters) - 1;
		$sellid = "";
 		for ($i = 0; $i < $random_string_length; $i++) {
      	    $sellid .= $characters[mt_rand(0, $max)];
		}
		// retrieve all datas
		$sell = new sell;

        if( isset( $_REQUEST['pmethod'] ) ){
//		var_dump($_POST);
		// retrieve datas
		    // sell id
			$sell->setSellid($sellid);
			// total
			$sell->setTotal($_REQUEST['total']);
			// user id repository
			$id = $this->get('security.token_storage')->getToken()->getUser()->getId();
			$userObj = $em->getRepository('ZoomUserBundle:User')->findOneById($id);
			$sell->setUserid($userObj);
			// paiement method
			$pmethodObj =  $em->getRepository('ZoomStoreBundle:Pmethod')->findOneByPaiement($_REQUEST['pmethod']);
			$sell->setPmethodid($pmethodObj);
			// sell date
			$sell->setSelldate(\date("d-m-Y"));
			// sell description
				// ads types list
			$description = "";				
			$adstypesObj = $em->createQuery('SELECT a.adsname 
										     FROM ZoomDoualaBundle:Adstype a');
			$adstypes = $adstypesObj->getResult();
			//recherche des data dans les lignes d'achat
			$lines = array();
			$i = 0;
			$found = false;

			
			foreach($adstypes as $key=>$value){
				foreach($_REQUEST as $key01 => $value01){
					if(strpos($key01, 'line_'.$value["adsname"].'_name') === 0){
						$lines[$i]['adsname'] = $value01;
						$found = true;
					}
					if(strpos($key01, 'line_'.$value["adsname"].'_price') === 0){
						$lines[$i]['price'] = $value01;
					}
					if(strpos($key01, 'line_'.$value["adsname"].'_duration') === 0){
						$lines[$i]['duration'] = $value01;
					}
					if(strpos($key01, 'line_'.$value["adsname"].'_amount') === 0){
						$lines[$i]['amount'] = $value01;
					}
					if(strpos($key01, 'line_'.$value["adsname"].'_startdate') === 0){
						$lines[$i]['startdate'] = $value01;
					}
					// case of model company ad
					if(isset($_REQUEST['entreprise_id'])){
						$lines[$i]['entreprise_id'] = $_REQUEST['entreprise_id'];
					}
					if(isset($_REQUEST['sector_id'])){
						$lines[$i]['sector_id'] = $_REQUEST['sector_id'];
					}
					// case of company registration
					if(isset($_REQUEST['registration'])){
						$lines[$i]['registration'] = $_REQUEST['registration'];
					}
				}
				if($found == true){
					$i++;
					$found = false;
				}
			}
//var_dump($_REQUEST);
//return new response("_REQUEST...");

// certain types de pub ne peubent avoir u'une ligne, donc on limite  le nombre de ligne à 1 pour éviter erreurs
		if( $lines[0]['adsname'] == "modele" ||  $lines[0]['adsname'] == "alaune" || $lines[0]['adsname'] == "registration" ){
			$newlines = $lines[0];
			$lines = array();
			array_push( $lines, $newlines );
		}
// pour la table sell
			// create description text
			for($i = 0; $i < count($lines); $i++){
				$description .= $lines[$i]['adsname']."--".$lines[$i]['price']."--".$lines[$i]['startdate']."--".$lines[$i]['amount']."--".$lines[$i]['duration'].'***';
			}
			$sell->setDescription($description);
			$em->persist($sell);
			$em->flush($sell);
			$batchSize = 20;
// var_dump($lines[0]['adsname']);
// pour la table ad ou model ou registration
			if( $lines[0]['adsname'] == "modele" ){
				$entity = "Zoom\DoualaBundle\Entity\CompanyRep";
			}			
			else if( $lines[0]['adsname'] == "alaune" ){
				$entity = "Zoom\DoualaBundle\Entity\CompanyAlaune";
			}
			else if( $lines[0]['adsname'] == "registration" ){
				$entity = "Zoom\DoualaBundle\Entity\CompanyRegistration";
			}
			else{
				$entity = "Zoom\DoualaBundle\Entity\Ads";
			}
// var_dump( $entity );
// return new response("stop...");
			for ( $i = 1; $i <= count($lines); ++$i ) {
				$ads = new $entity;
   				// user
				if( method_exists( $ads, 'setUser' ) ){
					$ads->setUser( $userObj );
				}
				if( method_exists( $ads, 'setCompanyrepUserid' ) ){ // case entity is CompanyRep
					$ads->setCompanyrepUserid($userObj);
				}
				if( method_exists( $ads, 'setCompanyalauneUserid' ) ){ // case entity is Alaune
					$ads->setCompanyalauneUserid($userObj);
				}
				if( method_exists( $ads, 'setcompanyregistrationUserid' ) ){ // case entity is setCompanyrepUserid
					$ads->setcompanyregistrationUserid($userObj);
				}
				
				// start date
				$ads->setStartdate( $lines[$i-1]['startdate'] );
				// ads type
				if( method_exists( $ads, 'setAdtype' ) ){
					$adstypeObj = $em->getRepository( 'ZoomDoualaBundle:Adstype' )->findOneByAdsname($lines[$i-1]['adsname']);
					$ads->setAdtype($adstypeObj);
				}
				// client (company name)
				if( method_exists( $ads, 'setClient' ) ){
					$ads->setClient( $userObj->getCompany() );
				}
				// status
				// client (company name)
				if( method_exists( $ads, 'setStatus' ) ){
					$statusObj = $em->getRepository( 'ZoomDoualaBundle:Adstatus' )->findOneById( 1 );
					$ads->setStatus( $statusObj );
				}
				// sellid
				$ads->setSellid( $sellid );
				// duree
				$ads->setDuree( $lines[$i-1]['duration'] );
				// active
				$ads->setActive(0);
				// model ad or registration
				if( isset( $lines[$i-1]['entreprise_id'] ) ){
					$entrepriseId = $lines[$i-1]['entreprise_id'];
					$entrepriseObj = $em->getRepository( 'ZoomDoualaBundle:Activite' )->findOneById( $entrepriseId );
					$ads->setEntrepriseId( $entrepriseObj );
				}
				if( isset( $lines[$i-1]['sector_id'] ) ){
					$rubriqueId = $lines[$i-1]['sector_id'];
					$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
					$ads->setRubriqueId($rubriqueObj);
				}
				// $ads->setUrl("#");
   				$em->persist($ads);
   				if( ( $i % $batchSize ) === 0 ) {
       				$em->flush();
       				$em->clear(); // Detaches all objects from Doctrine!
   				}
			}

			$em->flush(); // Persist objects that did not make up an entire batch
			$em->clear();
			
			return $this->redirectToRoute('store_thankyou', 
							array('checkoutLines' =>  serialize($lines),
								  'pmethod'		  =>  $_REQUEST['pmethod'], 
								  'total'         =>  $_REQUEST['total'].$_REQUEST['curency'],
			), 301);
		}
		else {
			return new response("Paiement method not found. <a href='history.back()'>back</a>");
		}
	}

	public function thankyouAction($checkoutLines, $pmethod, $total){
		$translator = $this->get('translator');
		if($this->getUser()){
			$usermail   = $this->getUser()->getUsername();
			$username   = $this->getUser()->getName();			
			$from_name  = "DoualaZoom.com";
			$from_email = "info@doualazoom.com";
			$from = array($from_email => $from_name);
			
			// sitename, email, pays...
			$siteData = $this->getLocale();
			// get site data values for email.txt.twig
			$sitetitle = $siteData['title'];
			$siteurl   = $siteData['url'];
			$sitename  = $siteData['name'];
		
			// send mail to admin
			try{
				$to01 = "info@doualapages.com";
				$to02 = "courrier@abidjanzoom.com";
				$to = array($to01, $to02);
				$message = \Swift_Message::newInstance()
         		 	->setSubject($username.' a fait un achat sur DoualaZoom.com')
            		->setFrom($from)
            		->setTo($to)
            		->setBody($this->renderView('ZoomStoreBundle:Email:adminSellNotification.txt.twig', array
													(
														'checkoutLines' => unserialize($checkoutLines), 
														'usermail'      => $usermail,
														'username'      => $username,
														'total'         => $total,
														'sitetitle'     => $sitetitle,
														'siteurl'       => $siteurl,
														'sitename'      => $sitename,
														'pmethod'       => $pmethod,
												)
											) , 'text/html');
				$send = $this->get('mailer')->send($message, $errors); // envoie du mail des l'admin
			}
			catch (\Swift_TransportException $STe)
			{
				$string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
	 			echo "\n";
	 			echo "send mail to info@doualazoom.com exeption: $string \n";
			}
			// send mail to the user
			try{
				$to = $usermail;
				$message = \Swift_Message::newInstance()
         		 	->setSubject($translator->trans('Thank you for your purchase'))
            		->setFrom($from)
            		->setTo($to)
            		->setBody($this->renderView('ZoomStoreBundle:Email:userSellNotification.txt.twig', array(
							                    'checkoutLines' => unserialize($checkoutLines), 
												'usermail'      => $usermail,
												'username'      => $username,
												'total'         => $total,
												'sitetitle'     => $sitetitle,
												'siteurl'       => $siteurl,
												'sitename'      => $sitename,
												'pmethod'       => $pmethod )) , 'text/html');
				$send = $this->get('mailer')->send($message, $errors); // envoie du mail des l'admin
			}
			catch (\Swift_TransportException $STe)
			{
				$string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
	 			echo "\n";
	 			echo "send mail to info@doualazoom.com exeption: $string \n";
			}
			return $this->render('ZoomStoreBundle:Show:thankyou.html.twig', 
										array('checkoutLines' =>  unserialize($checkoutLines),
								  			  'pmethod'		  =>  $pmethod,
								  			  'total'         =>  $total,
											  'usermail'      =>  $usermail,
											  'username'      =>  $username,
								 ));
		}
		else{// login page
			return $this->redirectToRoute('login');
		}
	}

	// list ads, modif ad image, delete ad image
	public function myadsAction(){
		// sitename, email, pays...
		$siteData = $this->getLocale();
		// get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];
		
		// pour les mails
		$from_name  = $sitetitle;
		$from_email = "info@doualazoom.com";
		$from = array($from_email => $from_name);
		
		$translator = $this->get('translator');
	// ads lines
		// client id
		$em = $this->getDoctrine()->getManager();
		$userid = $this->get('security.token_storage')->getToken()->getUser()->getId();
		$active = false;
		$errormsg = "";
		$adsObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Ads a 
										     WHERE  a.user =:id')->setParameters(array(
											 'id' => $userid,)) ;
		$adsLines = $adsObj->getResult();
		// translate descriptions inside ads 
		$i = 0;
		foreach($adsLines as $key=>&$value){
//			get Adtype object
			$adTypeObj = $value->getAdtype();
//			get description			
			$description = trim(preg_replace( "/\r|\n/", "", $adTypeObj->getDescription())); // remove line space
//			translate description			
			$descTranslated =  $translator->trans($description);
			$adTypeObj->setDescription($descTranslated);
//			set the translated description			
			$value->setAdtype($adTypeObj);
		}

		$adscount = count($adsLines);			
		$remainingDaysArray = array(); 
		$dateAdd = new AddDate;
		$i = 0;
		$datedepart = 0;
		// we make sure that if path is empty, statut shown is 'uploadez une image svp'
		for($i = 0; $i < $adscount; $i++ ){
			if(!$adsLines[$i]->getPath()){
				$id = 1; // uploadez une image svp.
				$statusRepository =  $em->getRepository('ZoomDoualaBundle:Adstatus')->findOneById($id);
				$adsLines[$i]->setStatus($statusRepository);
			}
//		}
			// calculate length in days for each ad and put it in an array
//$dates = $datesObj->getResult();

//		foreach($dates as $value){
			$datedepart = $adsLines[$i]->getStartdate();
			$duree = $adsLines[$i]->getDuree();
			$dateFin = $dateAdd->endCycle($datedepart, $duree);
			$datefinSecondes = strtotime($dateFin);
			$datedujourSecondes =  strtotime(\date('d-m-Y'));
			$reminingSeconde = $datefinSecondes - $datedujourSecondes;
			$remainingDaysArray[$i] = $reminingSeconde / 86400;
		} 
		// an image  file is uploaded
		$ids = array();
		if($_FILES){;
			// all ads id
			$idsObj = $em->createQuery('SELECT a.id FROM ZoomDoualaBundle:Ads a') ;
			$ids = $idsObj->getResult();
			$inputname = "";
			// file input name of uploaded file
			foreach($ids as $value){ // only one value will match
				if(isset($_FILES["form_".$value['id']])){
					// file original name
					$filearray = $_FILES["form_".$value['id']];			
					$inputname = $filearray['name'];
					// Check file size
					if ($filearray['size'] > 1000000 ){
    					$errormsg = $translator->trans("Sorry, your file is too large");
						return $this->render('ZoomStoreBundle:Show:myads.html.twig', 
										array('adsLines'  => $adsLines,
										      'remaining' => $remainingDaysArray,
											  'adscount'  => $adscount,
											  'errormsg'  => $errormsg, ));
					}
					else if( $filearray['size']  < 10 ){
    					$errormsg = $translator->trans("Sorry, your file is too small");
						return $this->render('ZoomStoreBundle:Show:myads.html.twig', 
										array('adsLines'  => $adsLines, 
											  'remaining' => $remainingDaysArray,
											  'adscount'  => $adscount,
											  'errormsg'  => $errormsg, ));
					}
					
					// save file
					    // Generate a unique name for the file before saving it
            		$fileName = md5(uniqid()).$inputname;
					$movedir = dirname(__FILE__).'/../../../../web/bundles/zoomdouala/images/ads';
					$uploadresult = move_uploaded_file($filearray['tmp_name'], $movedir."/".$fileName);
					// Move the file to the directory where files are stored
            		if(!$uploadresult ){
    					$errormsg = $translator->trans("Upload issue");
						return $this->render('ZoomStoreBundle:Show:myads.html.twig', 
										array('adsLines'  => $adsLines,
										      'remaining' => $remainingDaysArray,
											  'adscount'  => $adscount,
											  'errormsg'  => $errormsg , ));
					}
					// update database on table statusid
						//if ad status is not 'affichage en  cours' we update image otherwise we just notifie
					// get ad status
					$adObj = $em->getRepository('ZoomDoualaBundle:Ads')->findOneById($value['id']);
					$adstatusObj = $adObj->getStatus();
					$adstatusId = $adstatusObj->getId();

					if($adstatusId != 3 && $adstatusId != 5){ // not 'affichage en  cours', we can change the file.
						$path        = $fileName;
						$pathreplace = "";
						$status      = 2; // image en cours de validation...
						$query = $em->createQuery(
						   			  'UPDATE ZoomDoualaBundle:Ads a 
							           SET a.path        = :path,
							               a.pathreplace = :pathreplace,
								           a.status      = :status,
										   a.url         = :url
							           WHERE a.id =:id')
						             ->setParameters(array(
						               'path'          => $path,
							           'pathreplace'   => $pathreplace,
							           'status'        => $status,
									   'url'           => $_POST["linkname_".$value['id']],
									   'id'            => $value['id']));
						$updateResult = $query->getResult();
					}
					else{// si l'ad est deja en cours de publication, on peut demander un remplacement
						 // line of the modified ad
						$path = $adObj->getPath();
						$statusId = 5; // remplacement d'image demandé
						$setPath = "pathreplace"; // replacement image path
						// envoie du mail à l'admin
							// update path or pathreplace and update status  
						$adsObj = $em->createQuery("
									   UPDATE ZoomDoualaBundle:Ads a 
									   SET a.$setPath   = :path,
									       a.status     = :status
									   WHERE a.id       = :id")
									 ->setParameters(array(
									   'path'   => $fileName,
									   'id'     => $value['id'],
									   'status' => $statusId )) ;
						$updateResult = $adsObj->getResult();
						
						//////////////// send mail to admin with replacement picture /////////////////////////////
						$usermail = $this->getUser()->getUsername();
						try{
							$to01 = "info@doualapages.com";
							$to02 = "courrier@abidjanzoom.com";
							$to = array($to01, $to02);
							$message = \Swift_Message::newInstance()
         		 				->setSubject($usermail.' demande une modification d\'image  pour sa publicité sur DoualaZoom.com')
            					->setFrom($from)
            					->setTo($to)
            					->setBody($this->renderView('ZoomStoreBundle:Email:adminAdChangeRequest.txt.twig', array
																(
																	'adid'     		=> $value['id'],
																	'usermail' 		=> $usermail,
																	'sitetitle'     => $sitetitle,
																	'siteurl'       => $siteurl,
																	'sitename'      => $sitename,
																)
															), 'text/html');
							$message->attach(\Swift_Attachment::fromPath(__DIR__.'/../../../../web/bundles/zoomdouala/images/ads/'.$fileName));
							$send = $this->get('mailer')->send($message, $errors); // envoie du mail des l'admin
						}
						catch (\Swift_TransportException $STe)
						{
							$string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
	 						echo "\n";
	 						echo "send mail to info@doualazoom.com exeption: $string \n";
						}
						//////////////////////////////////////////////////////////////////////////////		
					}
			    }
		    }
			//return
			$_FILES = array();
			$_POST  = array();
			$adsObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Ads a 
   						            WHERE  a.user    =:id')->setParameters(array('id' => $userid,)) ;
		    $adsLines = $adsObj->getResult();

			///////////////////////////////////////////////////////////////////////////////
			return $this->redirectToRoute('store_myads', 
						array('adsLines'  => $adsLines,
							  'remaining' => $remainingDaysArray,
							  'adscount'  => $adscount,
							  'errormsg'  => $errormsg , ), 301);
		}
		
		// Remove ad image
		if(isset($_REQUEST['addidtoupdate'])){
			//if ad status is not 'affichage en  cours' we delete otherwise we just notifie
		      // get adstatut
			$id = $_REQUEST['addidtoupdate'];
			$adObj = $em->getRepository('ZoomDoualaBundle:Ads')->findOneById($id);
			$adstatusObj = $adObj->getStatus();
			$adstatusId = $adstatusObj->getId();
			if($adstatusId != 3 && $adstatusId != 5){ // not 'affichage en  cours': we can change ad path
				// remove image
				$statusid   = 1;
				$path       = "";
				$pathreplace = "";
				
				$query = $em->createQuery(
						   'UPDATE ZoomDoualaBundle:Ads a 
							SET a.path        = :path,
							    a.pathreplace = :pathreplace,
								a.status      = :statusid
							WHERE a.id   =:id')
						  ->setParameters(array(
						    'path'          => $path,
							'pathreplace'   => $pathreplace,
							'statusid'      => $statusid,
							'id'            => $id)) ;
				$result = $query->getResult();
				
				$adsObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Ads a 
   						            WHERE  a.user    =:id')->setParameters(array('id' => $userid,)) ;
		    	$adsLines = $adsObj->getResult();
				$_FILES = array();
				$_POST = array();
				return $this->redirectToRoute('store_myads', 
						array('adsLines'  => $adsLines,
							  'remaining' => $remainingDaysArray,
							  'adscount'  => $adscount,
							  'errormsg'  => $errormsg), 301);
			}
			else{ 
				// send mail to admin to notifie image suppress query
				//////////////// send mail to admin with replacement picture /////////////////////////////
				try{
					$to01 = "info@doualapages.com";
					$to02 = "courrier@abidjanzoom.com";
					$to = array($to01, $to02);
					$message = \Swift_Message::newInstance()
         		 		->setSubject($usermail.' demande une suppression d\'image  de la publicité id n°: '.$id)
            			->setFrom($from)
            			->setTo($to)
            			->setBody($this->renderView('ZoomStoreBundle:Email:adminAdDeleteRequest.txt.twig', array
														(
															'adid'      => $adstatusId,
															'usermail'  => $usermail,
															'sitetitle' => $sitetitle,
															'siteurl'   => $siteurl,
															'sitename'  => $sitename,
														)
													),  'text/html'
								);
					$send = $this->get('mailer')->send($message, $errors); // envoie du mail des l'admin
				}
				catch (\Swift_TransportException $STe)
				{
					$string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
	 				echo "\n";
	 				echo "send mail to info@doualazoom.com exeption: $string \n";
				}
				//return
				$errormsg = $translator->trans("We can not delete an active ad image. Use [select] to find a replacement image please".".");
//				var_dump($errormsg);
			}

			//return
			$adsObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Ads a 
										     WHERE  a.user    =:id')->setParameters(array('id' => $userid,)) ;
			$adsLines = $adsObj->getResult();
			$_FILES = array();
			$_POST = array();
			return $this->render('ZoomStoreBundle:Show:myads.html.twig',
				array('adsLines'  => $adsLines,
				  	  'remaining' => $remainingDaysArray,
				  	  'adscount'  => $adscount,
				  	  'errormsg'  => $errormsg
			));
		}

		//return
		$adsObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Ads a 
										     WHERE  a.user    =:id')->setParameters(array('id' => $userid,)) ;
		$adsLines = $adsObj->getResult();
		$_FILES = array();
		$_POST = array();
		return $this->render('ZoomStoreBundle:Show:myads.html.twig',
			array('adsLines'  => $adsLines,
				  'remaining' => $remainingDaysArray,
				  'adscount'  => $adscount,
				  'errormsg'  => $errormsg
		));
	}
	//

	public function storeMenuAction(){
		return $this->render('ZoomStoreBundle:Show:storeMenu.html.twig');
	}
	
	// Representant de categorie ad modif
	public function companyrepmodifAction($companyrepid, Request $request){
		// sitename, email, pays...
		$siteData = $this->getLocale();
		// get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];
		
		$em = $this->getDoctrine()->getManager();
		$translator = $this->get('translator');
		$message = "";
		$companyRepModifObj  = $em->getRepository('ZoomDoualaBundle:CompanyRep')->findOneById($companyrepid);
//		$companyRepModif 	 = $companyRepModifObj->getResult();
//		$companyRepModifForm = $this->createForm(CompanyRepModifForm::class);
// var_dump (  $companyrepid  );
//		$companyRepModifForm->handleRequest($request);
		if($_SERVER["REQUEST_METHOD"] == "POST"){
//			var_dump($rubriqueIdObj);
			// rubrique
			if($request->request->get('rubriqueName')){
				$rubrique    = $request->request->get('rubriqueName');
				$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneByRubrique($rubrique);
				$companyRepModifObj->setRubriqueId($rubriqueObj);
			}
			// activite
			if($request->request->get('company')){
				$companyStr = $request->request->get('company'); // nom de l'entreprise
 				$companyTab = explode('-', $companyStr);
				$companyId  =  $companyTab[count($companyTab)-1];// id de l'entreprise
				$companyObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneById($companyTab);
				$companyRepModifObj->setEntrepriseId($companyObj);
			}
			$em->persist($companyRepModifObj);
			$em->flush($companyRepModifObj);
			$message = $translator->trans("Your request for data modification succesfully send");
		
			// site datas (email, sitename, ...)
			$siteData = $this->getLocale();

			// send a mail
			if($this->getUser()){
				$usermail   = $this->getUser()->getUsername();
				$username   = $this->getUser()->getName();			
				$from_name  = "DoualaZoom.com";
				$from_email = "info@doualazoom.com";
				$from = array($from_email => $from_name);
				// send mail to admin
				try{
					$to01 = "info@doualapages.com";
					$to02 = "yaosoft@hotmail.com";
					$to = array($to01, $to02);
					// ex model name
					$exModelObj    = $em->getRepository('ZoomDoualaBundle:Activite')->findOneById($companyrepid);
					$exModel       = $exModelObj->getEntreprise();
					$mailMessage = \Swift_Message::newInstance()
						->setSubject($username.' demande une modification d\'entreprise model')
						->setFrom($from)
						->setTo($to)
						->setBody($this->renderView('ZoomStoreBundle:Email:adminModelModifNotification.txt.twig', 
													array(
														'modelName'     => $companyTab[0], 
														'modelId'       => $companyId,
														'rubrique'      => $rubrique,
														'exModelName' 	=> $exModel,
														'exModelId' 	=> $companyRepModifObj->getId(),
														'username'		=> $username,
														'usermail'		=> $usermail,
														'sitetitle'     => $sitetitle,
														'siteurl'       => $siteurl,
														'sitename'      => $sitename,
													)
												) , 'text/html'
								);
					$send = $this->get('mailer')->send($mailMessage, $errors); // envoie du mail de l'admin
				}
				catch (\Swift_TransportException $STe)
				{
					$string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
					echo "\n";
					echo "send mail to info@doualazoom.com exeption: $string \n";
				}
				// send mail to the user
				// ...
				// ...
			}
		}

		// site datas (email, sitename, ...)
		$siteData = $this->getLocale();

		return $this->render('ZoomStoreBundle:Show:companyRepModifier.html.twig', 
			array(
				  'companyInfo' 		 => $companyRepModifObj,
				  'message'				 => $message,
				  'siteData'             => $siteData,
		));
	}

	// Model de categorie ad
	public function companyrepAction(){
		$em = $this->getDoctrine()->getManager();
		$id = 5; // model ads id
		// company ref infos
		$companyrepAdInfoObj = $em->createQuery('SELECT a.adsname, a.price, a.description, a.curency
											     FROM ZoomDoualaBundle:Adstype a
											     WHERE a.id =:id'
											    )->setParameters(array('id' => $id));
		$companyrepAdInfo = $companyrepAdInfoObj->getResult();
		$translator = $this->get('translator');
		$message = "";
//		$companyRepModifObj = $em->getRepository('ZoomDoualaBundle:CompanyRep')->findOneById($companyrepid);
		// locals datas
		$localObj = $em->createQuery('SELECT a.ville, a.pays, a.indicatif, a.email, a.phone, a.curency
									  FROM ZoomDoualaBundle:Locale a')
									  ->setMaxResults(1);
		$local = $localObj->getResult();
		// all model companies of this customer
		$userid = $this->get('security.token_storage')->getToken()->getUser()->getId();
		$userModelCompanyObj = $em->createQuery('SELECT a
											     FROM ZoomDoualaBundle:CompanyRep a
											     WHERE a.companyrepUserid =:userid'
											     )->setParameters(array('userid' => $userid));
		$userModelCompany = $userModelCompanyObj->getResult();

		// site datas (email, sitename, ...)
		$siteData = $this->getLocale();

		return $this->render('ZoomStoreBundle:Show:companyRep.html.twig', 
			array(
				  'message'	         => $message,
				  'local'	         => $local,
				  'companyrepAdInfo' => $companyrepAdInfo,
				  'userModelCompany' => $userModelCompany,
				  'siteData'         => $siteData,
				  'userModelCount'   => count($userModelCompany),
			));
	}

    // 
    public function imagesAction(){

        $message='';
		$em = $this->getDoctrine()->getManager();
		if (isset($id)) 
		{
		// modification d'une image existante : on recherche ses données
			$image = $em->find('ZoomStoreBundle:Image', $id);
			if (!$image)
			{
				$message='Aucune Image trouvee';
			}
		}
		else 
		{
			//... ou ajout d'une nouvelle
			$image = new Image();
            //$activiteId;
            //$image
		}
		$form = $this->createForm(imageForm::class, $image);	
		$form->handleRequest($request);
		if ($form->isValid())
		{	
			$em->persist($form->getData('name'));
			$em->flush();
			if (isset($id)) 
			{
				$message_modif= $image->getName();
				return $this->render('ZoomDoualaBundle:Image:modifier.html.twig', array('form' => $form->createView(),'message_modif' => $message_modif));
			}
			else
			{
				$message_new= $image->getName();
				return $this->render('ZoomDoualaBundle:Image:modifier.html.twig', array('form' => $form->createView(),'message_new' => $message_new));
			}
		}
		else
		{
			return $this->render('ZoomDoualaBundle:Image:modifier.html.twig', array('form' => $form->createView(),'message' => $message));
		}
    }

	// A la une
	public function companyalauneAction(){
		// sitename, email, pays...
		$siteData = $this->getLocale();
		// get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];
		
		$em = $this->getDoctrine()->getManager();
		$id = 7; // a la une ads id
		// company ref infos
		$companyalauneAdInfoObj = $em->createQuery('SELECT a.adsname, a.price, a.description, a.curency
											     FROM ZoomDoualaBundle:Adstype a
											     WHERE a.id =:id'
											    )->setParameters(array('id' => $id));
		$companyalauneAdInfo = $companyalauneAdInfoObj->getResult();
		$translator = $this->get('translator');
		$message = "";
//		$companyRepModifObj = $em->getRepository('ZoomDoualaBundle:CompanyRep')->findOneById($companyrepid);
		// locals datas
		$localObj = $em->createQuery('SELECT a.ville, a.pays, a.indicatif, a.email, a.phone, a.curency
									  FROM ZoomDoualaBundle:Locale a')
									  ->setMaxResults(1);
		$local = $localObj->getResult();
		// all companies  a la une of this customer
		$userid = $this->get('security.token_storage')->getToken()->getUser()->getId();
		$userAlauneCompanyObj = $em->createQuery('SELECT a
                                                    FROM ZoomDoualaBundle:CompanyAlaune a
                                                    WHERE a.companyalauneUserid =:userid'
											    )->setParameters(array('userid' => $userid));
		$userAlauneCompany = $userAlauneCompanyObj->getResult();

		return $this->render('ZoomStoreBundle:Show:companyAlaune.html.twig', 
			array(
				  'message'	         => $message,
				  'local'	         => $local,
				  'companyAlauneAdInfo' => $companyalauneAdInfo,
				  'userAlauneCompany' => $userAlauneCompany,
				  'siteData'          => $siteData,
				  'userAlauneCount'   => count($userAlauneCompany),
			));
	}

	// A la une modif
	public function companyalaunemodifAction($companyalauneid, Request $request){
		// sitename, email, pays...
		$siteData = $this->getLocale();
		// get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];
		
		$em = $this->getDoctrine()->getManager();
		$translator = $this->get('translator');
		$message = "";
		$companyAlauneModifObj  = $em->getRepository('ZoomDoualaBundle:CompanyAlaune')->findOneById($companyalauneid);
//		$companyRepModif 	 = $companyRepModifObj->getResult();
//		$companyRepModifForm = $this->createForm(CompanyRepModifForm::class);
		
//		$companyRepModifForm->handleRequest($request);
		if($_SERVER["REQUEST_METHOD"] == "POST"){
//			var_dump($rubriqueIdObj);
			// rubrique
			//if($request->request->get('rubriqueName')){
			//	$rubrique    = $request->request->get('rubriqueName');
			//	$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneByRubrique($rubrique);
			//	$companyRepModifObj->setRubriqueId($rubriqueObj);
			//}
			// activite
			if($request->request->get('company')){
				$companyStr = $request->request->get('company'); // nom de l'entreprise
 				$companyTab = explode('-', $companyStr);
				$companyId  =  $companyTab[count($companyTab)-1];// id de l'entreprise
				$companyObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneById($companyTab);
				$companyAlauneModifObj->setEntrepriseId($companyObj);
			}
			$em->persist($companyAlauneModifObj);
			$em->flush($companyAlauneModifObj);
			$message = $translator->trans("Your request for data modification succesfully send");
		
			// send a mail
			if($this->getUser()){
				$usermail   = $this->getUser()->getUsername();
				$username   = $this->getUser()->getName();			
				$from_name  = "DoualaZoom.com";
				$from_email = "info@doualazoom.com";
				$from = array($from_email => $from_name);
				// send mail to admin
				try{
					$to01 = "info@doualapages.com";
					$to02 = "yaosoft@hotmail.com";
					$to = array($to01, $to02);
					// ex model name
					$exModelObj    = $em->getRepository('ZoomDoualaBundle:Activite')->findOneById($companyalauneid);
					$exModel       = $exModelObj->getEntreprise();
					$mailMessage = \Swift_Message::newInstance()
						->setSubject($username.' demande une modification d\'Entreprise à la une')
						->setFrom($from)
						->setTo($to)
						->setBody($this->renderView('ZoomStoreBundle:Email:adminAlauneModifNotification.txt.twig', 
													array(
														'modelName'     => $companyTab[0], 
														'modelId'       => $companyId,
														'exModelName' 	=> $exModel,
														'exModelId' 	=> $companyAlauneModifObj->getId(),
														'username'		=> $username,
														'usermail'		=> $usermail,
														'sitetitle'     => $sitetitle,
														'siteurl'       => $siteurl,
														'sitename'      => $sitename,
													)
												) , 'text/html'
								);
					$send = $this->get('mailer')->send($mailMessage, $errors); // envoie du mail de l'admin
				}
				catch (\Swift_TransportException $STe)
				{
					$string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
					echo "\n";
					echo "send mail to info@doualazoom.com exeption: $string \n";
				}
				// send mail to the user
				// ...
				// ...
			}
		}

		// site datas (email, sitename, ...)
		$siteData = $this->getLocale();

		return $this->render('ZoomStoreBundle:Show:companyAlauneModifier.html.twig', 
			array(
				  'companyInfo' 		 => $companyAlauneModifObj,
				  'message'				 => $message,
				  'siteData'             => $siteData,
		));
	}


// registration

	// list des companies enregistrés pour l'utilisateur courant
	public function companyregistrationAction(){
		// sitename, email, pays...
		$siteData = $this->getLocale();
		// get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];
		
		$em = $this->getDoctrine()->getManager();
		$id = 6; // registrations id
		// company ref infos
		$companyrepAdInfoObj = $em->createQuery('SELECT a.adsname, a.price, a.description, a.curency
											     FROM ZoomDoualaBundle:Adstype a
											     WHERE a.id =:id'
											     )->setParameters(array('id' => $id));
		$companyrepAdInfo = $companyrepAdInfoObj->getResult();
		$translator = $this->get('translator');
		$message = "";
//		$companyRepModifObj = $em->getRepository('ZoomDoualaBundle:CompanyRep')->findOneById($companyrepid);
		// locals datas
		$localObj = $em->createQuery('SELECT a.ville, a.pays, a.indicatif, a.email, a.phone, a.curency
									  FROM ZoomDoualaBundle:Locale a')
									  ->setMaxResults(1);
		$local = $localObj->getResult();
		// all registered companies of this customer
		$userid = $this->get('security.token_storage')->getToken()->getUser()->getId();
		$userModelCompanyObj = $em->createQuery('SELECT a
											     FROM ZoomDoualaBundle:companyRegistration a
											     WHERE a.companyregistrationUserid =:userid'
											     )->setParameters(array('userid' => $userid));
		$registration_list = $userModelCompanyObj->getResult();

        // remove invalide registratinsnot found companies
        $registrations = Array();
        foreach( $registration_list as $registration){
            $companyObj = $registration->getEntrepriseId();
// $entityName = $em->getMetadataFactory()->getMetadataFor(get_class($companyObj))->getName();
// echo $entityName;

            $companyObjQuery = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a
                                   WHERE a = :obj')->setParameters(array('obj' => $companyObj,));
                  
            $companys = $companyObjQuery->getResult();
// echo $activation;
// echo "-";
            if( sizeof( $companys ) ){
                array_push( $registrations, $companys[0] );
            }
                
            // $count = sizeof( $registrations );
        } 

		return $this->render('ZoomStoreBundle:Show:companyRegistration.html.twig', 
			array(
				  'message'	         => $message,
				  'local'	         => $local,
				  'companyrepAdInfo' => $companyrepAdInfo,
				  'userModelCompany' => $registrations,
				  'siteData'         => $siteData,
				  'userModelCount'   => count($registrations),
			)
		);
	}
	
	/////// Get locales variables, return array
	public function getLocale (){
		$em = $this->getDoctrine()->getManager();
		$localeObj   = $em->getRepository('ZoomDoualaBundle:Locale')->findAll();
		$localData = array();
		//
		$localData['email'] = $localeObj[0]->getEmail();
		$localData['name']  = $localeObj[0]->getSitename();
		$localData['url']   = $localeObj[0]->getSiteUrl();
		$localData['title'] = $localeObj[0]->getSiteTitle();
		$localData['ville'] = $localeObj[0]->getVille();
		$localData['pays']  = $localeObj[0]->getPays();
		//
		return $localData;
	}

}
