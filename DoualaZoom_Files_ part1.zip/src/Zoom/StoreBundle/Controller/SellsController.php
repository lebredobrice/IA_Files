<?php

namespace Zoom\StoreBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Translation\TranslatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Zoom\StoreBundle\Entity\Sell;
use Zoom\StoreBundle\Model\AddDate\AddDate;

class SellsController extends Controller
{
	public function listerAction(){
		$em = $this->getDoctrine()->getManager();
		$sellsObj = $em->createQuery('SELECT a FROM ZoomStoreBundle:Sell a');
		$sellsLines = $sellsObj->getResult();
		$sellsCount = count($sellsLines);
		return $this->render('ZoomStoreBundle:Sell:lister.html.twig',
							            array('sellsLines' => $sellsLines,
											  'sellsCount' => $sellsCount,
										 ));
	}
}