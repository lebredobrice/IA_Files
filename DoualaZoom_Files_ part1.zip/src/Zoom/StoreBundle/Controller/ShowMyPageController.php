<?php

namespace Zoom\StoreBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Translation\TranslatorInterface;
use Symfony\Component\Form\FormError;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Zoom\DoualaBundle\Entity\Ads;
use Zoom\DoualaBundle\Entity\CompanyRep;
use Zoom\StoreBundle\Entity\Sell;
use Zoom\StoreBundle\Model\AddDate\AddDate;
use Zoom\StoreBundle\Form\CompanyRepModifForm;
use Zoom\DoualaBundle\Form\contactEntrepriseModifierForm;
use Zoom\DoualaBundle\Model\Tablearray\Tablearray;
use Zoom\DoualaBundle\Model\Translate\Translate;
use Zoom\DoualaBundle\Model\Reversetranslate\Reversetranslate;
use Zoom\DoualaBundle\Model\Languagefromurl\Languagefromurl;
use Zoom\DoualaBundle\Entity\Repere;
use Zoom\DoualaBundle\Entity\Prestation;
use Zoom\DoualaBundle\Entity\Rubrique;
use Zoom\DoualaBundle\Entity\Activite;
use Zoom\DoualaBundle\Entity\Quartier;
use Zoom\DoualaBundle\Entity\Rue;
use Zoom\DoualaBundle\Model\Sendmail\Sendmail;
 
class ShowMyPageController extends Controller 
{

	// Page de modification d'une entreprise
	function myPageAction( $companyid, Request $request )
	{	

		$translator = $this->get('translator');

		// sitename, email, pays...
		$siteData = $this->getLocale();
		// get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];
		
		$em = $this->getDoctrine()->getManager();

		// company info
		$em = $this->getDoctrine()->getManager();
		$activite = $em->getRepository('ZoomDoualaBundle:Activite')
												->findOneBy
													(
														array
															(
																'id'=>$companyid
															)
													);
// var_dump($activite->getMap());
		// Ids to names
		// rubriqueId to rubrique
		$selected   = $activite->getEntreprise(); 

		// $entrepriseId = $companyid;
 		$rubriqueId = $activite->getRubriqueId(); 
        //
        $path01_old = $activite->getPath01(); 
        $path02_old = $activite->getPath02();
        $path03_old = $activite->getPath03();
        
//  echo "1: " . $path01_old . "<br>";
//  echo "2: " . $path02_old . "<br>";
//  echo "3: " . $path03_old . "<br>";
        
		// all registered companies of this customer
		$userid = $this->get('security.token_storage')->getToken()->getUser()->getId();

        $userModelCompanyObj = $em->createQuery('SELECT a
											     FROM ZoomDoualaBundle:companyRegistration a
											     WHERE a.companyregistrationUserid =:userid'
											     )->setParameters(array('userid' => $userid));
		$userModelCompany = $userModelCompanyObj->getResult();

        // remove not found companies
        $userModelCompanies = Array();
        foreach( $userModelCompany as $registration ){
            $companyObj = $registration->getEntrepriseId();
// $entityName = $em->getMetadataFactory()->getMetadataFor(get_class($companyObj))->getName();

            $companyObjQuery = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a
                                   WHERE a = :obj')->setParameters(array('obj' => $companyObj,));
                  
            $companys = $companyObjQuery->getResult();
// echo $activation;
// echo "-";
            if( sizeof( $companys ) ){
                array_push( $userModelCompanies, $companys[0] );
            }
                
            // $count = sizeof( $userModelCompanies );
        } 

        // display Rue on the form
        $rueId      = $activite->getRueId();
        $rueObj     = $em->getRepository( 'ZoomDoualaBundle:Rue' )
                         ->findOneById( $rueId );
        $rue = null;
        if( $rueObj )
            $rue  = $rueObj->getRue();
        $activite->setRueId( $rue );
        
        // display Repere on the form
        $repereId      = $activite->getRepereId();
        $repereObj     = $em->getRepository( 'ZoomDoualaBundle:Repere' )
                         ->findOneById( $repereId );
        $repere        = null;
        if( $repereObj )
            $repere = $repereObj->getRepere();
        $activite->setRepereId( $repere );
        
        // Preparation des elements pour cookies
		$translate = new Translate;
		$language = new Languagefromurl;
		$langueId = $language->getLanguage();
        
        // Entreprise selectionee
        $selectedObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneByEntreprise($selected);
		// Rubrique
		$oldRubriqueId = $selectedObj->getRubriqueId();
		$oldRubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($oldRubriqueId);
		$oldRubrique = $oldRubriqueObj->getRubrique();

		// Fonction
		$oldFonctionId = $selectedObj->getFonctionId();
        if( !is_null( $oldFonctionId ) ){
            $oldFonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($oldFonctionId);
            $oldFonction = "";
            if( !is_null( $oldFonctionObj ) )
                $oldFonction = $oldFonctionObj->getFonction();
        }
        else{
            $oldFonctionId  = 0;
            $oldFonction    = "Aucune";
        }
		// Ville 
		$oldVilleId = $selectedObj->getVilleId();
		$oldVilleObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($oldVilleId);
		$oldVille = $oldVilleObj->getVille();
			
		// Quartier
		$oldQuartierId = $selectedObj->getQuartierId();
// var_dump($oldQuartierId);
		$oldQuartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($oldQuartierId);
		$oldQuartier = $oldQuartierObj->getQuartier();
			
		// Adsize
		$oldAdsize = '';

		// Fabrication des cookies
		setcookie('IdEntreprise', $companyid, time() + (86400 * 30), '/'); // controller
		setcookie('nomEntreprise', $selected, time() + (86400 * 30), '/');
		setcookie('oldRubrique', $oldRubrique, time() + (86400 * 30), '/');
		setcookie('oldFonction', $oldFonction, time() + (86400 * 30), '/');
		setcookie('oldVille', $oldVille, time() + (86400 * 30), '/');
		setcookie('oldQuartier', $oldQuartier, time() + (86400 * 30), '/');
		setcookie('oldAdsize', $oldAdsize, time() + (86400 * 30), '/');
		setcookie('entrepriseId', $companyid, time() + (86400 * 30), '/');
					// some ids to ease translation on the form
		setcookie('oldRubriqueId', $oldRubriqueId, time() + (86400 * 30), '/');		
		setcookie('oldFonctionId', $oldFonctionId, time() + (86400 * 30), '/');

		$contactEntrepriseModifierObj = $this->createForm(contactEntrepriseModifierForm::class, $activite );
		$contactEntrepriseModifierObj->handleRequest($request); 

		if (!$contactEntrepriseModifierObj->isSubmitted() ){  // formulaire display
			
			// rechargement de la page pour "activer" les cookies
			//return $this->redirect($this->generateUrl('store_mypage_test', array(
			//'companyid' => $entrepriseId)));


			$message = $translator->trans('In case of difficulty in the filling of the form fields, send an email to the address info@Doualazoom.com, with all your Information and we will do it for you. Pictures,  logos and possibly commercial videos must be sent as attachments to that mail.');

			if( isset( $_COOKIE['IdEntreprise'] ) &&  $_COOKIE['IdEntreprise'] == $companyid ){
				return $this->render('ZoomStoreBundle:Show:mypage.html.twig', array(
					 'id'       => $companyid,
					 'selected' => $selected,
					 'message'  => $message,
					 'contactEntrepriseModifierForm' => $contactEntrepriseModifierObj->createView(),
					 'userModelCompany'  => $userModelCompanies,
					 'companyrepAdInfo'  => [],
				 ));
			}
			else {
//var_dump($_COOKIE['nomEntreprise']);
				// rechargement de la page pour "activer" les cookies
				return $this->redirect($this->generateUrl('store_mypage', array(
				'companyid' => $companyid)));
			}
		}	
		else  // formulaire POST
		{  			
			$contactEntrepriseModifierForm = $contactEntrepriseModifierObj;
			$datas = $contactEntrepriseModifierForm->getData();
			// farication de la chaine des donn?es du formulaire ? envoyer par mail
				//rubrique
			$rubriqueId = $datas->getRubriqueId();
			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
			$form_rubrique = $rubriqueObj->getRubrique();
				//entreprise
			$form_entreprise = $contactEntrepriseModifierForm['entreprise']->getData();
				//bp
			$form_bp = $contactEntrepriseModifierForm['bp']->getData();
				//telephone01
			$form_telephone01 = $contactEntrepriseModifierForm['telephone01']->getData();
				//
			$form_telephone02 = $contactEntrepriseModifierForm['telephone02']->getData();
				//
			$form_fax = $contactEntrepriseModifierForm['fax']->getData();
				//
			$form_contact = $contactEntrepriseModifierForm['contact']->getData();
				//fonction
			$form_fonction = "aucune";
			$fonctionId = $datas->getFonctionId();
			if($fonctionId){
				$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);$form_fonction = $fonctionObj->getFonction();
			}

// var_dump($fonctionId);
				//
			$form_ville = $contactEntrepriseModifierForm['villeId']->getData();
				//
			$form_quartier = $contactEntrepriseModifierForm['quartierId']->getData();
			//
			// filtrage des reperes
			$form_repere = stripslashes($contactEntrepriseModifierForm['repereId']->getData());
			$form_rue = htmlspecialchars(strip_tags($form_repere));
			//
			$form_details = $contactEntrepriseModifierForm['place']->getData();
			// filtrage des rues
			$form_rue = stripslashes($contactEntrepriseModifierForm['rueId']->getData());
			$form_rue = htmlspecialchars(strip_tags($form_rue));
			//
			$form_email = $contactEntrepriseModifierForm['email']->getData();
			$form_web = $contactEntrepriseModifierForm['web']->getData();
			// filtrage de l'adresse web et des slash
			$form_web = str_replace("http://","",$form_web);
			// filtrage de AdSize et ses apostrophes
			$form_adsize =  str_replace("'","",$contactEntrepriseModifierForm['adsizeId']->getData());
			// filtrage de Alaune et ses apostrophes
			$form_alaune =  str_replace("'","",$contactEntrepriseModifierForm['alaune']->getData());
			// Clean up these input values
			if(ini_get('magic_quotes_gpc'))
			{	
				//contact
				$form_contact = stripslashes($form_contact);
				$form_contact = htmlspecialchars(strip_tags($form_contact));
			}
			$form_map = $contactEntrepriseModifierForm['map']->getData();
			$form_datas = "Entreprise: ".$form_entreprise." - "."Rubrique: ".$form_rubrique." - "."Bp: ".$form_bp." - "."telephone01: ".$form_telephone01." - "."telephone02: ".$form_telephone02." - "."fax: ".$form_fax." - "."contact: ".$form_contact." - "."fonction: ".$form_fonction." - "."ville: ".$form_ville." - "."quartier: ".$form_quartier." - "."repere: ".$form_repere." - "."details: ".$form_details." - "."map: ".$form_map." - "."email: ".$form_email." - "."web: ".$form_web." - "."rue: ".$form_rue." - "."Nombre de mois Represantant de sa rubrique: "." - ".$form_adsize." - Nombre de mois A la une: ".$form_alaune;
			//
		    // Reperes: si le rep?re saisie n'existe pas encore dans la base de donn?e, on l'ajoute dans la table repere
		    $repereSaisie = trim($contactEntrepriseModifierForm['repereId']->getData());
			// est ce que un repere a ?t? saisie
			if($repereSaisie != "")
			{ 
				// est ce que ce repere existe d?ja sinon on le cr?e
				$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneByRepere($repereSaisie );
//var_dump($repereObj);
				$repereCount = sizeof($repereObj);
//echo $repereCount ;
				if($repereCount==0 AND $contactEntrepriseModifierForm['repereId']->getData()!= '') //nouveau repere
				{   
					$em01 = $this->getDoctrine()->getManager();
					//quartierId du repere en fonction du nom du quartier
					$quartier = trim($contactEntrepriseModifierForm['quartierId']->getData());
					$quartierObj = $em01->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
					$quartierId = $quartierObj->getId();
					// villeId du repere
					$ville = trim($contactEntrepriseModifierForm['villeId']->getData());
					$villeObj = $em01->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($ville);
					$villeId = $villeObj->getId();
					// repere
					$repere = new Repere();
					$repere->setRepere($repereSaisie);
					$repere->setQuartierId($quartierId);
					$repere->setVilleId($villeId);
					//// on persist la base de donn?e avec le nouveau Repere
				   $em->persist($repere); 
				   $em->flush();
				}
			}
			// fin traitement des Reperes
			
			// Traitement des rues
			// Rue: si la rue saisie n'existe pas encore dans la base de donn?e, on l'ajoute dans la table Rue
		    $rueSaisie = trim($contactEntrepriseModifierForm['rueId']->getData());
			// est ce que une rue a ?t? saisie
			if($rueSaisie)
			{ 
				// est ce que cette rue existe d?ja sinon on la cr?e
				$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneByRue($rueSaisie );
//var_dump($repereObj);
				$rueCount = sizeof($rueObj);
//echo $repereCount ;
				if($rueCount==0) //nouvelle rue
				{  
					$em01 = $this->getDoctrine()->getManager();
					//quartierId de la rue en fonction du nom du quartier
					$quartier = trim($contactEntrepriseModifierForm['quartierId']->getData());
					$quartierObj = $em01->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
					$quartierId = $quartierObj->getId();
					// villeId de la rue
					$ville = trim($contactEntrepriseModifierForm['villeId']->getData());
					$villeObj = $em01->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($ville);
					$villeId = $villeObj->getId();
					// prorpietés de la rue
					$rue = new Rue();
					$rue->setRue($rueSaisie);
					$rue->setQuartierId($quartierId);
					$rue->setVilleId($villeId);
					//// on persist la base de donn?e avec la nouvelle Rue
				    $em->persist($rue); 
				    $em->flush();
				}
			}
			// fin traitement des rues
			// Recup?rationdes Id en fonction des noms sur le formulaire avant de sauvegarder
			// Id de la ville ? partir du nom de la ville
			$villeId = trim($contactEntrepriseModifierForm['villeId']->getData());
			$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($villeId);
			$ville = $villeObj->getId();
			$activite->setVilleId($ville);
			// Id du quartier ? partir du nom duu quartier
			$quartierId = trim($contactEntrepriseModifierForm['quartierId']->getData()); 
			$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartierId);
			$quartier = $quartierObj->getId();
			$activite->setQuartierId($quartier);
			// site web
			$web = trim($contactEntrepriseModifierForm['web']->getData()); 
			$activite->setWeb($web);
			// Id de la fonction ? partir du nom de la fonction
			$fonctionId = trim($contactEntrepriseModifierForm['fonctionId']->getData());
//var_dump($datas->getFonctionId());
			if ($fonctionId){
				$activite->setFonctionId($fonctionId);
			}
			else{ // pas de fonction choisie
				$activite->setFonctionId(0);
			}
			// Id de la rubrique ? partir du nom de la rubrique
			$rubriqueId = trim($contactEntrepriseModifierForm['rubriqueId']->getData()); 
			$activite->setRubriqueId($rubriqueId);
			// Id de adsize  partir du nom de la adsize
//			$adsizeId = trim($contactEntrepriseModifierForm['adsizeId']->getData()); 
//			if ($adsizeId){ 
//				$adsizeObj = $em->getRepository('ZoomDoualaBundle:Adsize')->findOneById($adsizeId);
//				$adsize = $adsizeObj->getId();
//				$activite->setAdsizeId($adsize);
//			}
//			else{ // pas de adsize choisis
//				$activite->setAdsizeId(0);
//			}
			// Id du repere ? partir du nom du repere
			$repereId = trim($contactEntrepriseModifierForm['repereId']->getData());
			$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneByRepere($repereId);
			if(isset($repereObj))
			{
				$repere = $repereObj->getId();
				$activite->setRepereId($repere);
			}
			else // si aucun repere n'a ?t? choisis, l'id du repere = 0
			{
				$activite->setRepereId(0);	
			}
			// fin
			// Id de la rue ? partir du nom de la rue
			if($rueSaisie)
			{
				$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneByRue($rueSaisie );
				$rueId = $rueObj->getId();
				$activite->setRueId($rueId);
			}
			else // si aucun rue n'a ?t? choisis, l'id du repere = 0
			{
				$activite->setRueId(0);	
			}
			// Messages d'erreur de validation et contraintes suppl?mentaires du formlaire de modification 
			$validation = "";
			// Validation de la rubrique
			$data01 = $contactEntrepriseModifierForm['rubriqueId']->getData(); // on verifie que le champ rubrique de la listbox a ?t? modifi? avant de persister
			$rubriqueformId = $contactEntrepriseModifierForm['rubriqueId']->getData(); 
// echo $rubriqueformId;
			if($rubriqueformId == 0) // la rubrique n'a pas bien ?t? chang?e
			{
			    $validation = 1; // Veuillez selectionner une rubrique
			}
			// Validation du num?ro de telephone01
			$telephone01 = $contactEntrepriseModifierForm['telephone01']->getData();
			     // nombre de caracteres du num?ro
			$telephone01_len = strlen($telephone01);
			if($telephone01_len < 6 || $telephone01_len > 16)
			{
			    $validation = 2; // Le num?ro T?l?phone01 est invalide
			}
           // Validation du num?ro de telephone02
			$telephone02 = $contactEntrepriseModifierForm['telephone02']->getData();
			     // nombre de caracteres du num?ro
			$telephone02_len = strlen($telephone02);
			if($telephone02_len !=0 AND $telephone02_len < 6)
			{
			    $validation = 3; // Le num?ro T?l?phone02 est invalide
			}
           	// Validation du num?ro du fax
			$fax = $contactEntrepriseModifierForm['fax']->getData();
			     // nombre de caracteres du num?ro
			$fax_len = strlen($fax);
			if($fax_len!=0 AND $fax_len < 6)
			{
			    $validation = 4; // Le num?ro Fax est invalide
			}
			// Validation du nom de l'activit?
			    // nombre de caracteres de l'activt?
			$entreprise = $contactEntrepriseModifierForm['entreprise']->getData();
			$activite_len = strlen($entreprise);
			if($activite_len < 3)
			{
			    $validation = 5; // Le nom de l'activit? est invalide
			}
			// Validation du quartier
			$data02 = $contactEntrepriseModifierForm['quartierId']->getData(); // on verifie que le champ rubrique a ?t? modifi? avant de persister
			$quartierformId = $data02->getId(); 
			if($quartierformId == 0) // la rubrique n'a pas bien ?t? chang?e
			{
			    $validation = 6; // Veuillez selectionner une rubrique
			}
			// Validation de l'unicit? de EntrepriseRubriqueRue
			// Collection de toutes Id les entreprises qui ont deja ce nom

			//$entrepriseAInserer = trim($activite->getEntreprise());
			//$entrepriseAInsererRubrique = trim($activite->getRubriqueId());
			//$entrepriseAInsererRueId = trim($activite->getRueId());
			//$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a 
			//								WHERE a.entreprise =:entrepriseAInserer AND a.rubriqueId =:entrepriseAInsererRubrique AND a.rueId =:entrepriseAInsererRueId AND a.rueId != 0') // si la rue existe, rueId != 0
            //                               ->setParameters(array(
			//							   'entrepriseAInserer' => $entrepriseAInserer, 
			//							   'entrepriseAInsererRubrique' => $entrepriseAInsererRubrique, 
			//							   'entrepriseAInsererRueId' => $entrepriseAInsererRueId,));
			//$entreprisesDejaObj = $query->getResult();
			//if(sizeof($entreprisesDejaObj) > 0) // la rubrique n'a pas bien ?t? chang?e
			//{
			//    $validation = 7; // Veuillez selectionner une rubrique 
			//}

			// validation des coordonnés de la map: on verifie le format (latitude:float,longitude:float)
			if($form_map)
			{
				$form_mapArray = explode(',',$form_map);
				//var_dump($form_mapArray);
				is_numeric(trim($form_mapArray[0]))?($validation = $validation):($validation = 8); // latitude incorect
				is_numeric(trim($form_mapArray[1]))?($validation = $validation):($validation = 9); // longitude incorect
			}
			else
			{
				$form_map = "0,0";
			}
			// Validation de l'email
			$data10 = $contactEntrepriseModifierForm['email']->getData(); // 
			if(!filter_var($data10, FILTER_VALIDATE_EMAIL)) // l'email
			{
			    $validation = 10;  
			}
			// fin validation de l'email


			// Fin des messages de validations ///
           
		    ///////////// validations ///
			if($validation == "") // Tout va bien
			{
				//var_dump($activite);
				//// on upload les fichiers et on persist la base de donn?e avec les infos du formulaire de modif ou d'ajout

                $file01_form = $contactEntrepriseModifierForm['path01']->getData();
                $file02_form = $contactEntrepriseModifierForm['path02']->getData();
                $file03_form = $contactEntrepriseModifierForm['path03']->getData();
                
//echo "a: " . $selectedObj->getPath01() . "<br>";
//echo "b: " . $selectedObj->getPath02() . "<br>";
//echo "c: " . $selectedObj->getPath03() . "<br>";
                
				$photo = "no";
				$video = "no";
				$logo  = "no";
				// image file
                $path01 = "";
				if( $file01_form ){
					$path01 = $this->get('app.file_uploader')->upload($file01_form);	
				}
                else{
                    $path01 = $path01_old;	
                }
                $activite->setPath01($path01);
				$photo = $path01; // pour le mail à l'admin
                
                // video file
                $path02 = "";
                if( $file02_form ){
					$path02 = $this->get('app.file_uploader')->upload($file02_form);	
				}
                else{
                    $path02 = $path02_old;	
                }
                $activite->setPath02($path02);
				$video = $path02; // pour le mail à l'admin
                
                // logo file
				$path03 = "";
                if( $file03_form ){
					$path03 = $this->get('app.file_uploader')->upload($file03_form);	
				}
                else{
                    $path03 = $path03_old;	
                }
                $activite->setPath03($path03);
				$logo = $path03; // pour le mail à l'admin

				$activite->setActivated( 'oui' );

				$em->persist($activite); 
				$em->flush();

				// fin url
				$nom   = ucfirst($activite->getEntreprise());
				$email = $activite->getEmail();
				if($email == "")
				{
					$email = "inconu";
				}
				$contact=$activite->getContact();
				if($contact == "")
				{
					$contact = "Inconu";
				}
				

				// Send Ajout mail
                $type = "modification_user"; 
				$visitoremail = $email;
				$dzoomreceveur = "registration@Doualazoom.com";
				//$dzoomreceveur = "yaosoft@hotmail.com";
				// sitename, email, pays...
				$siteData = $this->getLocale();
// var_dump($siteData);
				$sender = new Sendmail($this->get('templating'), $this->get('mailer'));
				$sender->send($siteData, $visitoremail, $dzoomreceveur, $nom, $entreprise, $form_datas, $type, $photo, $video, $logo, $this->get('translator'));
				
				$translator = $this->get('translator');
				$message = $translator->trans('Modifications done!');
				
				return $this->render('ZoomStoreBundle:Show:mypage.html.twig', array(
					 'id'       => $companyid,
					 'selected' => $selected,
					 'message'  => $message,
					 'contactEntrepriseModifierForm' => $contactEntrepriseModifierObj->createView(),
					 'userModelCompany'  => $userModelCompanies,
					 'companyrepAdInfo'  => [],
			 ));
				

			}
			// validations
			// $translator = $this->get('translator');
			// echo 
			else if($validation == 1) // rubrique requise
			{
				$message = $translator->trans('please choose an activity sector');
				$dateError = new FormError($message); 
				$contactEntrepriseModifierForm->get('rubriqueId')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array(
                'contactEntrepriseAjouterForm' => $contactEntrepriseModifierForm->createView()));
			}
			else if ($validation == 2) // Téléphone01  est invalide
			{
				    $message = $translator->trans('phone number 01 is invalid');
				    $dateError = new FormError($message); 
					$contactEntrepriseModifierForm->get('telephone01')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView()));
			}
			else if ($validation == 3) // T?l?phone02  est invalide
			{
				    $message = $translator->trans('phone number 02 is invalid');
				    $dateError = new FormError($message); 
					$contactEntrepriseModifierForm->get('telephone02')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView()));
			}
			else if ($validation == 4) // Fax est invalide
			{
				    $message = $translator->trans('fax number is invalid');
				    $dateError = new FormError($message);
					$contactEntrepriseModifierForm->get('fax')->addError($dateError);
                    return $this->render('ZoomStoreBundle:Show:mypage.html.twig', array(
					 'id'       => $companyid,
					 'selected' => $selected,
					 'message'  => $message,
					 'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
					 'userModelCompany'  => [],
					 'companyrepAdInfo'  => [],
			));
			}
			else if ($validation == 5) // Nom de l'entreprise incorrect
			{
				    $message = $translator->trans('the company name must be at least 3 characters long');
				    $dateError = new FormError($message);
					$contactEntrepriseModifierForm->get('entreprise')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView()));
			}
			else if ($validation == 6) // quartier requis
			{
				    $message =  $translator->trans('Select a district please');
				    $dateError = new FormError($message);
					$contactEntrepriseModifierForm->get('quartierId')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView()));
			}
			//else if ($validation == 7)
			//{
			//	    $message = $translator->trans('this company already exists in the selected street').$nomRue;
			//	    $dateError = new FormError($message); // entreprise deja exitante
			//		$contactEntrepriseModifierForm->get('entreprise')->addError($dateError);
			//		return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('$contactEntrepriseModifierForm' => //$contactEntrepriseModifierForm->createView()));
			//}
			else if ($validation == 8)
			{ 		
				    $message = $translator->trans('invalid latitude value');
				    $dateError = new FormError($message); // latitude non valide
					$contactEntrepriseModifierForm->get('map')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView()));
			}
			else if ($validation == 9)
			{
				    $message =  $translator->trans('invalid longitude value');
				    $dateError = new FormError($message); // longitude non valide
					$contactEntrepriseModifierForm->get('map')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView()));
			}
			else if ($validation == 10)			
			{
				    $message = $translator->trans('please enter an email address');
				    $dateError = new FormError($message); // 
					$contactEntrepriseModifierForm->get('email')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView()));
			}
			//fin validations
			//affichage du formulaire d'ajout d'une entreprise
			return $this->render('ZoomStoreBundle:Show:mypage.html.twig', array(
					 'id'       => $companyid,
					 'selected' => $selected,
					 'message'  => $message,
					 'contactEntrepriseModifierForm' => $contactEntrepriseModifierObj->createView(),
					 'userModelCompany'  => [],
					 'companyrepAdInfo'  => [],
			));
		}
	}
	//
/////// Get locales variables, return array
	public function getLocale (){
		$em = $this->getDoctrine()->getManager();
		$localeObj   = $em->getRepository('ZoomDoualaBundle:Locale')->findAll();
		$localData = array();
		//
		$localData['email'] = $localeObj[0]->getEmail();
		$localData['name']  = $localeObj[0]->getSitename();
		$localData['url']   = $localeObj[0]->getSiteUrl();
		$localData['title'] = $localeObj[0]->getSiteTitle();
		$localData['ville'] = $localeObj[0]->getVille();
		$localData['pays']  = $localeObj[0]->getPays();
		//
		return $localData;
	}
}
