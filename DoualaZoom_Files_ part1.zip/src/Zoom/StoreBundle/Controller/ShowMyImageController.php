<?php

namespace Zoom\StoreBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Translation\TranslatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Zoom\DoualaBundle\Entity\Ads;
use Zoom\DoualaBundle\Entity\CompanyRep;
use Zoom\StoreBundle\Entity\Sell;
use Zoom\StoreBundle\Model\AddDate\AddDate;
use Zoom\StoreBundle\Form\CompanyRepModifForm;
use Zoom\StoreBundle\Form\imageForm;
use Zoom\DoualaBundle\Entity\Activite;
use Zoom\StoreBundle\Entity\Image;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\JsonResponse;
 
class ShowMyImageController extends Controller 
{

	// Page de modification d'une entreprise
	function myImageAction( )
	{	

		// sitename, email, pays...
		$siteData = $this->getLocale();
		// get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];
		
		$em = $this->getDoctrine()->getManager();
		$id = 6; // registrations id
		// company ref infos
		$companyrepAdInfoObj = $em->createQuery('SELECT a.adsname, a.price, a.description, a.curency
											     FROM ZoomDoualaBundle:Adstype a
											     WHERE a.id =:id'
											     )->setParameters(array('id' => $id));
		$companyrepAdInfo = $companyrepAdInfoObj->getResult();
		$translator = $this->get('translator');
		$message = "";
//		$companyRepModifObj = $em->getRepository('ZoomDoualaBundle:CompanyRep')->findOneById($companyrepid);
		// locals datas
		$localObj = $em->createQuery('SELECT a.ville, a.pays, a.indicatif, a.email, a.phone, a.curency
									  FROM ZoomDoualaBundle:Locale a')
									  ->setMaxResults(1);
		$local = $localObj->getResult();
		// all registered companies of this customer
		$userid = $this->get('security.token_storage')->getToken()->getUser()->getId();
		$userModelCompanyObj = $em->createQuery('SELECT a
											     FROM ZoomDoualaBundle:companyRegistration a
											     WHERE a.companyregistrationUserid =:userid'
											    )->setParameters(array('userid' => $userid));
		$registration_list = $userModelCompanyObj->getResult();

        // remove invalide registratinsnot found companies
        $registrations = Array();
        foreach( $registration_list as $registration){
            $companyObj = $registration->getEntrepriseId();
// $entityName = $em->getMetadataFactory()->getMetadataFor(get_class($companyObj))->getName();
// echo $entityName;

            $companyObjQuery = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a
                                   WHERE a = :obj')->setParameters(array('obj' => $companyObj,));
                  
            $companys = $companyObjQuery->getResult();
// echo $activation;
// echo "-";
            if( sizeof( $companys ) ){
                array_push( $registrations, $companys[0] );
            }
                
            // $count = sizeof( $registrations );
        } 

		return $this->render('ZoomStoreBundle:Show:image.html.twig', 
			array(
				  'message'	         => $message,
				  'local'	         => $local,
				  'companyrepAdInfo' => $companyrepAdInfo,
				  'userModelCompany' => $registrations,
				  'siteData'         => $siteData,
				  'userModelCount'   => count($registrations),
			)
		);
	}
    
    // Edit / modify an image
    function saveImageAction( Request $request ){
        $activiteId         = '';
        $imageName          = '';
        $imageDescription   = '';
        $imagePrice         = '';
        $imageId            = '';
        $file               = Array();
        $parameters = $request->request->all();
        
// $this->getRequest()->request->all();

        if( count( $parameters ) ){
            $activiteId         = $parameters[ 'companyId' ];
            $imageName          = $parameters[ 'imageName' ];
            $imageDescription   = $parameters[ 'imageDescription' ];
            $imagePrice         = $parameters[ 'imagePrice' ];
            $imageId            = $parameters[ 'imageId' ];
            $files = $request->files->get('files');
        }
        
        $em = $this->getDoctrine()->getManager();
        $company = $em->find( 'ZoomDoualaBundle:Activite', $activiteId );
        $output = Array();
        
        // save
        if( $imageId ){ // update
            $image = $em->find( 'ZoomStoreBundle:Image', $imageId );
            // name
            if( $imageName )
                $image->setName( $imageName );
            // price
            if( $imagePrice )
                $image->setPrix( $imagePrice );
            // description
            if( $imageDescription )
                $image->setDescription( $imageDescription );
            
            // persist image
            $em->persist($image);
            $em->flush();
            
            
            $output[] = $image->getId();
            
        }
        else{   // new
            foreach( $files as $file ){
                $image = new Image();
                // name
                if( $imageName )
                    $image->setName( $imageName );
                // price
                if( $imagePrice )
                    $image->setPrix( $imagePrice );
                // description
                if( $imageDescription )
                    $image->setDescription( $imageDescription );
                // path
                $path = $this->get('app.file_uploader')->upload($file);
                $image->setPath( $path );
            
                // persist company
                $company->addImage( $image );
                $em->persist($company);
                $em->flush();
                
                $output[] = $image->getId();
            }
        }
        return new JsonResponse( $output );
    }

    // List company's additional images
    function listImageAction(  Request $request ){
        $parameters = $request->request->all();
        $activiteId = $parameters[ 'companyId' ];
        
        $em = $this->getDoctrine()->getManager();
        $company    = $em->find( 'ZoomDoualaBundle:Activite', $activiteId );
        $image_tab  = $company->getImages();
        $images     = Array();
        foreach( $image_tab as $image ){
            $tab = Array();
            $tab['path']            = $image->getPath();
            $tab['description']     = ( $image->getDescription() ) ? $image->getDescription() : '';
            $tab['price']           = ( $image->getPrix() ) ? $image->getPrix() : '';
            $tab['name']            = ( $image->getName() ) ? $image->getName() : '';
            $tab['imgId']           = $image->getId();
            
            $images[] = $tab;
        }
        // $output =  json_encode( $images );
        $output = $images;
// var_dump( $output );
        return new JsonResponse( $output ); 
    }
    
    // Delete image
    function deleteImageAction(  Request $request ){
        $parameters = $request->request->all();
        $activiteId = $parameters[ 'companyId' ];
        $imageId    = $parameters[ 'imageId' ];
        $em         = $this->getDoctrine()->getManager();
        $image      = $em->find( 'ZoomStoreBundle:Image', $imageId );
        $company = '';
        if( $activiteId ){
            $company = $em->find( 'ZoomDoualaBundle:Activite', $activiteId );
        }
        else{
            $companies    = $image->getActivites();
            foreach( $companies as $v )
                $company = $v;
        }
        
        $company->removeImage($image);
        
        $em->remove($image);
        $em->flush();

        $output = $imageId;
        return new JsonResponse( $output ); 
    }
    
/////// Get locales variables, return array
	public function getLocale (){
		$em = $this->getDoctrine()->getManager();
		$localeObj   = $em->getRepository('ZoomDoualaBundle:Locale')->findAll();
		$localData = array();
		//
		$localData['email'] = $localeObj[0]->getEmail();
		$localData['name']  = $localeObj[0]->getSitename();
		$localData['url']   = $localeObj[0]->getSiteUrl();
		$localData['title'] = $localeObj[0]->getSiteTitle();
		$localData['ville'] = $localeObj[0]->getVille();
		$localData['pays']  = $localeObj[0]->getPays();
		//
		return $localData;
	}
}
