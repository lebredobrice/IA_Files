<?php

namespace Zoom\StoreBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Doctrine\Common\Collections\ArrayCollection;
/**
 * @ORM\Entity 
 * @ORM\Table(name="pmethod")
 */
class Pmethod
{
	public function __toString() {
    	return $this->paiement;
	}

   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    private $id;

   /**
 	* @ORM\Column(type="string", nullable = false)
 	*/
    private $paiement;
	
   /**
 	* @ORM\Column(type="string", nullable = false)
 	*/
    private $redirection;

   /**
 	* @ORM\Column(type="string", nullable = false)
 	*/
    private $activated;

   /**
 	* @ORM\Column(type="string", nullable = false)
 	*/
    private $recommendation;

   /**
 	* @ORM\Column(type="string", nullable = true)
 	*/
    private $logo;

   /**
 	* @ORM\Column(type="string", nullable = false)
 	*/
    private $type;
	
   /**
    * @ORM\OneToMany(targetEntity="Sell", mappedBy="pmethodid")
	*/
	private $pmethodSell;
	
    /**
     * @ORM\ManyToOne(targetEntity="Provider", inversedBy="providerPmethod")
     * @ORM\JoinColumn(name="provider_id", referencedColumnName="id", nullable = false)
     */
	protected $providerCollection;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->pmethodSell = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set paiement
     *
     * @param string $paiement
     *
     * @return pmethod
     */
    public function setPaiement($paiement)
    {
        $this->paiement = $paiement;

        return $this;
    }

    /**
     * Get paiement
     *
     * @return string
     */
    public function getPaiement()
    {
        return $this->paiement;
    }

    /**
     * Set activated
     *
     * @param string $activated
     *
     * @return pmethod
     */
    public function setActivated($activated)
    {
        $this->activated = $activated;

        return $this;
    }

    /**
     * Get activated
     *
     * @return string
     */
    public function getActivated()
    {
        return $this->activated;
    }

	/**
     * Set redirection
     *
     * @param string $redirection
     *
     * @return pmethod
     */
    public function setRedirection($redirection)
    {
        $this->redirection = $redirection;

        return $this;
    }

    /**
     * Get redirection
     *
     * @return string
     */
    public function getRedirection()
    {
        return $this->redirection;
    }

    /**
     * Set logo
     *
     * @param string $logo
     *
     * @return pmethod
     */
    public function setLogo($logo)
    {
        $this->logo = $logo;

        return $this;
    }

    /**
     * Get logo
     *
     * @return string
     */
    public function getLogo()
    {
        return $this->logo;
    }

    /**
     * Get recommendation
     *
     * @return string
     */
    public function getRecommendation()
    {
        return $this->recommendation;
    }


    /**
     * Set recommendation
     *
     * @param string $recommendation
     *
     * @return pmethod
     */
    public function setRecommendation($recommendation)
    {
        $this->recommendation = $recommendation;

        return $this;
    }

    /**
     * Add pmethodSell
     *
     * @param \DoualaBundle\Store\Sell $pmethodSell
     *
     * @return pmethodSell
     */
    public function pmethodSell($pmethodSell)
    {
        $this->pmethodSell = $pmethodSell;

        return $this;
    }

    /**
     * Remove pmethodSell
     *
     * @param \DoualaBundle\Store\Sell $pmethodSell
     */
    public function removePmethodSell($pmethodSell)
    {
        $this->pmethodSell->removeElement($pmethodSell);
    }

    /**
     * Get pmethodSell
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPmethodSell()
    {
        return $this->pmethodSell;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return pmethod
     */
    public function setType($type)
    {
        $this->type = $type;
        return $this;
    }

    /**
     * Get type
     *
     * @return pmethod
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set providerCollection
     *
     * @param Zoom\StoreBundle\Entity\Provider $providerCollection
     *
     * @return Pmethod
     */
    public function setProviderCollection($providerCollection)
    {
        $this->providerCollection = $providerCollection;

        return $this;
    }

    /**
     * Get providerCollection
     */
    public function getProviderCollection()
    {
        return $this->providerCollection;
    }
}

