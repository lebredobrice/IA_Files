<?php

namespace Zoom\StoreBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * @ORM\Entity 
 * @ORM\Table(name="image")
 */
class Image
{
   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    private $id;
    
   /**
    * @var string
    *
    * @ORM\Column(name="name", type="string", length=500, nullable=true)
    */
    private $name;
    
    /**
    * @var string
    *
    * @ORM\Column(name="prix", type="string", length=500, nullable=true)
     */
    private $prix;
	
   /**
    * @var string
    *
    * @ORM\Column(name="description", type="string", length=500, nullable=true)
    */
    private $description;

        
    /**
     * @ORM\ManyToMany(targetEntity="Zoom\DoualaBundle\Entity\Activite", mappedBy="images")
     */
    protected $activites;

    /**
     * @ORM\Column(type="string",length=255)
     * 
     */ 
    private $path;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->activites = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

   /**
    * Set path
    *
    */
    public function setPath($path)
    {
        $this->path = $path;

        return $this;
    }

   /**
    * Get path
    *
    */
    public function getPath()
    {
        return $this->path;
    }


    /**
     * Set prix
     */
    public function setPrix($prix)
    {
        $this->prix = $prix;

        return $this;
    }

    /**
     * Get prix
     */
    public function getPrix()
    {
        return $this->prix;
    }

    /**
     * Set name
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     */
    public function getDescription()
    {
        return $this->description;
    }
    
    /**
     * Remove image
     *
     * @param \Zoom\StoreBundle\Entity\Image $image
     */
    public function removeImage(\Zoom\StoreBundle\Entity\Image $image)
    {
        $this->images->removeElement($image);
    }
    
    /**
     * Add activite
     *
     * @param \Zoom\DoualaBundle\Entity\Activite $activite
     *
     * @return Tag
     */
    public function addActivite(\Zoom\DoualaBundle\Entity\Activite $activite)
    {
        $this->activites[] = $activite;
        
        return $this;
    }
 
    /**
     * Remove activite
     *
     * @param \Zoom\DoualaBundle\Entity\Activite $activite
     */
    public function removeActivite(\Zoom\DoualaBundle\Entity\Activite $activite)
    {
        $this->activites->removeElement($activite);
    }

    /**
     * Get activites
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getActivites()
    {
        return $this->activites;
    }
    
    
}

