<?php

namespace Zoom\StoreBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Doctrine\Common\Collections\ArrayCollection;
/**
 * @ORM\Entity 
 * @ORM\Table(name="provider")
 */
class Provider
{
	public function __toString() {
    	return $this->provider;
	}

   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    private $id;

   /**
 	* @ORM\Column(type="string", nullable = false)
 	*/
    private $provider;

   /**
 	* @ORM\Column(type="string", nullable = false)
 	*/
    private $merchandid;

   /**
 	* @ORM\Column(type="string", nullable = false)
 	*/
    private $mackey;

   /**
    * @ORM\OneToMany(targetEntity="Pmethod", mappedBy="providerCollection")
	*/
	private $providerPmethod;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->providerPmethod = new ArrayCollection();
    }
	
    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set provider
     *
     * @param string $provider
     *
     * @return provider
     */
    public function setProvider($provider)
    {
        $this->provider = $provider;

        return $this;
    }

    /**
     * Get provider
     *
     * @return string
     */
    public function getProvider()
    {
        return $this->provider;
    }

    /**
     * Set merchandid
     *
     * @param string $merchandid
     *
     * @return provider
     */
    public function setMerchandid($merchandid)
    {
        $this->merchandid = $merchandid;

        return $this;
    }

    /**
     * Get merchandid
     *
     * @return string
     */
    public function getMerchandid()
    {
        return $this->merchandid;
    }

    /**
     * Set mackey
     *
     * @param string $mackey
     *
     * @return mackey
     */
    public function setMackey($mackey)
    {
        $this->mackey = $mackey;

        return $this;
    }

    /**
     * Get mackey
     *
     * @return string
     */
    public function getMackey()
    {
        return $this->mackey;
    }


    /**
     * Add providerPmethod
     *
     * @param \DoualaBundle\Store\Provider $providerPmethod
     *
     * @return providerPmethod
     */
    public function providerPmethod($providerPmethod)
    {
        $this->providerPmethod = $providerPmethod;

        return $this;
    }

    /**
     * Remove providerPmethod
     *
     * @param \DoualaBundle\Store\Provider $providerPmethod
     */
    public function removeProviderPmethod($providerPmethod)
    {
        $this->providerPmethod->removeElement($providerPmethod);
    }

    /**
     * Get providerPmethod
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getProviderPmethod()
    {
        return $this->providerPmethod;
    }
}

