<?php

namespace Zoom\StoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ZoomStoreBundle extends Bundle
{
}
