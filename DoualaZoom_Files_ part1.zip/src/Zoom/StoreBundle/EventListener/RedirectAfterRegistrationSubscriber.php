<?php
namespace Zoom\StoreBundle\EventListener;
use FOS\UserBundle\Event\FormEvent;
use FOS\UserBundle\FOSUserEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Security\Http\Util\TargetPathTrait;
class RedirectAfterRegistrationSubscriber implements EventSubscriberInterface
{
    use TargetPathTrait;
    private $router;
    public function __construct(RouterInterface $router)
    {
        $this->router = $router;
    }
    public function onRegistrationSuccess(FormEvent $event)
    {
        // user is your firewall's name
        $url = $this->getTargetPath($event->getRequest()->getSession(), 'user');
        if (!$url) {
            $url = $this->router->generate('store_showcase');
        }
        $response = new RedirectResponse($url);
        $event->setResponse($response);
    }
    public static function getSubscribedEvents()
    {
        return [
            FOSUserEvents::REGISTRATION_SUCCESS => 'onRegistrationSuccess'
        ];
    }
}