<?php

	// INCLUDE CONFIG
    include('PHP_VPC_3Party_Config.php');
	
	// INCLUDE ENGINE
    include('VPCPaymentConnection.php');
    $conn = new VPCPaymentConnection();


    // This is secret for encoding the SHA256 hash
    // This secret will vary from merchant to merchant

    $secureSecret = $vpcData["vpc_SecureSecret"];

    // Set the Secure Hash Secret used by the VPC connection object
    $conn->setSecureSecret($secureSecret);


    // *******************************************
    // START OF MAIN PROGRAM
    // *******************************************
    // Sort the POST data - it's important to get the ordering right
	ksort($vpcData);
	
    // add the start of the vpcURL querystring parameters
    $vpcURL = $vpcData["vpc_ServerURL"];

    // This is the title for display
    $title  = $vpcData["Title"];


    // Remove the Virtual Payment Client URL from the parameter hash as we 
    // do not want to send these fields to the Virtual Payment Client.
    unset($vpcData["vpc_ServerURL"]); 
    unset($vpcData["SubButL"]);
    unset($vpcData["Title"]);
    unset($vpcData["vpc_SecureSecret"]);

    // Add VPC post data to the Digital Order
    foreach($vpcData as $key => $value) {
            if (strlen($value) > 0) {
                    $conn->addDigitalOrderField($key, $value);
            }
    }

    // Add original order HTML so that another transaction can be attempted.
    $conn->addDigitalOrderField("AgainLink", $againLink);

    // Obtain a one-way hash of the Digital Order data and add this to the Digital Order
    $secureHash = $conn->hashAllFields();
    $conn->addDigitalOrderField("Title", $title);
    $conn->addDigitalOrderField("vpc_SecureHash", $secureHash);
    $conn->addDigitalOrderField("vpc_SecureHashType", "SHA256");

    // Obtain the redirection URL and redirect the web browser
    $vpcURL = $conn->getDigitalOrder($vpcURL);

    header("Location: ".$vpcURL);
    //echo "<a href=$vpcURL>$vpcURL</a>";

?>