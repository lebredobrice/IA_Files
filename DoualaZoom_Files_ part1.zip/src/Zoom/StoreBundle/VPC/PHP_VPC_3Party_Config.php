﻿<?php
	
	// Fix Parameter, Do not Change
	$vpcData = array();
	$vpcData["vpc_ServerURL"] = "https://www.bitang.net/_b2iPayProd/3Party_Order.aspx";
	$vpcData["vpc_Version"] = "1";
	$vpcData["vpc_Command"] = "pay";
	
	// Return URL, Cancel URL, Notify URL
	$vpcData["vpc_ReturnURL"] = "PHP_VPC_3Party_Order_DR.php"; // URL de retour en cas de succès ou échec
	$vpcData["vpc_CancelURL"] = "PHP_VPC_3Party_Order_DR.php"; // URL de retour en cas d'annulation
	$vpcData["vpc_NotifyURL"] = "PHP_VPC_3Party_Order_Notif.php"; // URL pour la notification de la réponse
	
	// Your Account Parameter, ask to b2i
	$vpcData["vpc_Merchant"] = "zoom001"; // Required, ask to b2i
	$vpcData["vpc_AccessCode"] = "mkliIIOOMMIGFDJhgggzygdzydgYRYUN787JJGfzhdj784JGYFyUii178JUhukjjjjjjbb"; // Required, ask to b2i
	$vpcData["vpc_SecureSecret"] = "BA0E60D920EB41E89ED80DD670D4F8E8"; // Required, ask to b2i
	
	// Your Order/Product Parameter
	$vpcData["vpc_OrderInfo"] = "98457856985"; // Requis, le numéro de la commande
	$vpcData["vpc_Description"] = "DOUALA ZOOM"; // Requis, la référence du produit
	$vpcData["vpc_Amount"] = "25000"; // Requis, le montant de la commande
	
	// Sort the POST data - it's important to get the ordering right
	ksort($vpcData);

?>