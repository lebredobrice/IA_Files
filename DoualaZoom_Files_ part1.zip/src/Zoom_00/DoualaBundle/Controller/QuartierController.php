<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\Quartier;
use Zoom\DoualaBundle\Form\quartierForm;

class QuartierController extends Controller  
{    
//////////////////////////////////////////////////////////////
   
////////////////////////////////////////////////////////////////////
    public function listerAction(Request $request)
	{
		$em = $this->container->get('doctrine')->getManager();
		$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Quartier a 
	                WHERE  a.id != 0'); // exclut l'index 0
	    $quartier = $query->getResult();
		$count = sizeof($quartier);
	    if($count>0)
	    {
	        // message
		    $nombre = " ".$count."trouvés";// nombre de quartier trouvés(s)	
		    //IDs to Names
		    foreach($quartier AS $values)
		    {
				// noms des villes à partir des villeId
			    $villeId = $values->getVilleId(); 
				//echo $villeId." -" ;
			    $villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
			    $ville = $villeObj->getVille();
			    $values->setVilleId($ville); // cette variable change de type
			}	
        }
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    // var_dump($quartier);
		$pagination = $paginator->paginate($quartier, $request->query->get('page', 1)/*page number*/, 10/*limit per page*/);
	
	    return $this->render('ZoomDoualaBundle:Quartier:lister.html.twig', array(
	    'quartier' => $quartier,
		'pagination' => $pagination,
		'count' => $count,
		));
	}
////////////////////////////////////////////////////////////////////
///////// Quartier ajouter/modifier
    public function modifierAction(Request $request, $id = null)
	{
   	    $message="";
		$em = $this->getDoctrine()->getManager();
		if (isset($id)) //... une edition
		{   $quartier = $em->find('ZoomDoualaBundle:Quartier', $id);
			// modification d'une quartier existante : on recherche ses donn?es
			
			if (!$quartier)
			{
				$message='Aucune quartier trouvée';
			}
			else
			{
			    $form = $this->createForm(quartierForm::class, $quartier);
			}
		}
		else //... une nouvelle insertion
		{
			$quartier = new Quartier();
			$form = $this->createForm(quartierForm::class, $quartier );
		}
		
		$form->handleRequest($request);

		if ($form->isValid())  // insertion
		{  	
            //var_dump($quartier);
			//// on persist la base de donn?e avec les infos du formulaire de modif ou d'ajout
			$quartier->setvilleId("1"); //Douala
			$em->persist($quartier); 
			$em->flush();
		    
			// affichage des messages
			if (isset($id))     // insertion nouveau
			{   $nom=$quartier->getQuartier();
				$message_modif= $nom;
				return $this->render('ZoomDoualaBundle:Quartier:insererQuartierPageAdmin.html.twig', array('formajouter' => $form->createView(),'message_modif' => $message_modif));
			}
			else               // modification
			{
				$nom=$quartier->getQuartier();
				$message_new = $nom;
				return $this->render('ZoomDoualaBundle:Quartier:insererQuartierPageAdmin.html.twig', array('formajouter' => $form->createView(),'message_new' => $message_new));
			}
		}
		else
		{
            return $this->render('ZoomDoualaBundle:Quartier:insererQuartierPageAdmin.html.twig', array('formajouter' => $form->createView(),'message' => $message));
		}
	}
///////// Fin Quartier ajouter/modifier   
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id)
	{
	    $em = $this->container->get('doctrine')->getManager();
	    $quartier = $em->find('ZoomDoualaBundle:Quartier', $id);
	    if (!$quartier) 
		{
            throw new NotFoundHttpException("Quartier non trouvée");
        }
        $message = $quartier->getQuartier();
	    $quartierId = $id;
		$place = "Aucune";
		//Activite: Update à id=0  des  quartierId, rueId, place (Lieu) et repereId des Activite ayant pour quartier id, avant supression
		$query = $em->createQuery('UPDATE ZoomDoualaBundle:Activite a
	             SET a.quartierId = 0 , a.rueId = 0, a.repereId = 0, a.place =:place  WHERE a.quartierId = :quartierId')->setParameters(array('quartierId' => $quartierId, 'place'=>$place));
		$activites = $query->getResult();
		//Rue: Suppression à id=0  des  quartierId des Rues ayant pour quartier le quartier à supprimer
		$query = $em->createQuery('DELETE ZoomDoualaBundle:Rue a
	             WHERE a.quartierId = :quartierId')->setParameters(array('quartierId' => $quartierId,));
		$activites = $query->getResult();
		//Reperes: Suppression à id=0  des  repereIds des quartierId pour les reperes ayant pour quartier id, avant de suprimer
		$query = $em->createQuery('DELETE ZoomDoualaBundle:Repere a
	              WHERE a.quartierId = :quartierId')->setParameters(array('quartierId' => $quartierId,));
		$activites = $query->getResult();
		// suppression du quatier
		$em->remove($quartier);
        $em->flush();
        return $this->render('ZoomDoualaBundle:Quartier:supprimer.html.twig', array('message' => $message));
    }
}