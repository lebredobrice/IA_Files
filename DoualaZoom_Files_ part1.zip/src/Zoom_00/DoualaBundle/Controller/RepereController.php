<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\Repere;
use Zoom\DoualaBundle\Form\repereForm;
use Symfony\Component\Form\FormError;

class RepereController extends Controller  
{    
//////////////////////////////////////////////////////////////
   
////Lister les reperes////////////////////////////////////////////////////
    public function listerAction(Request $request)
	{
	    $em = $this->container->get('doctrine')->getManager();
        $query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Repere a 
	                   WHERE  a.id != 0'); // exclut l'index 0
	    $reperes = $query->getResult();
	    $count = sizeof($reperes);
		if($count>0)
	    {
	        // message
		    $nombre = " ".$count."trouvés";// nombre de reperes trouvés(s)	
		    //IDs to Names
		    foreach($reperes AS $values)
		    {
				// noms des quartier- à partir des quartierId
			    $quartierId = $values->getQuartierId(); 
				//echo $villeId." -" ;
			    // patch pour Gandi qui ne voit pas l'index Id = 0 
					if($quartierId != 0)
					{
						$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
						// var_dump($quartierObj);
						$quartier = ucfirst(strtolower($quartierObj->getQuartier()));
						//echo $quartier;
					}
					else
					{
						$quartier = "";
					}
					// fin patch pour Gandi qui ne voit pas l'index Id = 0 
			    $values->setQuartierId($quartier); // cette variable change de type
		       
				// noms des villes à partir des villeId
			    $villeId = $values->getVilleId(); 
				//echo $villeId." -" ;
			    // patch pour Gandi qui ne voit pas l'index Id = 0 
					if($villeId != 0)
					{
						$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
						// var_dump($quartierObj);
						$ville = ucfirst(strtolower($villeObj->getVille()));
						//echo $ville;
					}
					else
					{
						$ville = "";
					}
					// fin patch pour Gandi qui ne voit pas l'index Id = 0 
			    $values->setVilleId($ville); // cette variable change de type
			}	

        }
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    // var_dump($reperes);
		$pagination = $paginator->paginate($reperes, $request->query->get('page', 1)/*page number*/, 10/*limit per page*/);
	
	    return $this->render('ZoomDoualaBundle:Repere:lister.html.twig', array(
	    'reperes' => $reperes,
		'pagination' => $pagination,
		'count' => $count,
		));
	}
////////////////////////////////////////////////////////////////////
///////// repere ajouter/modifier
    public function modifierAction(Request $request, $id = null)
	{
   	    $message="";
		$em = $this->getDoctrine()->getManager();
		if (isset($id)) //... une edition
		{   $repere = $em->find('ZoomDoualaBundle:Repere', $id);
		    // Pour la valeur par defaut du quartier dans le formulaire
				// nom de la quartier de l'entité $activite
			$oldQuartierId =  trim($repere->getQuartierId());
		    $oldQuartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($oldQuartierId);
			$oldQuartier = $oldQuartierObj->getQuartier();
			     // Fin
				 // Cookie utilisé dans la class du formumaire quigarde oldRubriqueId
			$php_oldQuartier_cookie = "php_oldQuartier_cookie";
			$php_oldQuartier_cookievalue = $oldQuartier;
            //echo $oldRubrique." ---";
			$php_oldQuartier_cookie = "php_oldQuartier_cookie";
		    setcookie($php_oldQuartier_cookie, $php_oldQuartier_cookievalue, time() + (86400 * 30), '/');
			//echo $_COOKIE[$php_oldRubrique_cookie];
			// on verifie que le cookie nouveau cookie a deja été mis sur le server sinon on recharge la page pour le faire
			if( $oldQuartier != $_COOKIE[$php_oldQuartier_cookie] )
			{
				return $this->redirect($this->generateUrl('zoom_douala_admin_repere_modifier', array('id' => $id,)));
			}
			// Fin
			// creation du formulaire
			if (!$repere)
			{
				$message='Aucun repere trouvée';
			}
			else
			{
			    $form = $this->createForm(repereForm::class, $repere);
			}
		}
		else //... une nouvelle insertion
		{
			// Pour la valeur par defaut du quartier dans le formulaire
				// nom de la quartier de l'entité $activite
			$oldQuartierId =  0;
		    $oldQuartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($oldQuartierId);
			$oldQuartier = $oldQuartierObj->getQuartier();
			     // Fin
				 // Cookie utilisé dans la class du formumaire quigarde oldRubriqueId
			$php_oldQuartier_cookie = "php_oldQuartier_cookie";
			$php_oldQuartier_cookievalue = $oldQuartier;
            //echo $oldRubrique." ---";
			$php_oldQuartier_cookie = "php_oldQuartier_cookie";
		    setcookie($php_oldQuartier_cookie, $php_oldQuartier_cookievalue, time() + (86400 * 30), '/');
			//echo $_COOKIE[$php_oldRubrique_cookie];
			// on verifie que le cookie nouveau cookie a deja été mis sur le server sinon on recharge la page pour le faire
			if( $oldQuartier != $_COOKIE[$php_oldQuartier_cookie] )
			{
				return $this->redirect($this->generateUrl('zoom_douala_admin_repere_modifier', array('id' => $id,)));
			}
			// Fin
			
			$repere = new repere();
			$form = $this->createForm(repereForm::class, $repere );
		}
		$form->handleRequest($request);

		if ($form->isValid())  // insertion
		{  	
            $data01 = $form['quartierId']->getData(); // on verifie que le champ Quartier a été modifié avant de persister
			$rubriqueformId = $data01->getId();        
			if($rubriqueformId != 0) // rubrique est obligatoire
			{
			    
				// Id des quartier à partir du nom du quartier avant de flush
			    $quartier = trim($form['quartierId']->getData());
			    $quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
			    $quartierId = $quartierObj->getId();
			    $repere->setQuartierId($quartierId);
				//// on persist la base de donn?e avec les infos du formulaire de modif ou d'ajout
				$repere->setvilleId("1"); //Douala
				$em->persist($repere); 
				$em->flush();
		    
			    // affichage des messages
				if (isset($id))     // insertion nouveau
				{   $nom=$repere->getrepere();
					$message_modif = $nom;
					return $this->render('ZoomDoualaBundle:Repere:insererReperePageAdmin.html.twig', array(
					'formajouter' => $form->createView(),
					'message_modif' => $message_modif));
				}
				else               // modification
				{
					$nom=$repere->getrepere();
					$message_new = $nom;
					return $this->render('ZoomDoualaBundle:Repere:insererReperePageAdmin.html.twig', array(
					'formajouter' => $form->createView(),
					'message_new' => $message_new));
				}
			}
			else
			{
				$dateError = new FormError("choisissez un quartier ici!"); // rubrique non choisis
				$form->get('quartierId')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Repere:insererReperePageAdmin.html.twig', array(
				'formajouter' => $form->createView(),
				)); 
			}
		}
		else
		{
            return $this->render('ZoomDoualaBundle:Repere:insererReperePageAdmin.html.twig', array('formajouter' => $form->createView(),'message' => $message));
		}
	}
///////// Fin repere ajouter/modifier   
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id)
	{
	    $em = $this->container->get('doctrine')->getManager();
	    $repere = $em->find('ZoomDoualaBundle:Repere', $id);
	    if (!$repere) 
		{
            throw new NotFoundHttpException("repere non trouvée");
        }
        $message = $repere->getrepere();
	    $repereId = $id;
		// Update à id=0  des  repereId des activités ayant pour repere id, avant de supprimer
		$query = $em->createQuery('UPDATE ZoomDoualaBundle:Activite a
	             SET a.repereId = 0 WHERE a.repereId =:repereId')->setParameters(array('repereId' => $repereId,));
		$activites = $query->getResult();
		// suppression du repere
		$em->remove($repere);
        $em->flush();
        return $this->render('ZoomDoualaBundle:Repere:supprimer.html.twig', array('message' => $message));
    }
}