<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\CompanyRep;
use Zoom\DoualaBundle\Form\ModelForm;
use Zoom\StoreBundle\Model\AddDate\AddDate;

class ModelController extends Controller  
{
//////////////////////////////////////////////////////////////
   
////////////////////////////////////////////////////////////////////
    public function listerAction(Request $request)
	{
		$em = $this->getDoctrine()->getManager();
		$adsObj = $em->createQuery("SELECT a FROM ZoomDoualaBundle:CompanyRep a");
		$ads = $adsObj->getResult();
		$count = sizeof($ads);

	    if($count > 0)
	    {
			$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    	// var_dump($ads);
			$pagination = $paginator->paginate($ads, $request->query->get('page', 1)/*page number*/, 50/*limit per page*/);
		
			// calcul de la duree restante pour chaque ad and put it in an array
			$datesObj = $em->createQuery("SELECT a.startdate, a.duree FROM ZoomDoualaBundle:CompanyRep a") ;
			$dates = $datesObj->getResult();
			$remainingDaysArray = array(); 
			$dateAdd = new AddDate;
			$i = 0;
			$datedepart = 0;
			foreach($dates as $value){
				$datedepart = $value["startdate"];
				$duree = $value["duree"];
				$dateFin = $dateAdd->endCycle($datedepart, $duree);
				$datefinSecondes = strtotime($dateFin);
				$datedujourSecondes =  strtotime(\date('d-m-Y'));
				$reminingSeconde = $datefinSecondes - $datedujourSecondes;
				$remainingDaysArray[$i] = $reminingSeconde / 86400;
				$i++;
			}
		}
		else{
			$pagination = NULL;
			$remainingDaysArray = array();
			$ads =  array();
		}
		//
	    return $this->render('ZoomDoualaBundle:Model:lister.html.twig', array(
	    'ads'                => $ads,
		'remainingDaysArray' => $remainingDaysArray,
		'pagination'         => $pagination,
		'count'              => $count,
		));
	}
////////////////////////////////////////////////////////////////////
///////// Model ajouter/modifier
    public function modifierAction(Request $request, $id = null)
	{
//		error_reporting(E_ALL); 
		ini_set('memory_limit', '-1' ); 
//		ini_set('display_errors', 1); 
		
   	    $message = "";
		$titre = "";
		$curentAd =  "";
		$message_new =  "";
		$message_modif =  "";
		$description =  "";

		$em = $this->getDoctrine()->getManager();
		if (isset($id)){ //... une edition
		    $ads = $em->find('ZoomDoualaBundle:CompanyRep', $id);
			$titre="Modifier";
			if (!$ads)
			{
				$message='Aucune ads trouv�e';
			}
		}
		else{ //... une nouvelle insertion
			$titre = "Ajouter";
			$ads = new CompanyRep;
		}
		// date de debut
		if (!isset($id)){
			$date = \date('d-m-Y');
			$ads->setStartdate($date); 
		}
		// createthe form with the right ads object
		$form = $this->createForm(ModelForm::class, $ads );

		//	handleRequest
		$form->handleRequest($request);

		if ($form->isSubmitted() && $form->isValid()){  // insertion
			$formdataobj   = $form->getData();
			$entrepriseId  = $request->request->get('entrepriseId');
			$entrepriseObj = $em->find('ZoomDoualaBundle:Activite', $entrepriseId);
			$entreprise = $entrepriseObj->getEntreprise();
			// save
			$em = $this->getDoctrine()->getManager();
            $em->persist($formdataobj);
			$em->flush();
			// messages
			if (isset($id)){     // modification
			  
				// message � aficher
				$message_modif = "L'entreprise modele $entreprise ($entrepriseId) a bien ete modifiee.";
				$message_new = "";
			}
			else{             // insertion nouveau
				
				$message_new   = "L'entreprise modele $entreprise ($entrepriseId) a bien ete ajoutee.";
				$message_modif = "";
			}
			return $this->render('ZoomDoualaBundle:Model:inserer.html.twig', array
									(
										'formajouter' => $form->createView(),
										'message' => $message, 'titre' => $titre, 
										'curent'=>$curentAd, 'description'=>$description, 
										'message_modif'=>$message_modif, 
										'message_new'=>$message_new
									)
								);
		}
		else{
            return $this->render('ZoomDoualaBundle:Model:inserer.html.twig', array
									(
										'formajouter' => $form->createView(),
										'message' => $message, 
										'titre' => $titre, 
										'curent'=>$curentAd, 
										'description'=>$description, 
										'message_modif'=>$message_modif, 
										'message_new'=>$message_new
									)
								);
		}
	}
///////// Fin Model ajouter/modifier   
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id)
	{
	    $em = $this->container->get('doctrine')->getManager();
	    $ads = $em->find('ZoomDoualaBundle:CompanyRep', $id);
	    if (!$ads) 
		{
            throw new NotFoundHttpException("Model non trouv�e");
        }
        $message = "entreprise modele";
	    $adsId = $id;

		//Reperes: Suppression � id=0  des  repereIds des adsId pour les reperes ayant pour ads id, avant de suprimer
		$query = $em->createQuery('DELETE ZoomDoualaBundle:CompanyRep a
	              WHERE a.id = :adsId')->setParameters(array('adsId' => $adsId,));
		$activites = $query->getResult();
		// suppression de la publicit�
        $em->flush();
        return $this->render('ZoomDoualaBundle:Model:supprimer.html.twig', array('message' => $message));
    }
}