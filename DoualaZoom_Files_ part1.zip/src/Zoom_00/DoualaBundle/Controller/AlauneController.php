<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\CompanyAlaune;
use Zoom\DoualaBundle\Form\AlauneForm;
use Zoom\StoreBundle\Model\AddDate\AddDate;

class AlauneController extends Controller  
{
//////////////////////////////////////////////////////////////
   
////////////////////////////////////////////////////////////////////
    public function listerAction(Request $request)
	{
		$em = $this->getDoctrine()->getManager();
		$adsObj = $em->createQuery("SELECT a FROM ZoomDoualaBundle:CompanyAlaune a");
		$ads = $adsObj->getResult();
		$count = sizeof($ads);

	    if($count > 0)
	    {
			$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    	// var_dump($ads);
			$pagination = $paginator->paginate($ads, $request->query->get('page', 1)/*page number*/, 50/*limit per page*/);
		
			// calcul de la duree restante pour chaque ad and put it in an array
			$datesObj = $em->createQuery("SELECT a.startdate, a.duree FROM ZoomDoualaBundle:CompanyAlaune a") ;
			$dates = $datesObj->getResult();
			$remainingDaysArray = array(); 
			$dateAdd = new AddDate;
			$i = 0;
			$datedepart = 0;
			foreach($dates as $value){
				$datedepart = $value["startdate"];
				$duree = $value["duree"];
				$dateFin = $dateAdd->endCycle($datedepart, $duree);
				$datefinSecondes = strtotime($dateFin);
				$datedujourSecondes =  strtotime(\date('d-m-Y'));
				$reminingSeconde = $datefinSecondes - $datedujourSecondes;
				$remainingDaysArray[$i] = $reminingSeconde / 86400;
				$i++;
			}
		}
		else{
			$pagination = NULL;
			$remainingDaysArray = array();
			$ads =  array();
		}
		//
	    return $this->render('ZoomDoualaBundle:Alaune:lister.html.twig', array(
	    'ads'                => $ads,
		'remainingDaysArray' => $remainingDaysArray,
		'pagination'         => $pagination,
		'count'              => $count,
		));
	}
////////////////////////////////////////////////////////////////////
///////// A la une ajouter/modifier
    public function modifierAction(Request $request, $id = null)
	{
//		error_reporting(E_ALL); 
		ini_set('memory_limit', '-1' ); 
//		ini_set('display_errors', 1); 
		
   	    $message = "";
		$titre = "";
		$curentAd =  "";
		$message_new =  "";
		$message_modif =  "";
		$description =  "";

		$em = $this->getDoctrine()->getManager();
		if (isset($id)){ //... une edition
		    $ads = $em->find('ZoomDoualaBundle:CompanyAlaune', $id);
			$titre="Modifier";
			if (!$ads)
			{
				$message='Aucune ads trouvée';
			}
		}
		else{ //... une nouvelle insertion
			$titre = "Ajouter";
			$ads = new CompanyAlaune;
		}
		// date de debut
		if (!isset($id)){
			$date = \date('d-m-Y');
			$ads->setStartdate($date); 
		}
		// createthe form with the right ads object
		$form = $this->createForm(AlauneForm::class, $ads );

		//	handleRequest
		$form->handleRequest($request);

		if ($form->isSubmitted() && $form->isValid()){  // insertion
			$formdataobj   = $form->getData();
			$entrepriseId  = $request->request->get('entrepriseId');
			$entrepriseObj = $em->find('ZoomDoualaBundle:Activite', $entrepriseId);
			$entreprise = $entrepriseObj->getEntreprise();
			// save
			$em = $this->getDoctrine()->getManager();
            $em->persist($formdataobj);
			$em->flush();
			// messages
			if (isset($id)){     // modification
			  
				// message à aficher
				$message_modif = "L'entreprise A la une $entreprise ($entrepriseId) a bien ete modifiee.";
				$message_new = "";
			}
			else{             // insertion nouveau
				
				$message_new   = "L'entreprise A la une $entreprise ($entrepriseId) a bien ete ajoutee.";
				$message_modif = "";
			}
			return $this->render('ZoomDoualaBundle:Alaune:inserer.html.twig', array
									(
										'formajouter' => $form->createView(),
										'message' => $message, 'titre' => $titre, 
										'curent'=>$curentAd, 'description'=>$description, 
										'message_modif'=>$message_modif, 
										'message_new'=>$message_new
									)
								);
		}
		else{
            return $this->render('ZoomDoualaBundle:Alaune:inserer.html.twig', array
									(
										'formajouter' => $form->createView(),
										'message' => $message, 
										'titre' => $titre, 
										'curent'=>$curentAd, 
										'description'=>$description, 
										'message_modif'=>$message_modif, 
										'message_new'=>$message_new
									)
								);
		}
	}
///////// Fin Alaune ajouter/modifier   
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id)
	{
	    $em = $this->container->get('doctrine')->getManager();
	    $ads = $em->find('ZoomDoualaBundle:CompanyAlaune', $id);
	    if (!$ads) 
		{
            throw new NotFoundHttpException("Entreprise à la une non trouvée");
        }
        $message = "entreprise A la une";
	    $adsId = $id;

		//Reperes: Suppression à id=0  des  repereIds des adsId pour les reperes ayant pour ads id, avant de suprimer
		$query = $em->createQuery('DELETE ZoomDoualaBundle:CompanyAlaune a
	              WHERE a.id = :adsId')->setParameters(array('adsId' => $adsId,));
		$activites = $query->getResult();
		// suppression de la publicité
        $em->flush();
        return $this->render('ZoomDoualaBundle:Alaune:supprimer.html.twig', array('message' => $message));
    }
}