<?php
namespace Zoom\DoualaBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Zoom\DoualaBundle\Entity\Translation;
use Zoom\DoualaBundle\Entity\Tablelist;
use Zoom\DoualaBundle\Entity\Language;
use Zoom\DoualaBundle\Form\TranslationForm; 
use Symfony\Component\Form\FormError;

class TranslationController extends Controller  
{    
//////////////////////////////////////////////////////////////
   
////////////////////////////////////////////////////////////////////
    public function listerAction(Request $request)
	{
	    $em = $this->container->get('doctrine')->getManager();

		// creation de la table des mots sources traduits
		$translationObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Translation a');
		$translations = $translationObj->getResult();
		$translationArray = [];
		if (count($translations)){
			
			$i = 0;
			foreach($translations as $key=>$value){
				// retrouver le terme traduit à partir de son id et son tableid
				// id de la table d'origine de la translation
				$tableid = $value->getTableid();

		   	 		// nom de la table			
				$tableObj =  $em->getRepository('ZoomDoualaBundle:Tablelist')->findOneById(array($tableid));
				$tablename = $tableObj->getName();
					// entity name
				$tableEntity = ucfirst($tablename);
					// Id du terme traduit
				$translatedid = $value->getTranslatedid();
// var_dump($translatedid);
					// terme traduit
				$translatedObj = $em->createQuery("SELECT a FROM ZoomDoualaBundle:$tableEntity a
													    WHERE a.id = $translatedid");
				$translateds = $translatedObj->getResult();
// echo 'tableEntity:'.$tableEntity."--";
// echo $translateds[0]->getId()."<br>";
				$function = "get".$tableEntity;
				if($translateds[0]){
					$translated = $translateds[0]->$function();
					// fabrication de l'array à envoyer à la vue
					$translationArray[$i] = $translated;
					
				}
				else{
					$translationArray[$i] = "Not found";
				}
				$i++;
			}
		}
		$count = count($translations);
	     // message
		$nombre = " ".$count."trouvés";// nombre de Translations trouvés(s)	
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
// var_dump($translation->getTableid());
		$pagination = $paginator->paginate($translations, $request->query->get('page', 1)/*page number*/, 50/*limit per page*/);
//		echo '<pre>';
//	    	var_dump($translationArray);
//		echo '</pre>';
	    return $this->render('ZoomDoualaBundle:Translation:lister.html.twig', array(
	    					 'translation' => $translations,
							 'translated' => $translationArray,
							 'pagination' => $pagination,
							 'count' => $count,
		));
	}
////////////////////////////////////////////////////////////////////
///////// Translation ajouter
    public function ajouterAction(Request $request, $id = null)
	{
	    $em = $this->container->get('doctrine')->getManager();
		$translation = new Translation;
		$message="";
		if ($_POST) {
    		// verify if this translation not exixt in the database
			$exist = $em->getRepository('ZoomDoualaBundle:Translation')->findOneBy(array(
														"tableid"=>$_POST['tableslist'],
														"languageid"=>$_POST['languageslist'],
														"translatedid"=>$_POST['termslist']
																			));
			if(!$exist){// not existing in the database, we can persist
				// many to one objets object
				$tablelist = $em->getRepository('ZoomDoualaBundle:Tablelist')->findOneById($_POST['tableslist']);
				$language =  $em->getRepository('ZoomDoualaBundle:Language')->findOneById($_POST['languageslist']);
		
				$translation->setTableid($tablelist); // many to one
				$translation->setLanguageid($language); // many to one
				$translation->setTranslatedid($_POST['termslist']);
				$translation->setTranslation($_POST['traduction']);
				//$em->persist($tablelist); // persist			
				//$em->persist($language); // persist
				$em->persist($translation); // persist
				// saving
				$em->flush();
				// message
				$message = 'La traduction '.trim($_POST['traduction']).' a été créée.';
				return $this->render('ZoomDoualaBundle:Translation:ajouter.html.twig', array('message'=>$message));
			}
			else{
				$message = 'La traduction '.$_POST['traduction'].' existe deja pour la table choisie';
				return $this->render('ZoomDoualaBundle:Translation:ajouter.html.twig', array('message'=>$message));
			}
		}
		$message = 'Enregistrer une nouvelle traduction.';
		return $this->render('ZoomDoualaBundle:Translation:ajouter.html.twig', array('message'=>$message));
	}
///////// Fin Translation ajouter/modifier

////////// Modifier  /////////////
////////////////////////////////////////////////////////////////////
///////// fonction modifier
    public function modifierAction(Request $request, $id = null, $totranslate)
	{
   	    $message="";
		$em = $this->getDoctrine()->getManager();
		if (isset($id)) //... une edition
		{   
			$translation = $em->find('ZoomDoualaBundle:Translation', $id);
			// creation du formulaire
			if (!$translation)
			{
				$translation='Aucun traduction trouvée';
			}
			else
			{
			    $form = $this->createForm(TranslationForm::class, $translation);
			}
		}
		
		$form->handleRequest($request);

		if ($form->isValid())  // insertion
		{  	
            $em->persist($translation); 
			$em->flush();
		    // affichage des messages
			if (isset($id))     // insertion nouveau
			{   
			    $translation = $translation->getTranslation();
				$message = "La traduction ".$translation." a été modifiéé";
				return $this->render('ZoomDoualaBundle:Translation:modifier.html.twig', array(
					'formmodifier' => $form->createView(),
					'message' => $message,
					'totranslate' => $totranslate,
					));
			}
		}
		else
		{
            return $this->render('ZoomDoualaBundle:Translation:modifier.html.twig', array(
				'formmodifier' => $form->createView(),
				'message' => $message,
				'totranslate' => $totranslate,
				));
		}
	}
///////// Fin fonction ajouter/modifier   
////////// Fin modidifer ////////
////////////////////////////////////////////////////////////////////
    public function supprimerAction($id)
	{
	    $em = $this->container->get('doctrine')->getManager();
	    $translation = $em->find('ZoomDoualaBundle:Translation', $id);
	    if (!$translation) 
		{
            throw new NotFoundHttpException("Traduction non trouvée");
        }
        $message = $translation->getTranslation();
		// suppression de la Translation
		$em->remove($translation);
        $em->flush();
        return $this->render('ZoomDoualaBundle:Translation:supprimer.html.twig', array('message' => $message));
    }
}