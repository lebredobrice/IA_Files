<?php

namespace Zoom\DoualaBundle\Model;

class Dbconnexion
{
	public function connect(){
		// parameters
		$dsn = 'mysql:dbname=default_db;host=localhost';
		$user = 'root';
		$password = '';
		// connexion
    	try {
    		$dbh = new \PDO($dsn, $user, $password);
    		// echo 'Connexion reusie';
			return $dbh;
		} 
		catch (PDOException $e) {
    		echo 'Connexion �chou�e : ' . $e->getMessage();
		}
	}
}