<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType; 

class ActiviteForm extends AbstractType
{
	public function buildForm(FormBuilderInterface $builder, array $options)
    {   
	    // old repere
		$cookiename = "php_oldRepere_cookie";
		$repere = $_COOKIE[$cookiename];
		// old rue
		$cookiename = "php_oldRue_cookie";
		$rue = $_COOKIE[$cookiename];
		// old quartier
		$cookiename = "php_oldQuartier_cookie";
		if($_COOKIE[$cookiename])
		{
			$php_oldQuartier_cookie = $_COOKIE[$cookiename];
		}
		// old rubrique
		$cookiename = "php_oldRubrique_cookie";
		if($_COOKIE[$cookiename])
		{
			$php_oldRubrique_cookie = $_COOKIE[$cookiename];
		}
		// activated value 01
		$cookiename = "php_activated_value01_cookie";
		if($_COOKIE[$cookiename])
		{
			$php_activated_value01_cookie = $_COOKIE[$cookiename];
		}
		else
		{
			$php_activated_value01_cookie = 'oui';
		}
		// activated value 02
		$cookiename = "php_activated_value02_cookie";
		if($_COOKIE[$cookiename])
		{
			$php_activated_value02_cookie = $_COOKIE[$cookiename];
		}
		else
		{
			$php_activated_value02_cookie = 'no';
		}
		// old date
		//$cookiename = "php_oldDate_cookie";
		//if($_COOKIE[$cookiename]){ // si c une modif
			//php_date_cookie = new \DateTime();
			//$dateTab = explode('-', $_COOKIE[$cookiename]);
			//$day = intval(trim($dateTab[0]));
			//$month = intval(trim($dateTab[1]));
			//$year = intval(trim($dateTab[2]));
// echo $cookiename.' = '.$_COOKIE[$cookiename];
			//$php_date_cookie->setdate($year, $day, $month);
			//unset($_COOKIE[$cookiename]);
		//}
		//else
		//{
		//	$php_date_cookie = new \DateTime();
		//}
		$builder
          ->add('entreprise', TextType::class, array('label' =>'Nom'))
          ->add('bp', TextType::class, array('required' => false))
          ->add('telephone01', TextType::class,array('required' => true))
          ->add('telephone02', TextType::class, array('required' => false))
          ->add('fax', TextType::class, array('required' => false))
          ->add('email', EmailType::class, array('required' => false))
          ->add('web', TextType::class, array('required' => false,))
          ->add('contact', TextType::class, array('label'=>'Nom du contact','required' => false))
          ->add('fonctionId', EntityType::class, array(
				'label' =>'Fonction',
				'class' => 'ZoomDoualaBundle:Fonction', 
				'query_builder' => function(EntityRepository $er) {
		                     $cookiename = "php_oldFonction_cookie";
					         $fonction = $_COOKIE[$cookiename];	
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.fonction = :fonction THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
							 ->setParameters(array('fonction' => $fonction)); 
                             unset($_COOKIE[$cookiename]);
							 }
							 ))	
          ->add('villeId',EntityType::class, array('label' =>'Ville', 'class' => 'ZoomDoualaBundle:Ville'))	
          ->add('quartierId', EntityType::class, array(
				'label' =>'Quartier',
				'class' => 'ZoomDoualaBundle:Quartier', 
				'query_builder' => function(EntityRepository $er) {
		                     $cookiename = "php_oldQuartier_cookie";
					         $quartier = $_COOKIE[$cookiename];	
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.quartier = :quartier THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
							 ->setParameters(array('quartier' => $quartier)); 
                             unset($_COOKIE[$cookiename]);
							 }
							 ))
          ->add('rueId', TextType::class, array('label' =>'Rue', 'data'=>$rue, 'required' => false))	
	      ->add('repereId', TextType::class, array('label' =>'.', 'data'=>$repere, 'required' => false, ))	
          ->add('rubriqueId', EntityType::class, array(
				'label' =>'Rubrique',
				'class' => 'ZoomDoualaBundle:Rubrique', 
				'query_builder' => function(EntityRepository $er) {
		                     $cookiename = "php_oldRubrique_cookie";
					         $rubrique = $_COOKIE[$cookiename];	
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.rubrique = :rubrique THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
                             ->addOrderBy('ss.rubrique', 'ASC')
							 ->setParameters(array('rubrique' => $rubrique)); 
                             unset($_COOKIE[$cookiename]);
							 }
							 ))
          ->add('place', TextType::class, array('label' =>'Détail', 'required' => false))
          ->add('map', TextType::class, array('required' => false))
          ->add('date', DateType::class, array('widget' => 'single_text', 'format' => 'dd-MM-yyyy', 'attr' => array('style' => ('display:inline'))))
          ->add('rueId_primary_key', HiddenType::class) // champ ajouté pour la combobox (listbox + textbox)
		  ->add('path01', FileType::class,  array('attr'=>array('style'=>(' border:none')),'required' => false, 'data_class' =>NULL,'label' => 'Photo de l\'entreprise (.jpg)'))
		  ->add('path02', FileType::class, array('attr'=>array('style'=>(' border:none')), 'required' => false, 'data_class' =>NULL,'label' => 'Animation vidéo (.flv)'))
		  ->add('path03', FileType::class, array('attr'=>array('style'=>(' border:none')),'required' => false, 'data_class' =>NULL,'label' => 'Logo de l\'entreprise (.jpg, .gif)'))
		  ->add('activated', ChoiceType::class, array('attr' => array('style' => ('width:80px;')),
			    'label'  => 'Activer',
			    'choices' => array($php_activated_value01_cookie => $php_activated_value01_cookie, $php_activated_value02_cookie => $php_activated_value02_cookie)
		  ,))	;
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}

}