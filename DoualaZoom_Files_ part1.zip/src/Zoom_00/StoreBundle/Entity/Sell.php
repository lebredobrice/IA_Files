<?php

namespace Zoom\StoreBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Doctrine\Common\Collections\ArrayCollection;
/**
 * @ORM\Entity 
 * @ORM\Table(name="sell")
 */
class Sell
{
   /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer")
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    */
    private $id;

    /**
    * @var string
    *
    * @ORM\Column(name="sellid", type="string", length=500)
     */
    private $sellid;

    /**
    * @var string
    *
    * @ORM\Column(name="total", type="string", length=500)
     */
    private $total;
	
   /**
    * @var string
    *
    * @ORM\Column(name="description", type="string", length=500)
    */
    private $description;

    /**
     * @ORM\ManyToOne(targetEntity="Zoom\UserBundle\Entity\User", inversedBy="userSell")
     * @ORM\JoinColumn(name="userid", referencedColumnName="id", nullable = false)
     */
    private $userid;

    /**
     * @ORM\ManyToOne(targetEntity="Zoom\StoreBundle\Entity\Pmethod", inversedBy="pmethodSell")
     * @ORM\JoinColumn(name="pmethod_id", referencedColumnName="id", nullable = false)
     */
    private $pmethodid;

    /**
     * @var string
     *
     * @ORM\Column(name="date", type="string", length=500)
     */
    private $selldate;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set sellid
     *
     * @param string $sellid
     *
     * @return Sell
     */
    public function setSellid($sellid)
    {
        $this->sellid = $sellid;

        return $this;
    }

    /**
     * Get sellid
     *
     * @return string
     */
    public function getSellid()
    {
        return $this->sellid;
    }

    /**
     * Set total
     *
     * @param string $total
     *
     * @return Sell
     */
    public function setTotal($total)
    {
        $this->total = $total;

        return $this;
    }

    /**
     * Get total
     *
     * @return int
     */
    public function getTotal()
    {
        return $this->total;
    }

    /**
     * Set selldate
     *
     * @param string $selldate
     *
     * @return Sell
     */
    public function setSelldate($selldate)
    {
        $this->selldate = $selldate;

        return $this;
    }

    /**
     * Get selldate
     *
     * @return int
     */
    public function getSelldate()
    {
        return $this->selldate;
    }

    /**
     * Set userid
     *
     * @param Zoom\UserBundle\Entity\User $user
     *
     * @return Sell
     */
    public function setUserid($user)
    {
        $this->userid = $user;

        return $this;
    }

    /**
     * Get userid
     *
     * @return Zoom\UserBundle\Entity\User
     */
    public function getUserid()
    {
        return $this->userid;
    }

    /**
     * Set pmethodid
     *
     * @param Zoom\StoreBundle\Entity\Pmethod $pmethodid
     *
     * @return Sell
     */
    public function setPmethodid($pmethodid)
    {
        $this->pmethodid = $pmethodid;

        return $this;
    }

    /**
     * Get pmethodid
     *
     */
    public function getPmethodid()
    {
        return $this->pmethodid;
    }


    /**
     * Set description
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     */
    public function getDescription()
    {
        return $this->description;
    }
}

