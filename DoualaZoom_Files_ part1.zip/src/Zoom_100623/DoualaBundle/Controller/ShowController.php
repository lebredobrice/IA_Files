<?php 
namespace Zoom\DoualaBundle\Controller;

use Zoom\DoualaBundle\Form\RueForm; 
use Zoom\DoualaBundle\Form\rechercheRubriqueShowForm;
use Zoom\DoualaBundle\Form\rechercheActiviteShowForm;
use Zoom\DoualaBundle\Form\rechercheQuartierShowForm;
use Zoom\DoualaBundle\Form\layoutSearchByNameForm;
use Zoom\DoualaBundle\Form\layoutSearchByRubriqueForm;
use Zoom\DoualaBundle\Form\contactEntrepriseAjouterForm;
use Zoom\DoualaBundle\Form\contactEntrepriseIntroForm;
use Zoom\DoualaBundle\Form\contactEntrepriseModifierForm;
use Zoom\DoualaBundle\Form\contactEntrepriseOkForm;
use Zoom\DoualaBundle\Form\layoutSearchByQuartierForm;
use Zoom\DoualaBundle\Form\layoutContactForm;
use Zoom\DoualaBundle\Form\layoutErrorForm; 
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Doctrine\DBAL\Event\Listeners\MysqlSessionInit;
use Zoom\DoualaBundle\Entity\Rue;
use Zoom\DoualaBundle\Entity\Repere;
use Zoom\DoualaBundle\Entity\Prestation;
use Zoom\DoualaBundle\Entity\Rubrique;
use Zoom\DoualaBundle\Entity\Activite;
use Zoom\DoualaBundle\Entity\Quartier;
use Zoom\DoualaBundle\Entity\Pgard;
use Zoom\DoualaBundle\Entity\Usefulltype;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Response; 
use Symfony\Component\Translation\TranslatorInterface;
use Zoom\DoualaBundle\Model\Tablearray\Tablearray;
use Zoom\DoualaBundle\Model\Translate\Translate;
use Zoom\DoualaBundle\Model\Reversetranslate\Reversetranslate;
use Zoom\DoualaBundle\Model\Languagefromurl\Languagefromurl;
use Zoom\DoualaBundle\Model\Sendmail\Sendmail;
use Zoom\DoualaBundle\Model\KeysOfDuplicateValues\KeysOfDuplicateValues;

class ShowController extends Controller 
{
////////////////////////////////////// RENDU DU TOP MENU  /////////////////////////// 
	public function layout_top_menuAction() 
    {
    //Top menu url for language selection and featured links
		$link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";// full url
		$linktable = explode('/', $link); // full url exploded
		if(strpos($link,'/fr')){ // french is the current Local
			// Lien du bouton de la langue en cours (french)
			$links['french']  = $link;
			$links['english'] = str_replace('/fr', '/en', $link);
			$links['chinese'] = str_replace('/fr', '/cn', $link); 
			$links['spain']   = str_replace('/fr', '/es', $link);
			$links['arab']    = str_replace('/fr', '/ar', $link);
			//
			$langue = 'Français';
		}
		else if(strpos($link,'/en')){ // english is the current Local
			// Lien du bouton de la langue en cours (french)
			$links['english'] = $link;
			$links['french']  = str_replace('/en', '/fr', $link);
			$links['chinese'] = str_replace('/en', '/cn', $link);
			$links['spain']   = str_replace('/en', '/es', $link);
			$links['arab']    = str_replace('/en', '/ar', $link);
			//
			$langue = 'English';
		}
		else if(strpos($link,'/cn')){ // english is the current Local
			// Lien du bouton de la langue en cours (french)
			$links['chinese'] = $link;
			// Autres bouton de langue en cours (french)
			$links['chinese'] = $link;
			$links['english'] = str_replace('/cn', '/en', $link);
			$links['french']  = str_replace('/cn', '/fr', $link);
			$links['spain']   = str_replace('/cn', '/es', $link);
			$links['arab']    = str_replace('/cn', '/ar', $link);
			$langue = 'Chinese';
		}
		else if(strpos($link,'/es')){ // english is the current Local
			// Lien du bouton de la langue en cours (french)
			$links['spain'] = $link;
			// Autres bouton de langue en cours (french)
			$links['spain']   = $link;
			$links['english'] = str_replace('/es', '/en', $link);
			$links['french']  = str_replace('/es', '/fr', $link);
			$links['chinese'] = str_replace('/es', '/cn', $link);
			$links['arab']    = str_replace('/es', '/ar', $link);
			$langue           = 'Spain';
		}
		else if(strpos($link,'/ar')){ // english is the current Local
			// Lien du bouton de la langue en cours (french)
			$links['spain'] = $link;
			// Autres bouton de langue en cours (french)
			$links['arab']    = $link;
			$links['english'] = str_replace('/ar', '/en', $link);
			$links['french']  = str_replace('/ar', '/fr', $link);
			$links['chinese'] = str_replace('/ar', '/cn', $link);
			$links['spain']   = str_replace('/ar', '/es', $link);
			$langue 		  = 'Arab';
		}
		return $this->render('ZoomDoualaBundle:Show:layout_top_menu.html.twig', array(
							 'selectedlangue'=> $langue,
							 'linktable' => $links,
							  ));
	}

///////////////////////// RENDU DU BOUTON AJOUT/SUPRESSION D4UNE ENTREPRISE  /////////////////////////// 
	public function btn_addmodifyAction()
    {
		return $this->render('ZoomDoualaBundle:Show:btn_addmodify.html.twig');
	}
	
////////////////////////////////////// RENDU DU BOUTON DETAIL  /////////////////////////// 
	public function btn_detailsAction()
    {
		return $this->render('ZoomDoualaBundle:Show:btn_details.html.twig');
	}

////////////////////////////////////// RENDU DE SEARCH BY NAME DANS LE LAYOUT  /////////////////////////// 
	public function layout_search_by_nameAction()
    {
        $asset_path = $this->get('assets.packages')->getUrl('bundles/zoomdouala/ajax/');
        $http = $_SERVER['SERVER_NAME'] == 'localhost' ? 'http://' : 'https://';
        $server_address =  $http.$_SERVER['SERVER_NAME'].$asset_path.'activitesRead_json.php';
//var_dump( $server_address );
//die();
		return $this->render('ZoomDoualaBundle:Show:layout_search_by_name_form.html.twig', array(
            'server_address' => $server_address,
        ));
	}
///////////////////////////////////////// REDIRECT TO THE USER LANGUAGE ////////////////////////////
 	public function defaultredirectionAction(Request $request){
		$lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
		if($lang){
			$langtab = explode('-', $lang);
			$lang = $langtab[0];
			switch($lang) {
    			case "fr-FR":
       			$local = "fr";
        	break;
    		default:
        		$local = "en";
       	 	break;
			}
		}
		else{
			$local = "en";
		}
//
		$siteData = $this->getLocale();
		
		$currentRoute = $request->attributes->get('_route');
// echo $currentRoute;
		if( $currentRoute == "zoom_douala_default" ){
			$page = "zoom_douala_home";
		}
		else{
			$page = "zoom_douala_testhome";
		}

		return $this->redirect($this->generateUrl($page));			
	}
//////////////////////////////////////////// LIST DES RUES /////////////////////
	public function listRueAction(Request $request ) 
	{
		$em = $this->getDoctrine()->getManager();
		$indexZero = "Aucune";
		$indexAutre = "Autre";
		// Query de la liste des rues ( pour creer les lignes de rues avec leur textes + bouton))
		$rueObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Rue a 
	                           		WHERE a.rue != :indexZero ORDER BY a.rue ASC')
							   		->setParameters(array('indexZero'=>$indexZero))
									;
		$rues = $rueObj->getResult();
		$nombre_rues = count($rues );
		// nom de la ville à partir de villeId d'une rue
		$villeId = ( $rues[0]->getVilleId() ) ? $rues[0]->getVilleId() : 1;
// echo 'VilleId: ' . $villeId;
		$villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
		$ville = $villeObj->getVille();
		//////// creation des Array à afficher pour chaque ligne de rue. Ces array doivent partager le meme index
		// Nombres d'entreprises de chaque ligne rue
		$nombre_entreprises = "";
		// Messages de la ligne (exemple: 0 entreprise, 2entreprises)
		$nombre_entreprises_messages = "";
		// Bouton de detail de la ligne � afficher si la rue a aumoins une entreprise
		$afficher_btn_details = "";
		// Index alphab�tique de la rue
		$indexAlphaArray = "";
 		$indexAlphaArray[0] = "";
		// Array de toutes les lignes de rues � afficher
 		$lignesRues =  array();

		//////// totaux et compteurs
		// total rues
		$total = $nombre_rues; // nombres de rues
		$conteur = 0; // nombre d'entreprise dans cette rue
		$pagelimit = 100; // limit de la pagination knp et alphabetique
		
		// remplissage de l'array $ligneRue contenant toutes les lignes � afficher
		foreach($rues as $index=>$rue)
		{
			// nom de la rue
			$rueString = trim($rue->getRue());
// echo 'rueString: ' . $rueString;
            if( $rueString ){
                // description de la rue
                $rueDescription = $rue->getDescription();
                // l'index alphabetique de la rue
                $indexAlpha = '';
                
                $alpha = ucfirst($rueString[0]); 
                $indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
                if($index==0) // premiere insertion ou insetion diferente de la derni�re
                {
                    $indexAlpha = $alpha;
                    $indexAlphaArray[0] =  $alpha;
                }
                else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
                {
                    $indexAlpha = $alpha;
                }
                else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
                {
                    $indexAlpha = "";
                }
                $lastinsertedId = $index;
//echo $indexAlpha;
                // 
                // nombre d'entreprise de cette ligne (rue) + texte à afficher 
                $rueId = $rue->getId(); //recuperation de l'id de la rue
                $entreprises = $em->getRepository('ZoomDoualaBundle:Activite')->findByRueId($rueId, array('entreprise' => 'ASC'));
                // array d'affichage des rues
                $lignesRues[$index]["rue"] = $rueString;
                $lignesRues[$index]["alpha"] = $indexAlpha;
                $lignesRues[$index]["description"] = $rueDescription;
                if($entreprises)
                {
                    $conteur = count($entreprises); // decompte des entreprises de la rue
                    $nombre_entreprises = $conteur;
                // text du nombre d'entreprise dans la rue:(gestion du pluriel avec s)
                    if($conteur < 2)
                    {
                        $message = "entreprise";
                    }
                    else
                    {
                        $message = "entreprises";
                    }
                    $nombre_entreprises_messages = $message;
                    // Affichage du bouton "Details" de cette rue: est-ce qu'il ya des entreprises dans rue
                    $afficher_btn_details = 1;
                    // Fabrication de l'array des lignes � afficher
                    $lignesRues[$index]["nombre"] = $nombre_entreprises;
                    $lignesRues[$index]["text"] = $nombre_entreprises_messages;
                    $lignesRues[$index]["button"] = $afficher_btn_details;
                    $lignesRues[$index]["message"] = $message;
                }
                else{
                    $afficher_btn_details = "";
                    $lignesRues[$index]["button"] = $afficher_btn_details;		
                }
            }
        }
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    $pagination = $paginator->paginate($lignesRues, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
		//messages
		return $this->render('ZoomDoualaBundle:Show:rueList.html.twig', array(
							 'pagination' => $pagination, 
							 'nombre_entreprises' =>$nombre_entreprises, 
							 'indexAlphaArray' => $indexAlphaArray, 
							 'total' => $total,
							 'ville' => $ville,
							 ));
  	}

//////////////////////////////////////////// LISTE DES ACTIVITES DE LA RUE CHOISIE 

////////////////////////////////////////
    public function showRueAction(Request $request, $rueChoisie)
	{
		// echo "travaux en cours sur cette page, 95%";
		// rue choisie
		$rueChoisie = trim(ucfirst($rueChoisie));
		$em = $this->getDoctrine()->getManager();
		$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneByRue($rueChoisie, array('rue' => 'DESC'));
		if($rueObj){
			$rueId = $rueObj->getId();
		// si cette rue a des entreprise
			$activated = 'oui';
        	$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a 
	                           WHERE a.rueId =:rueChoisie AND a.activated =:activated')
								->setParameters(array('rueChoisie'=>$rueId, 'activated'=>$activated));
			$activites = $query->getResult();
			$conteur = count($activites);
			// changer le nom des rues en rempla�ant l'id par le nom de la rue et cr�ee le tableau des index alphabetique � afficher
			$indexAlphaArray = array();
			$indexAlphaArray[0] = "";
			$lastinsertedId = 0;
			$pagelimit = 25; // limit de la pagination knp et alphabetique/ var_dump($activites);
			// nombre d'entreprise à afficher / total paginé
			if($conteur < $pagelimit)
			{
				$toshow = $conteur;
			}
			else
			{
				$toshow = $pagelimit;
			}
		//
// echo $conteur;
// var_dump($activites);
// echo $indexPaginationRue;
			foreach($activites as $index=>$activite)
			{
				// on enleve les caracteres sp�ciaux dans le nom de l'activit�
				$entreprise = str_replace('/', '', $activite->getEntreprise());
				$activite->setEntreprise($entreprise);
				// $rue = ucfirst($rueObj->getRue());
				$activite->setRueId($rueChoisie);
				// changement de l'id de  la villeId en nom de ville
				$villeId = $activite->getVilleId();
		    	$villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
				$ville = $villeObj->getVille();
				$activite->setVilleId($ville);
				// changement de l'Id du quartier en nom du quartier
				$quartierId = $activite->getQuartierId();
		    	$quartierObj =  $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
				$quartier = ucfirst($quartierObj->getQuartier());
				$activite->setQuartierId($quartier);
				// logo par defaut
				$logo = $activite->getPath03();
				if(!isset($logo))
				{
					$activite->setPath03("default/logo".array_rand([1,2,3], 1).".gif");
				}
				else{
					$activite->setPath03("../../../uploads/documents/".$logo);
				}
				//
				// Affichage du bouton "Details" de cette rue: est-ce qu'il ya des entreprises dans rue
				if($conteur > 0)
				{
		    		$afficher_btn_details = 1;
				}
				else
				{
		    		$afficher_btn_details = "";
				}
				// tableau des index alphabetique des entrprises
				// l'index alphabetique de l'entreprise
				$alpha = ucfirst($entreprise[0]);
				$indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
				if($index==0) // premiere insertion ou insetion diferente de la derni�re
				{
					$indexAlpha = $alpha;
					$indexAlphaArray[$index] =  $alpha; 
				}
				else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
				{
					$indexAlpha = $alpha;
				}
				else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
				{
					$indexAlpha = "";
				}
				$lastinsertedId = $index;
				//
				// Fabrication de l'array des lignes � afficher
				$lignesEntreprise[$index]["alpha"] = $indexAlpha;
				$lignesEntreprise[$index]["entreprise"] = ucfirst(strtolower($activite->getEntreprise()));
				$lignesEntreprise[$index]["telephone01"] = $activite->getTelephone01();
				$lignesEntreprise[$index]["email"] = ucfirst(strtolower($activite->getEmail()));
				$lignesEntreprise[$index]["quartierId"] = ucfirst($activite->getQuartierId());
				$lignesEntreprise[$index]["rueId"] = $activite->getRueId();
				$lignesEntreprise[$index]["villeId"] = ucfirst($ville);
				$lignesEntreprise[$index]["description"] = $rueObj->getDescription();
				$lignesEntreprise[$index]["path03"] = $activite->getPath03(); // logo;
				$lignesEntreprise[$index]["button"] = $afficher_btn_details;
				$lignesEntreprise[$index]["nombre"] = $conteur;
				$lignesEntreprise[$index]["id"] = $activite->getId();
			}
//			var_dump($lignesEntreprise);
//	 		Pagination knp_paginator
			$paginator  = $this->get('knp_paginator');		   
	    	$pagination = $paginator->paginate($lignesEntreprise, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);

			// sitename, email, pays...
			$localData = $this->getLocale();
			return $this->render('ZoomDoualaBundle:Show:rueShow.html.twig', array
				(
					'pagination'		=> $pagination, 
					'type' 				=> 'Rue', 
					'rueChoisie' 		=> $rueChoisie, 
					'indexAlpha' 		=> $indexAlphaArray, 
					'totalEntreprise'	=> $conteur, 
					'toshow'			=> $toshow,
					'localData'			=> $localData
				)
			);
		}
		else{
			return $this->render('ZoomDoualaBundle:Show:rueNullShow.html.twig', array('rueChoisie'=>$rueChoisie));
		}
	}
 
////////////////////////////////////////////////////// LISTE DES QUARTIERS 

//////////////////////////////////////////////
	public function listQuartierAction(Request $request ) 
	{
		$em = $this->getDoctrine()->getManager();
		$indexZero = "Aucune";
		$indexAutre = "Autre";
		// Query de la liste des quartiers ( pour creer les lignes de quartiers avec leur textes + bouton))
		$quartierObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Quartier a 
	                           		WHERE a.quartier != :indexZero ORDER BY a.quartier ASC')
							   		->setParameters(array('indexZero'=>$indexZero))
									;
		$quartiers = $quartierObj->getResult();
		$nombre_quartiers = count($quartiers );
		// nom de la ville à partir de villeId d'une quartier
		$villeId = $quartiers[0]->getVilleId();
		$villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
		$ville = $villeObj->getVille();
		//////// creation des Array à afficher pour chaque ligne de quartier. Ces array doivent partager le meme index
		// Nombres d'entreprises de chaque ligne quartier
		$nombre_entreprises = "";
		// Messages de la ligne (exemple: 0 entreprise, 2entreprises)
		$nombre_entreprises_messages = "";
		// Bouton de detail de la ligne � afficher si la quartier a aumoins une entreprise
		$afficher_btn_details = "";
		// Index alphab�tique de la quartier
		$indexAlphaArray = "";
 		$indexAlphaArray[0] = "";
		// Array de toutes les lignes de quartiers � afficher
 		$lignesQuartiers =  array();

		//////// totaux et compteurs
		// total quartiers
		$total = $nombre_quartiers; // nombres de quartiers
		$conteur = 0; // nombre d'entreprise dans cette quartier
		$pagelimit = 100; // limit de la pagination knp et alphabetique
		
		// remplissage de l'array $ligneQuartier contenant toutes les lignes � afficher
		foreach($quartiers as $index=>$quartier)
		{
			// nom de la quartier
			$quartierString = trim($quartier->getQuartier());
			// description de la quartier
			$quartierDescription = $quartier->getDescription();
			// l'index alphabetique de la quartier
			$alpha = ucfirst($quartierString[0]);
			$indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
			if($index==0) // premiere insertion ou insetion diferente de la derni�re
			{
				$indexAlpha = $alpha;
				$indexAlphaArray[0] =  $alpha;
			}
			else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
			{
				$indexAlpha = $alpha;
			}
			else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
			{
				$indexAlpha = "";
			}
			$lastinsertedId = $index;
//echo $indexAlpha;
			// 
			// nombre d'entreprise de cette ligne (quartier) + texte à afficher 
			$quartierId = $quartier->getId(); //recuperation de l'id de la quartier
			$entreprises = $em->getRepository('ZoomDoualaBundle:Activite')->findByQuartierId($quartierId, array('entreprise' => 'ASC'));
			// array d'affichage des quartiers
			$lignesQuartiers[$index]["quartier"] = $quartierString;
			$lignesQuartiers[$index]["alpha"] = $indexAlpha;
			$lignesQuartiers[$index]["description"] = $quartierDescription;
			if($entreprises)
			{
				$conteur = count($entreprises); // decompte des entreprises de la quartier
				$nombre_entreprises = $conteur;
			// text du nombre d'entreprise dans la quartier:(gestion du pluriel avec s)
				if($conteur < 2)
		    	{
		    		$message = "entreprise";
 	        	}
		   	 	else
		    	{
		    		$message = "entreprises";
		    	}
				$nombre_entreprises_messages = $message;
				// Affichage du bouton "Details" de cette quartier: est-ce qu'il ya des entreprises dans quartier
	    		$afficher_btn_details = 1;
				// Fabrication de l'array des lignes � afficher
				$lignesQuartiers[$index]["nombre"] = $nombre_entreprises;
				$lignesQuartiers[$index]["text"] = $nombre_entreprises_messages;
				$lignesQuartiers[$index]["button"] = $afficher_btn_details;
				$lignesQuartiers[$index]["message"] = $message;
			}
			else{
				$afficher_btn_details = "";
				$lignesQuartiers[$index]["button"] = $afficher_btn_details;		
			}
		}
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    $pagination = $paginator->paginate($lignesQuartiers, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
		//messages
		return $this->render('ZoomDoualaBundle:Show:quartierList.html.twig', array(
							 'pagination' => $pagination, 
							 'nombre_entreprises' =>$nombre_entreprises, 
							 'indexAlphaArray' => $indexAlphaArray, 
							 'total' => $total,
							 'ville' => $ville,
							 ));
  	}

///////////////////////////////////////////////// LISTE DES ACTIVITES DANS QUARTIER ////////////////////////////////////////
    public function showQuartierAction(Request $request, $quartierChoisie)
	{
		$indexZero = "Aucun";
		$indexAutre = "Aucune";
		// Quartier choisie
		$quartierChoisie = ucfirst($quartierChoisie);
		$em = $this->getDoctrine()->getManager();
		$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartierChoisie, array('quartier' => 'DESC'));
		$quartierId = $quartierObj->getId();
		$activated = 'oui';
        $query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a 
	                        WHERE a.quartierId =:quartierChoisie AND a.activated =:activated ORDER BY a.entreprise ASC')
							->setParameters(array('quartierChoisie'=>$quartierId, 'activated'=>$activated));
    	$activites = $query->getResult();
		// si il ya 
		if($activites){
			$conteur = count($activites);
// var_dump($quartierChoisie);
		// changer le nom des quartiers en rempla?ant l'id par le nom de la quartier et cr?ee le tableau des index alphabetique ? afficher
			$indexAlphaArray = array();
			$indexAlphaArray[0] = "";
			$lastinsertedId = 0;
			$pagelimit = 25; // limit de la pagination knp et alphabetique
			// nombre d'entreprise à afficher / total paginé
			if($conteur < $pagelimit)
			{
				$toshow = $conteur;
			}
			else
			{
				$toshow = $pagelimit;
			}

			foreach($activites as $index=>$activite)
			{
				// on enleve les caracteres sp?ciaux dans le nom de l'activit?
				$entreprise = str_replace('/', '', $activite->getEntreprise());
				$activite->setEntreprise($entreprise);
				// $quartier = ucfirst($quartierObj->getQuartier());
				$activite->setQuartierId($quartierChoisie);
				// changement de l'id de  la villeId en nom de ville
				$villeId = $activite->getVilleId();
		    	$villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
				$ville = $villeObj->getVille();
				$activite->setVilleId($ville);
				// changement de l'id de  la rueId en nom de la rue
				$rueId = $activite->getRueId();
				// patch pour Gandi qui ne voit pas l'index Id = 0 
				if($rueId != 0)
				{
					$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
					$rue = ucfirst(strtolower($rueObj->getRue()));
					//echo $rue;
				}
				else
				{
					$rue = "";
				}
				// fin patch pour Gandi qui ne voit pas l'index Id = 0 
				$activite->setRueId($rue);
				// changement de l'Id du quartier en ucfirst
				$quartier = ucfirst(strtolower($quartierChoisie));
				$activite->setQuartierId($quartier);
				// logo par defaut
				$logo = $activite->getPath03();
				if(!isset($logo))
				{
					$activite->setPath03("default/logo".array_rand([1,2,3], 1).".gif");
				}
				else{
					$activite->setPath03("../../../uploads/documents/".$logo);
				}
				// Affichage du bouton "Details" de cette quartier: est-ce qu'il ya des entreprises dans quartier
				if($conteur > 0)
				{
		    		$afficher_btn_details = 1;
				}
				else
				{
		    		$afficher_btn_details = "";
				}
				// tableau des index alphabetique des entrprises
				// l'index alphabetique de l'entreprise
				$alpha = ucfirst($entreprise[0]);
				$indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
				if($index==0) // premiere insertion ou insetion diferente de la derni?re
				{
					$indexAlpha = $alpha;
					$indexAlphaArray[$index] =  $alpha; 
				}
				else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
				{
					$indexAlpha = $alpha;
				}
				else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
				{
					$indexAlpha = "";
				}
				$lastinsertedId = $index;
				//
				// Fabrication de l'array des lignes ? afficher
				$lignesEntreprise[$index]["alpha"] = $indexAlpha;
				$lignesEntreprise[$index]["entreprise"] = $activite->getEntreprise();
				$lignesEntreprise[$index]["telephone01"] = $activite->getTelephone01();
				$lignesEntreprise[$index]["email"] = strtolower ($activite->getEmail());
				$lignesEntreprise[$index]["quartierId"] = $activite->getQuartierId();
				$lignesEntreprise[$index]["villeId"] = $ville;
				$lignesEntreprise[$index]["description"] = $quartierObj->getDescription();
				$lignesEntreprise[$index]["path03"] = $activite->getPath03(); // logo;
				$lignesEntreprise[$index]["button"] = $afficher_btn_details;
				$lignesEntreprise[$index]["nombre"] = $conteur;
				$lignesEntreprise[$index]["rueId"] = $activite->getRueId();
				$lignesEntreprise[$index]["logo"] = $activite->getPath03();
				$lignesEntreprise[$index]["id"] = $activite->getId();
			}
/////// 	Pagination knp_paginator
			$paginator  = $this->get('knp_paginator');
	    	if($conteur)
			{
				$pagination = $paginator->paginate($lignesEntreprise, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
			}
			// sitename, email, pays...
			$localData = $this->getLocale();
			
			return $this->render('ZoomDoualaBundle:Show:quartierShow.html.twig', 
				array(
					'pagination' 		=> $pagination, 
					'type' 				=> 'Quartier', 
					'quartierChoisie'   => $quartierChoisie, 
					'indexAlpha'        => $indexAlphaArray, 
					'totalEntreprise'   => $conteur, 
					'toshow'            => $toshow,
					'localData'         => $localData,
					)
				);
		}
 		else{
			return $this->render('ZoomDoualaBundle:Show:quartierNullShow.html.twig', array
				(	
					'quartierChoisie'=>$quartierChoisie,
				)
			);
		}
	}
  
//////////////////////////////////////////// LISTE DES RUBRIQUES 

//////////////////////////////////////////
	public function listRubriqueAction(Request $request ) 
	{
		mb_internal_encoding('UTF-8');
		$em = $this->getDoctrine()->getManager();
		$indexZero = "Aucune";
		$indexAutre = "Autre";
		// Query de la liste des rubriques ( pour creer les lignes de rubriques avec leur textes + bouton))
		$rubriqueObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Rubrique a 
										 WHERE a.rubrique != :indexZero 
										 ORDER BY a.rubrique ASC')
											->setParameters(array('indexZero'=>$indexZero))
									;
		$rubriques = $rubriqueObj->getResult();
		$nombre_rubriques = count($rubriques );
		// nom de la ville à partir de villeId d'une rubrique
		$villeId = 1; // douala
		$villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
		$ville = $villeObj->getVille();
		//////// creation des Array à afficher pour chaque ligne de rubrique. Ces array doivent partager le meme index
		// Nombres d'entreprises de chaque ligne rubrique
		$nombre_entreprises = "";
		// Messages de la ligne (exemple: 0 entreprise, 2entreprises)
		$nombre_entreprises_messages = "";
		// Bouton de detail de la ligne à afficher si la rubrique a aumoins une entreprise
		$afficher_btn_details = "";
		// Array de toutes les lignes de rubriques à afficher
 		$lignesRubriques =  array();

		//////// totaux et compteurs
		// total rubriques
		$total   = $nombre_rubriques; // nombres de rubriques
		$conteur = 0; // nombre d'entreprise dans cette rubrique
		$pagelimit = 100; // limit de la pagination knp et alphabetique
		
		// remplissage de l'array $ligneRubrique contenant toutes les lignes � afficher
		foreach($rubriques as $index => $rubrique)
		{
			// nom de la rubrique
			$rubriqueString = trim($rubrique->getRubrique());
			// translate rubrique
			$language  = new Languagefromurl;
			$langueId  = $language->getLanguage();
			$tableId   = 1;
			$termid    = $rubrique->getId();
			$translate = new Translate;
			$trans     = $translate->getOneTranslation( $tableId, $termid, $langueId );
			if( $trans ){
				$rubriqueString = $trans;
			}
			
			// description de la rubrique
			$rubriqueDescription = $rubrique->getDescription();
			

			// 
			// nombre d'entreprise de cette ligne (rubrique) + texte à afficher 
			$rubriqueId = $rubrique->getId(); //recuperation de l'id de la rubrique
			$entreprises = $em->getRepository('ZoomDoualaBundle:Activite')->findByRubriqueId($rubriqueId, array('entreprise' => 'ASC'));
			// array d'affichage des rubriques
			$lignesRubriques[$index]["rubrique"] = $rubriqueString;
			$lignesRubriques[$index]["alpha"] = ""; // sera definit apres reordonation alphabetique ci dessous
			$lignesRubriques[$index]["description"] = $rubriqueDescription;
			if($entreprises){
				$conteur = count($entreprises); // decompte des entreprises de la rubrique
				$nombre_entreprises = $conteur;
			// text du nombre d'entreprise dans la rubrique:(gestion du pluriel avec s)
				if($conteur < 2)
		    	{
		    		$message = "entreprise";
 	        	}
		   	 	else
		    	{
		    		$message = "entreprises";
		    	}
				$nombre_entreprises_messages = $message;
				// Affichage du bouton "Details" de cette rubrique: est-ce qu'il ya des entreprises dans rubrique
	    		$afficher_btn_details = 1;
				// Fabrication de l'array des lignes à afficher
				$lignesRubriques[$index]["id"]      = $rubrique->getId();
				$lignesRubriques[$index]["nombre"]  = $nombre_entreprises;
				$lignesRubriques[$index]["text"]    = $nombre_entreprises_messages;
				$lignesRubriques[$index]["button"]  = $afficher_btn_details;
				$lignesRubriques[$index]["message"] = $message;
			}
			else{
				$lignesRubriques[$index]["id"]      = $rubrique->getId();
				$afficher_btn_details = "";
				$lignesRubriques[$index]["button"]  = $afficher_btn_details;		
			}
		}
		// reorder alpha position because of translation
		$order = array();
		foreach( $lignesRubriques as $key => $value ){ // create an array with all alpha and id
			$rubrique = $value['rubrique'];
			$index =  mb_substr($rubrique, 0, count($rubrique));
			$data  = $index."_".$key;
			array_push( $order, $data );
		}
		sort( $order ); // ordering array
		$orderedindex = array();
		foreach( $order as $value ){
			$str_tab = explode( "_", $value );
			$key = $str_tab[1];
			array_push( $orderedindex, $key);
		}
		$lignesRubriquesOrdered = array();
		// recreate $lignesRubriques array with good index order
		foreach( $orderedindex as $value ){
			$data = $lignesRubriques[$value];
			array_push( $lignesRubriquesOrdered, $data );
		}
		// set [alpha]
		$index = "";
 		$deja  = false;
		$representant  = array();
		foreach( $lignesRubriquesOrdered as &$value ){ // mettre [alpha]
			$rubrique  = $value['rubrique'];
			$index =  mb_substr($rubrique, 0, count($rubrique));// string, int start, int lenght
            
            // $alpha = ucfirst($rubrique[0]);
            $indexAlphaArray[$index] =  $index; 
            
			if( in_array( $index, $representant ) ){
				$deja = true;
			}
			else{
				$deja = false;
				array_push( $representant, $index );
			}
			if( $deja ){
				$value['alpha'] = "";
			}
			else{
				$value['alpha'] = $index;
			}
		}
// echo "<pre>";
// var_dump($lignesRubriquesOrdered);
// echo "</pre>";
		//
		$paginator  = $this->get('knp_paginator');	////// Pagination	   
	    $pagination = $paginator->paginate($lignesRubriquesOrdered, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
		//messages
		return $this->render('ZoomDoualaBundle:Show:rubriqueList.html.twig', array
								(
									'pagination'         => $pagination, 
									'nombre_entreprises' => $nombre_entreprises, 
									'indexAlphaArray'    => $indexAlphaArray, 
									'total'				 => $total,
									'ville' 			 => $ville,
								)
							);
  	}

//////////////////////////////////////// LISTE DES ACTIVITES DE LA RUBRIQUE CHOISIE 

////////////////////////////////////////
    public function showRubriqueAction(Request $request, $rubrique, $rubriqueId)
	{
 // echo "travaux en cours sur cette page.. 99% <br>";
		$indexZero = "Aucun";
		$indexAutre = "Aucune";
		// Rubrique choisie obj
		$em = $this->getDoctrine()->getManager();
		$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId, array('rubrique' => 'DESC'));

//		if(!$rubriqueObj){ // si le nom de rubrique fournit n'est pas trouvé dans la table rubrique, on la cherche dans la table des traductions
//			$reversetranslate = new Reversetranslate;
//			$rubriqueId = $reversetranslate->getReverseTranslation(trim($rubriqueChoisie), 1);// 1 is the id of table Rubrique in the table of tables
//			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId, array('rubrique' => 'DESC'));
//		}
//		else{ // le nom de rubrique est trouvé
//			$rubriqueId = $rubriqueObj->getId();
//		}
//		if(!$rubriqueId){
//		  	return $this->render('ZoomDoualaBundle:Show:rubriqueNullShow.html.twig', array('rubriqueChoisie'=>$rubriqueChoisie));
//		}
		
		// Companies of the choosen activity sector
//		$rubriqueChoisie = $rubriqueObj->getRubrique();//The entity Rubrique returns the rubrique name that fit the current local
		$activated = 'oui';
        $query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a 
	                        WHERE a.rubriqueId =:rubriqueId AND a.activated =:activated ORDER BY a.entreprise ASC')
							->setParameters(array('rubriqueId'=>$rubriqueId, 'activated'=>$activated));
    	$activites = $query->getResult();
		// si il ya 
		if($activites){
			// get the model company of this rubrique
			$rubriqueModelObj = $em->getRepository('ZoomDoualaBundle:Companyrep')->findOneBy(array(
																							   "active"=>1,
																							   "rubriqueId"=>$rubriqueId));
//			var_dump($indexOfModelCompany);
			$conteur = count($activites);
		// changer le nom des rubriques en rempla?ant l'id par le nom de la rubrique et cr?ee le tableau des index alphabetique ? afficher
			$indexAlphaArray = array();
			$indexAlphaArray[0] = "";
			$lastinsertedId = 0;
			$pagelimit = 25; // limit de la pagination knp et alphabetique
			// nombre d'entreprise à afficher / total paginé
			if($conteur < $pagelimit)
			{
				$toshow = $conteur;
			}
			else
			{
				$toshow = $pagelimit;
			}
			foreach($activites as $index=>$activite){
				// on enleve les caracteres sp?ciaux dans le nom de l'activit?
				$entreprise = str_replace('/', '', $activite->getEntreprise());
				$activite->setEntreprise($entreprise);
				// $rubrique = ucfirst($rubriqueObj->getRubrique());

				$activite->setRubriqueId($rubriqueId);
				// changement de l'id de  la villeId en nom de ville
				$villeId = $activite->getVilleId();
		    	$villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
				$ville = $villeObj->getVille();
				$activite->setVilleId($ville);
				// changement de l'id du quartier en nom du quartier
				$quartierId = $activite->getQuartierId();
				// quartier
				if($quartierId != 0)
				{
					$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
					$quartier = ucfirst(strtolower($quartierObj->getQuartier()));
					//echo $rue;
				}
				// changement de l'id de  la rueId en nom de la rue
				$rueId = $activite->getRueId();
				// rue
				if($rueId != 0)
				{
					$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
					$rue = ucfirst(strtolower($rueObj->getRue()));
					//echo $rue;
				}
				else
				{
					$rue = "";
				}
				// fin patch pour Gandi qui ne voit pas l'index Id = 0 
				$activite->setRueId($rue);
				
				// changement de l'Id du rubrique en ucfirst
				//$rubriqueChoisie = ucfirst(strtolower($rubriqueChoisie));
				//$activite->setRubriqueId($rubriqueChoisie);
				
				// logo par defaut
				$logo = $activite->getPath03();
				if(!$logo)
				{
					$activite->setPath03("default/logo".array_rand([1,2,3], 1).".gif");
				}
				else{
					$activite->setPath03("../../../uploads/documents/".$logo);
				}
				// Affichage du bouton "Details" de cette rubrique: est-ce qu'il ya des entreprises dans rubrique
				if($conteur > 0)
				{
		    		$afficher_btn_details = 1;
				}
				else
				{
		    		$afficher_btn_details = "";
				}
				// tableau des index alphabetique des entrprises
				// l'index alphabetique de l'entreprise
				$alpha = ucfirst($entreprise[0]);
				$indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
				if($index==0) // premiere insertion ou insetion diferente de la derni?re
				{
					$indexAlpha = $alpha;
					$indexAlphaArray[$index] =  $alpha; 
				}
				else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
				{
					$indexAlpha = $alpha;
				}
				else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
				{
					$indexAlpha = "";
				}
				$lastinsertedId = $index;
				//
				// Fabrication de l'array des lignes ? afficher
				$lignesEntreprise[$index]["alpha"]       = $indexAlpha;
				$lignesEntreprise[$index]["entreprise"]  = $activite->getEntreprise();
				$lignesEntreprise[$index]["telephone01"] = $activite->getTelephone01();
				$lignesEntreprise[$index]["email"]       = strtolower ($activite->getEmail());
				$lignesEntreprise[$index]["rubriqueId"]  = $rubrique;
				$lignesEntreprise[$index]["villeId"]     = $ville;
				$lignesEntreprise[$index]["quartierId"]  = $quartier;
				$lignesEntreprise[$index]["path03"]      = $activite->getPath03(); // logo;
				$lignesEntreprise[$index]["button"]      = $afficher_btn_details;
				$lignesEntreprise[$index]["nombre"]      = $conteur;
				$lignesEntreprise[$index]["rueId"]       = $rue;
				$lignesEntreprise[$index]["logo"]        = $activite->getPath03();
				$lignesEntreprise[$index]["id"]          = $activite->getId();
			}
			// Pagination knp_paginator
			$paginator  = $this->get('knp_paginator');
	    	if($conteur){
				$pagination = $paginator->paginate($lignesEntreprise, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
			}
			// Array des entreprises modeles pour affichage
				// Liste des id des entreprises modeles de cette rubrique
			$entrepriseModelObj = $em->getRepository('ZoomDoualaBundle:CompanyRep')->findBy(array("active" => 1), array());
			$i = 0;
			$entrepriseModelIds = array();
			$entrepriseObj      = array();
			foreach( $entrepriseModelObj as $key => $value ){
				$entrepriseModelRubriqueObj = $value->getRubriqueId(); // rubrique object
				$entrepriseModelRubriqueId  = $entrepriseModelRubriqueObj->getId();
				$logo = "";
				if( $entrepriseModelRubriqueId     == $rubriqueObj->getId() ){
					$entrepriseObj                 =  $value->getEntrepriseId(); // company repository
					$entrepriseModelIds[$i]["id"]  =  $entrepriseObj->getId();
					$i++;
				}
			}
				// Array des entreprises modele
			$entrepriseModelArray = array();
			$i = 0;
			foreach( $lignesEntreprise as $key => $value ){
				$lignesEntrepriseId = $value['id'];
				foreach( $entrepriseModelIds as $k => $v ){
					if( $v['id'] == $value['id'] ){
						$entrepriseModelArray[$i] = $lignesEntreprise[$key];
						$i++;
					}
				}
			}
			//
			if(!$i){
				$countModels = NULL;
			}else{
				$countModels = count($entrepriseModelArray);
			}
			// traduction de la rubrique choisie
			$toTranslate = array();
			array_push( $toTranslate, ['name' => $rubrique, 'id' => $rubriqueId] );
			$tableId     = 1; // rubrique
			$translated  = $this->getArrayTrans( $toTranslate, $tableId );
			$rubrique    = $translated[0]['name'];
			// sitename, email, pays...
			$localData = $this->getLocale();
//			$rubriqueChoisie = $translated[0]['name'];
			return $this->render('ZoomDoualaBundle:Show:rubriqueShow.html.twig', array(
				'pagination'      => $pagination, 
				'type' 			  => 'rubrique', 
				'rubriqueChoisie' => $rubrique, 
				'indexAlpha' 	  => $indexAlphaArray, 
				'totalEntreprise' => $conteur, 
				'toshow'		  => $toshow,
				'entrepriseModel' => $entrepriseModelArray,
				'countModels'     => $countModels,
				'localData'       => $localData
			));
		}
 		else{
			return $this->render('ZoomDoualaBundle:Show:rubriqueNullShow.html.twig', array(
				'rubriqueChoisie'=>$rubrique));
		}
	}

//////////////////////////// LISTES ACTIVITES DE L'INDEX ALPHABETIQUES CHOISIE
/////////////
    public function showAlphaAction(Request $request, $alphaChoisie)
	{
	    $indexZero = "Aucun";
		$indexAutre = "Aucune";
		$pagelimit = 25;
		$alphaChoisie = ucfirst($alphaChoisie);
		$em = $this->getDoctrine()->getManager();
		$activated = "oui";
		$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a 
	                           WHERE a.entreprise LIKE :alphaChoisie AND a.activated =:activated ORDER BY a.entreprise ASC')->setParameters(array('alphaChoisie'=>$alphaChoisie.'%', 'activated'=>$activated));
    	$activites = $query->getResult();
		$conteur = count($activites);
		// nombre d'entreprise à afficher / total paginé
		if($conteur < $pagelimit)
		{
			$toshow = $conteur;
		}
		else
		{
			$toshow = $pagelimit;
		}
		//
		// changer le nom des rubriques en rempla?ant l'id par le nom de la rubrique et cr?ee le tableau des index alphabetique ? afficher
		$k = 0;
		$indexAlphaArray = array();
		$indexAlphaArray[0] = "";
		$lastinsertedId = 0;
		//
		foreach($activites as $index=>$activite)
		{
			// on enleve les caracteres sp?ciaux dans le nom de l'activit?
			$entreprise = str_replace('/', '', $activite->getEntreprise());
// echo $entreprise;
			$activite->setEntreprise($entreprise);
			// changement de l'id du quartier  en nom du quartier
			$quartierId = $activite->getQuartierId();
		    $quartierObj =  $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
			$quartier = ucfirst(strtolower($quartierObj->getQuartier()));
			$activite->setQuartierId($quartier);
			// changement de l'id de  la villeId en nom de ville
			$villeId = $activite->getVilleId();
// echo $villeId;
		    $villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
			$ville = $villeObj->getVille();
			$activite->setVilleId($ville);
			// changement de l'id de  la rueId en nom de la rue
			// patch pour Gandi qui ne voit pas l'index Id = 0 
			$rueId = $activite->getRueId();
//var_dump($rueId);
			if($rueId != 0)
			{
				$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
//echo "<pre>";
//				var_dump($rueObj);
//echo "</pre>";
				$rue = ucfirst(strtolower($rueObj->getRue()));
				//echo $rue;
			}
				else
			{
				$rue = "";
			}
		// fin patch pour Gandi qui ne voit pas l'index Id = 0 
			$activite->setRueId($rue);
			// logo par defaut
			$logo = $activite->getPath03();
			if(!isset($logo))
			{
				$activite->setPath03("default/logo".array_rand([1,2,3], 1).".gif");
			}
			else{
				$activite->setPath03("../../../uploads/documents/".$logo);
			}
			// Affichage du bouton "Details" de cette quartier: est-ce qu'il ya des entreprises dans quartier
			if($conteur > 0)
			{
		    	$afficher_btn_details = 1;
			}
			else
			{
		    	$afficher_btn_details = "";
			}
			// tableau des index alphabetique des entrprises	// l'index alphabetique de l'entreprise
			$alpha = ucfirst($entreprise[0]);
			$indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
			if($index==0) // premiere insertion ou insetion diferente de la derni?re
			{
				$indexAlpha = $alpha;
				$indexAlphaArray[$index] =  $alpha; 
			}
			else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
			{
				$indexAlpha = $alpha;
			}
			else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
			{
				$indexAlpha = "";
			}
			$lastinsertedId = $index;
			//
			// Fabrication de l'array des lignes ? afficher
			$lignesEntreprise[$index]["alpha"] = $indexAlpha;
			$lignesEntreprise[$index]["entreprise"] = $activite->getEntreprise();
			$lignesEntreprise[$index]["telephone01"] = $activite->getTelephone01();
			$lignesEntreprise[$index]["email"] = strtolower ($activite->getEmail());
			$lignesEntreprise[$index]["quartierId"] = $activite->getQuartierId();
			$lignesEntreprise[$index]["villeId"] = $ville;
			$lignesEntreprise[$index]["description"] = $quartierObj->getDescription();
			$lignesEntreprise[$index]["path03"] = $activite->getPath03(); // logo;
			$lignesEntreprise[$index]["button"] = $afficher_btn_details;
			$lignesEntreprise[$index]["nombre"] = $conteur;
			$lignesEntreprise[$index]["rueId"] = $activite->getRueId();
			$lignesEntreprise[$index]["logo"] = $activite->getPath03();
			$lignesEntreprise[$index]["id"] = $activite->getId();			
		}
		// Pagination knp_paginator
		$paginator  = $this->get('knp_paginator');		   
	    $pagination = $paginator->paginate($lignesEntreprise, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
		
		// site datas (email, sitename, ...)
		$siteData = $this->getLocale();

		return $this->render('ZoomDoualaBundle:Show:alphaShow.html.twig', array
			(
				'pagination'	  => $pagination, 
				'type' 			  => 'Index', 
				'alphaChoisie'    => $alphaChoisie, 
				'totalEntreprise' => $conteur, 
				'toshow'          => $toshow,
				'siteData'        => $siteData,
			)
		);
  }
// FIN AFFICHAGE DES ACTIVITES DE LA LETTRE CHOISIE 

/////////////////////////////////////////////


///////////////////////////// FORMULAIRE RECHERCHE PAR rubrique, RENDU SUR LAYOUT_PAGE 

///////////////////////////////////////////
	public function layout_search_by_rubriqueAction() 
    {
		// total number of rubrique in rubrique list form
		$resultResult  = $em->createQuery( "SELECT COUNT(a.id) FROM ZoomDoualaBundle:Rubrique a" );
		$resultObj     = $resultResult->getResult();
		$countrubrique = 470; // number of rows
		//
		$layout_search_by_rubrique_Obj = new layoutSearchByRubriqueForm(); // 
		$layout_search_by_rubrique_Form = $this->createForm($layout_search_by_rubrique_Obj);
		return $this->render('ZoomDoualaBundle:Show:layout_search_by_rubrique_form.html.twig', array
			(
				'layout_search_by_rubrique_Form' => $layout_search_by_rubrique_Form->createView(),
				'countrubrique'                  => $countrubrique,
			));
	}
//// FIN FORMULAIRE RECHERCHE PAR RUBRIQUES DU LAYOUT_PAGE 

//////////////////////////////////////////////////////////////////


/////////////////////////////////////// FORMULAIRE RECHERCHE PAR QUARTIER LAYOUT_PAGE 

///////////////////////////////////////////////////////////////
	public function layout_search_by_quartierAction() 
    {
		// total number of rubrique in rubrique list form
		$resultResult  = $em->createQuery( "SELECT COUNT(a.id) AS 'total' FROM ZoomDoualaBundle:Quartier a" );
		$resultObj     = $resultResult->getResult();
		$countquartier = $resultObj['total']; // number of rows
		//
	    $layout_search_by_quartier_Obj = new layoutSearchByQuartierForm(); // pour le formulaire de contact de recherche de layout_page
		$layout_search_by_quartier_Form = $this->createForm($layout_search_by_quartier_Obj);
		return $this->render('ZoomDoualaBundle:Show:layout_search_by_quartier_form.html.twig', array
			(
				'layout_search_by_quartier_Form' => $layout_search_by_quartier_Form->createView(),
				'countquartier'                  => $countquartier,
			));
	}
//// FIN FORMULAIRE RECHERCHE PAR NOM DU LAYOUT_PAGE 

//////////////////////////////////////////////////////////////////


//// FIN FORMULAIRE RECHERCHE PAR QUARTIER DU LAYOUT_PAGE 
 
//////////////////////////////////////////////////////////////////

////////////////////////// formulaire de contact ? rendre sur la page d'accueil 
///////////////////////////////////////////////////////////////////////////////
	public function layout_contact_formAction() 
    {		
	    // pour le formulaire de contact de la page d'accueil
	    // $layout_contact_FormObj = new layoutContactForm(); 
		$layout_contact_form = $this->createForm(layoutContactForm::class);
		return $this->render('ZoomDoualaBundle:Show:layout_contact_form.html.twig', array('layout_contact_form' => $layout_contact_form->createView()));
	}
// fin formulaire de contact ? rendre sur la page d'accueil

////////////////////////// formulaire de report d'erreur ? rendre sur la page d'accueil 
///////////////////////////////////////////////////////////////////////////////
	public function layout_error_formAction() 
    {		
	    // pour le formulaire de contact de la page d'accueil
	    // $layout_contact_FormObj = new layoutContactForm(); 
		$layout_error_form = $this->createForm(layoutErrorForm::class);
		$localData         = $this->getLocale();
		return $this->render('ZoomDoualaBundle:Show:layout_error_form.html.twig', array
								(
									'layout_error_form' => $layout_error_form->createView(),
									'siteData'          => $localData,
								)
							); 
	}
// fin formulaire de contact ? rendre sur la page d'accueil

////////////////  Page d'accueil (Default) ///////
    public function defaultAction(Request $request)
    {
// echo "we are working on this page...98%";
		$motcle = "";
		$rubrique = "";
		$quartier = "";
		$id = "";
	    // $formRechercheActiviteObj = new rechercheActiviteShowForm();
	    // $formRechercheRubriqueObj = new rechercheRubriqueShowForm();
	    // $formRechercheQuartierObj = new rechercheQuartierShowForm();
        $formActivite = $this->createForm(rechercheActiviteShowForm::class);
        $formRubrique = $this->createForm(rechercheRubriqueShowForm::class);
        $formQuartier = $this->createForm(rechercheQuartierShowForm::class);
	    $em = $this->getDoctrine()->getManager();
		if ($request) 
		{   
			// recuperation des données sélectionnées sur les formulaire de recherche de la page d'accueil
			$formActivite->handleRequest($request); // recherche par nom
		    $motcle = $request->get('motcle');
			$formRubrique->handleRequest($request);  // recherche par rubrique
		    $rubrique = $request->get('rubrique');
	        $formQuartier->handleRequest($request);  // recherche par quartier
		    $quartier = $request->get('quartier');
			// recherche par mot cle
        	if ($motcle)
        	{
				$motcleTab = explode(",",$motcle);
 				$motcle = trim($motcleTab[0]);
				$activiteChoisie = ucfirst(strtolower($motcle));
				// eviter d'avoir une chaine de points dans l'url [...]
				if(! preg_match('/[^\.]/', $activiteChoisie)) {
					$activiteChoisie = $activiteChoisie.'_';
				}

				if(array_key_exists(1, $motcleTab)) // entreprise choisie dans la list box l'autocompletion
				{
					$qartierTab = explode(' - ', $motcleTab[1]);  // quartier
					if($qartierTab)
					{
						if($qartierTab[0] && $qartierTab[1])
						{
							$quartier = trim($qartierTab[0]);		
							$activiteId = trim($qartierTab[1]);			  // id
							$from01 = "motcle";
							$from02 = $motcle;
							return $this->redirect($this->generateUrl('zoom_douala_show_activite', array(
						'from01'=>$from01,'from02'=>$from02, 'activiteChoisie'=>$activiteChoisie, 'activiteId'=>$activiteId)));
						}
						else  // entreprise saisie et non selectionée dans la list autocompletée, on compare et list les entreprises ressemblant 
						{
							$from01 = "saisie";
							$activiteSaisie = $activiteChoisie;
							return $this->redirect($this->generateUrl('zoom_douala_list_activite', array(
						'from01'=>$from01,'activiteSaisie'=>$activiteSaisie,))); 
						}
					}
					else  // entreprise saisie et non selectionée dans la list autocompletée, on compare et list les entreprises ressemblant 
					{
						$from01 = "saisie";
						$activiteSaisie = $activiteChoisie;
						return $this->redirect($this->generateUrl('zoom_douala_list_activite', array(
						'from01'=>$from01,'activiteSaisie'=>$activiteSaisie,))); 
					}
				}
				else if (!array_key_exists(1, $motcleTab)) // entreprise saisie et non selectionée: on compare et liste les entreprises ressemblant 
				{
					$from01 = "saisie";
					$activiteSaisie = $activiteChoisie;
					return $this->redirect($this->generateUrl('zoom_douala_list_activite', array(
					'from01'=>$from01,'activiteSaisie'=>$activiteSaisie,))); 
				}
				else if ($activiteChoisie != "Saisissez une entreprise")// rien n'a été saisie, retour à la page d'accueil
				{
					return $this->render('ZoomDoualaBundle:Show:default.html.twig', array(
					'formActivite'       => $formActivite->createView(), 
					'formRubrique'       => $formRubrique->createView(), 
					'formQuartier'       => $formQuartier->createView(), 
					'representantsArray' => $representantsArray, 
					'rubriquesWindow'    => $rubriquesWindow, 
					'quartiers'          => $quartiers));
				}
			}
			else if($rubrique != '' AND $rubrique != 0)
        	{	// echo $rubrique;
				$from01 = "rubrique";
				$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubrique);
				$rubriqueChoisie = $rubriqueObj->getRubrique();
				// redirection vers la page de la rubrique choisie
				return $this->redirect($this->generateUrl('zoom_douala_show_rubrique', array(
					'from01'		  => $from01, 
					'rubriqueChoisie' => $rubriqueChoisie
				)));
				 
	    	}
			else if($quartier != '' AND $quartier != 0)
        	{	//echo $quartier;
				$quartieObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartier);
				$quartierChoisie = $quartieObj->getQuartier();
				// redirection vers la page du quartier choisie
				return $this->redirect($this->generateUrl('zoom_douala_show_quartier', array(
					'quartierChoisie'=>$quartierChoisie
				)));
	    	}
		}
		
		/** affichage d'un échantillon de rubriques sur la page d'accueil (rubriquesWindowObj) et du logo de leur entreprise representante si elle existe.
		**/
		$total = 24; // Nombre total de rubriques à afficher 
		// Array des id des rubriques représentés par une entreprise model
		$rubriqueWithModelId = array();
		$rubriqueWithNoModelId = array();
		$rubriqueWithModelObj = $em->getRepository('ZoomDoualaBundle:CompanyRep')->findBy(array("active"=>1), array());
		$countModels = count($rubriqueWithModelObj);
			// array of objects
		for( $i = 0; $i < $countModels; $i++ ){
			$rubriqueObj  = $rubriqueWithModelObj[$i]->getRubriqueId();
			$rubriqueId   = $rubriqueObj->getId(); // a rubrique id
			$companyrepId = $rubriqueWithModelObj[$i]->getId();
			$rubriqueWithModelId[$companyrepId] = $rubriqueId;
		}
			// randomize ids

			// list of duplicate items to delete
		$deleteListCreator = new KeysOfDuplicateValues;
		$deleteList = $deleteListCreator->getDuplicatedKey($rubriqueWithModelId);
			// Delete unwanted keys
		foreach( $deleteList as $key => $value ){
			unset( $rubriqueWithModelId[$value] );
		}

		// randomize activity sector to display
		$rubriqueWithModelId = $this->shuffle_assoc($rubriqueWithModelId);


		// Array des id des rubriques non représentés par une entreprise model
			// Array des id de toutes les rubriques
		$allRubriqueWithNoModelId = array();
		
		if( count($rubriqueWithModelId) < $total ){ // not enough activity sector model
			$allRubriqueWithNoModelObj  = $em->getRepository('ZoomDoualaBundle:Rubrique')->findAll(); // all ruriques
			$countAllRubrique = count($allRubriqueWithNoModelObj);
			
			for( $i = 0; $i < $countAllRubrique; $i++ ){	
				$rubriqueId = $allRubriqueWithNoModelObj[$i]->getId(); // a rubrique id
				if(!in_array($rubriqueId, $rubriqueWithModelId)){ // jump elements of $rubriqueWithModelId
					array_push( $allRubriqueWithNoModelId, $rubriqueId );
				}
			}
			// Create a random  array of index from allRubriqueWithNoModelId with Total - models values
			$rubriqueWithModelCount = count($rubriqueWithModelId);
			$necessaryTotal = (int)$total - (int)$rubriqueWithModelCount;// number of rubrique necessary to reach $total
			$rubriqueWithNoModelId = array();
			$countAllRubriqueWithNoModelId = count( $allRubriqueWithNoModelId );
			do {
				$necessary = array_rand($allRubriqueWithNoModelId, 1); // random key 
				$idvalue   = $allRubriqueWithNoModelId[$necessary];
				if( !in_array( $idvalue, $rubriqueWithNoModelId ) ){ // no duplications
					array_push( $rubriqueWithNoModelId, $idvalue ); // put when random value not already in array
				}
			} while ( count( $rubriqueWithNoModelId ) <= $necessaryTotal ); // random value already in array, do rand again
		}

		// Entire array of ids of objects to display
		$allWidgetRubriqueId = [];
		$i = 0;
		foreach($rubriqueWithModelId as $key => $value){
			$i++;
			if( count($allWidgetRubriqueId) < $total ){
				array_push($allWidgetRubriqueId, $value);
			}
		}
		foreach($rubriqueWithNoModelId as $key => $value){
			$i++;
			if( count($allWidgetRubriqueId) < $total ){
				array_push($allWidgetRubriqueId, $value);
			}
		}
		
		//array of objects to display
		$rubriquesWindow = array();
		for( $i = 0; $i < count($allWidgetRubriqueId); $i++ ){
			$rubriqueId  = $allWidgetRubriqueId[$i];
			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneBy(array('id'=>$rubriqueId ));
			array_push( $rubriquesWindow, $rubriqueObj ); // array of objects
		}

		// display		$representantsArray = array(); // array des representants (logo, nom, id)
		$i = 0;
		foreach($rubriquesWindow as $rubrique)
		{	
			$rubriqueId = $rubrique->getId(); 
			if(in_array($rubriqueId, $rubriqueWithModelId)){// entreprise representat la categorie
				$modelId = array_keys($rubriqueWithModelId, $rubriqueId);// modelid is stored as key
				$queryRepresentant = $em->createQuery('
											SELECT a FROM ZoomDoualaBundle:CompanyRep a                            			
											WHERE a.id =:modelId')
											->setParameters(array('modelId'=>$modelId ));
				$representantObj = $queryRepresentant->getResult(); // array of objects
//				var_dump($rubriqueId);
				if(!empty($representantObj)){
					$representant     = $representantObj[0]->getEntrepriseId();
                    $activiteId       = $representant->getId();
// var_dump($activiteId);
					if( $activiteId ){
                        $representantLogo = $representant->getPath03();
                        $representantNom  = $representant->getEntreprise();
					
                        // si un representat existe, on affiche son logo sinon le logo par default
                        if($representantLogo)
                        {
                            $representantsArray["logo"][$i] = $representantLogo;
                        }
                        else
                        {
                            $representantsArray["logo"][$i]  = "rubrique".$i.".gif";
                        }
					
                        $representantsArray["nom"][$i] = $representantNom;
                        $representantsArray["activiteId"][$i] = $activiteId;
                    }
				}
			}
			else
			{
				$representantsArray["logo"][$i]  = "rubrique".$i.".gif";
				$representantsArray["nom"][$i] = "";
			}
			$i++;
		}
		// Fin affichage des rubriques sur la page d'accueil
		
		// Affichage des entreprises à la une
		$entrepriseAlauneObj = $em->getRepository('ZoomDoualaBundle:CompanyAlaune')->findBy(array("active"=>1), array());
		$alauneArray = array();
		if( count( $entrepriseAlauneObj ) ){
			$i = 0;
			// list des entreprises à la une pour randomize
			$alauneIdsArray = array();
			foreach( $entrepriseAlauneObj as $k => $v ){
				$alaune   = $v->getEntrepriseId();
				$alauneId =  $alaune->getId();
				array_push($alauneIdsArray, $alauneId);
			}
;
			// randomize and select 37 ids
			$selectedIds = $this->randomize($alauneIdsArray, 24);
// var_dump($selectedIds);
			foreach( $selectedIds as $k => $v ){
				// $alaune = $v->getEntrepriseId();
				$alauneArray[$i]['entreprise'] = $entrepriseAlauneObj[$v]->getEntrepriseId()->getEntreprise(); // $v are selected key after 
				// Logo randomization
				if( $entrepriseAlauneObj[$v]->getEntrepriseId()->getPath03() ){
					$alauneArray[$i]['logo'] = $entrepriseAlauneObj[$v]->getEntrepriseId()->getPath03();
				}
				else{
					$alauneArray[$i]["logo"] = "default/logo".rand(0, 2).".gif";
				}
				$alauneArray[$i]['id'] = $entrepriseAlauneObj[$v]->getEntrepriseId()->getId();
				// ville
				
				// quartier
				
				// rue
				$i++;
			}
		}
		else{
			$alauneArray = null;
		}
//echo "<pre>";
//	var_dump($alauneArray);
//echo "</pre>";
		// Affichage des quatiers (boutons) sur la page d'accueil
		$quartierObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Quartier a 
	                            WHERE a.id != 0');
		$quartiers = $quartierObj->getResult();
		// Fin affichage des quatiers (boutons) sur la page d'accueil
        //affichage de la page d'accueil
		
		// lucky links datas
			// quartier names array
			    // random ids array
		$table        = "quartier";
		$entity       = ucfirst($table);
		$lastIdResult = $em->createQuery( "SELECT COUNT(a.id) FROM ZoomDoualaBundle:$entity a" );
		$lastIdObj    = $lastIdResult->getResult();
		$lastId       = $lastIdObj[0][1]; // number of rows
// var_dump($lastIdObj);
// var_dump($lastId);
// return "--";
		$length    = 3; //we want array of 3 elements
		$randomQuartierIdArray = $this->getRandomIdArray( $lastId, $table, $length );

		$quartierNamesArray = $this->getNamesArray( $randomQuartierIdArray, $table );

			// Rubrique names array
			    // random ids array
		$table     = "rubrique";
		$entity       = ucfirst($table);
		$lastIdResult = $em->createQuery( "SELECT COUNT(a.id) FROM ZoomDoualaBundle:$entity a" );
		$lastIdObj    = $lastIdResult->getResult();
		$lastId       = $lastIdObj[0][1]; // number of rows
// echo $lastId;
// return "Toto";
		$length    = 3; //we want array of 3 elements
		$randomRubriqueIdArray = $this->getRandomIdArray( $lastId, $table, $length );
		$rubriqueNamesArrayBrut = $this->getNamesArray( $randomRubriqueIdArray, $table );
				// translate rubrique array
		$tableId = 1;
		$rubriqueNamesArray = $this->getArrayTrans( $rubriqueNamesArrayBrut, $tableId );
// var_dump($rubriqueNamesArray);	
			// Companies names array
			    // random ids array
		$table     = "activite";
		$entity       = ucfirst($table);
		$lastIdResult = $em->createQuery( "SELECT COUNT(a.id) FROM ZoomDoualaBundle:$entity a" );
		$lastIdObj    = $lastIdResult->getResult();
		$lastId       = $lastIdObj[0][1]; // number of rows
		$length       = 3; //we want array of 3 elements
		$randomCompanyIdArray = $this->getRandomIdArray( $lastId, $table, $length );
		$companyNamesArray = $this->getNamesArray( $randomCompanyIdArray, $table );
		
// total number of rubrique in rubrique list form
		$resultResult  = $em->createQuery( "SELECT COUNT(a.id) 
											FROM ZoomDoualaBundle:rubrique a" );
		$resultObj     = $resultResult->getResult();
		$countrubrique = $resultObj[0][1]; // number of rows

// total number of district in rubrique list form
		$resultResult  = $em->createQuery( "SELECT COUNT(a.id) 
											FROM ZoomDoualaBundle:quartier a" );
		$resultObj     = $resultResult->getResult();
		$countquartier = $resultObj[0][1]; // number of rows
		// site datas (email, sitename, ...)
		$siteData = $this->getLocale();

		$currentRoute = $request->attributes->get('_route');
// echo $currentRoute;
//        if( $currentRoute == "zoom_douala_home﻿" ){
//			$page = "ZoomDoualaBundle:Show:default.html.twig";
//		}
//		else{
//			$page = "ZoomDoualaBundle:Show:testdefault.html.twig";
//		}

$page = "ZoomDoualaBundle:Show:testdefault.html.twig";

        return $this->render($page,  
							array(
									'formActivite'       => $formActivite->createView(), 
								    'formRubrique'       => $formRubrique->createView(), 
								    'formQuartier'       => $formQuartier->createView(), 
								    'representantsArray' => $representantsArray, 
									'alauneArray'        => $alauneArray,
								    'rubriquesWindow'    => $rubriquesWindow, 
								    'quartiers'          => $quartiers,
								    'luckydistrict'      => $quartierNamesArray,
								    'luckycompany'       => $companyNamesArray,
								    'luckysector'        => $rubriqueNamesArray,
								    'countrubrique'      => $countrubrique,
								    'countquartier'      => $countquartier,
								    'siteData'           => $siteData
								  )
							);
	}
	// return array of id and name from random id array
	public function getRandomIdArray( $lastId, $table, $length ){// asuming that lastId must be the highest id value
// echo $lastId.'-'.$table.'-'.$length;
		$em = $this->getDoctrine()->getManager();
		// is this id exist
		$randomIdArray   = array();

		do {
			$randId          = rand( 0, $lastId );
			$idCountedQuery  = $em->createQuery( "SELECT COUNT(a.id) FROM ZoomDoualaBundle:$table a
												  WHERE a.id = $randId" );
			$idCountedObj    = $idCountedQuery->getResult();
			$idCounted       = $idCountedObj[0][1]; // number of rows
// echo $idCounted."--";
			if( !in_array( $randId, $randomIdArray ) && $idCounted > 0 ){ // no duplications and id exist
				array_push( $randomIdArray, $randId ); // put when random value not already in array
			}
		}
		while ( count( $randomIdArray ) < $length  ); // random value already in 

		return $randomIdArray;
	}
	// return array of names from random id array
	public function getNamesArray($randomIdArray, $table){
		$namesArray = array();
		if( $table == 'activite' ){ // cas particulier de la table activite qui a un champ entreprise
			$field = 'entreprise';
		}
		else{
			$field = $table;
		}

		$em = $this->getDoctrine()->getManager();

		foreach( $randomIdArray as $key => $value ){
			$nomObj = $em->createQuery( "SELECT a.$field FROM ZoomDoualaBundle:$table a
										 WHERE a.id = $value" );
			$result = $nomObj->getResult();
			$thename   = $result[0][$field];
			$name = $this->miniCap( $thename ); // on s'assure du bon formatage
			array_push( $namesArray, ['name' => $name, 'id' => $value]); // id will be needed for translation
		}
// var_dump ($result);
		return $namesArray;
	}
	// return an array of translated name and id values
	public function getArrayTrans( $namesArray, $tableId ){ // namesArray is an array with [name, id]
		$translate  = new Translate;
		$language   = new Languagefromurl;
		$langueId   = $language->getLanguage();
		$translatedArray = array();
		foreach( $namesArray as $key => $value ){
			$name   = $value['name'];
			$termid = $value['id'];
			$trans  = $translate->getOneTranslation( $tableId, $termid, $langueId );
			if(!$trans){
				$trans = $name;
			}
			$translated = $this->miniCap( $trans ); // on s'assure du bon formatage
			array_push($translatedArray, ['name' => $translated, 'id' => $termid]);
		}
// echo $tableId.', '.$name.', '.$termid.' *';
		return $translatedArray;
	}
	// format text (mininmize + capitalize)
	public function miniCap( $text ){
		$formated = ucfirst(strtolower($text));
		return $formated;
	}
//////////////////////////////////////////////// RECHERCHE-ACTION 

 ///entreprise non trouvé	
 
public function showActiviteNullAction($activiteChoisie)
{
	return $this->render('ZoomDoualaBundle:Show:activiteNullShow.html.twig', array('activiteChoisie' => $activiteChoisie,));
}

////////////////////////////////////////  DETAILS DE L'ACTIVITE CHOISIE ///////

 public function showActiviteAction(Request $request, $from01, $from02, $activiteChoisie, $activiteId) //
 {
// echo "we are working on this page...98%";
	$em = $this->getDoctrine()->getManager();
	$activated   = "oui";

    $activiteObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneBy(array('entreprise'=>$activiteChoisie, 'id'=>$activiteId, 'activated'=>$activated));
	//
	$translate  = new Translate;
	$language   = new Languagefromurl;
	$langueId   = $language->getLanguage();
    
	if( !is_null($activiteObj ) ){
		// on retire les backslash
		$activite = str_replace('/', '',$activiteObj->getEntreprise()); // backslash are removed
		// premieres lettres en majuscule
		$activite = strtolower($activite); // on met tout les caracteres en muniscule
		$activite = ucwords($activite); // ucfirst of every words
		$wordArr = [];
		// upercase the first word after tiret
		if( strpos( $activite, '-' ) || strpos( $activite, '.' ) || strpos( $activite, '(' ) ){
			$wordArr  = str_split( $activite, 1 );
			foreach( $wordArr as $key => &$value ){
				if( $value == '-' || $value == '.' || $value == '(' ){
					$wordArr[$key + 1] = strtoupper( $wordArr[$key + 1] );
				}
			}
			$activite = implode( $wordArr );
		}

//var_dump($videoPath);
		//
		$logoPath = $activiteObj->getPath03();
		//
		$rubriqueId = $activiteObj->getRubriqueId();
		$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
		$rubrique = ucfirst(strtolower($rubriqueObj->getRubrique()));
		// tranlation
		$translatedRubrique = $translate->getOneTranslation( 1, $rubriqueId, $langueId ); // getOneTranslation($tableid, $wordid, $languageid)
		if( $translatedRubrique ){
			$rubrique = $translatedRubrique;
		}
		//
		$villeId = $activiteObj->getVilleId();
		$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
		$ville = ucfirst(strtolower($villeObj->getVille()));
		//
		$quartierId = $activiteObj->getQuartierId();
		$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
		$quartier = $quartierObj->getQuartier();
		$quartier =ucfirst(strtolower( $quartierObj->getQuartier()));
	//echo $rue;
		if($quartier == "Aucune")
		{
	   	 	$quartier = "";
		}
		//
		$rueId = $activiteObj->getRueId();
		$rueObj = "";
		// patch pour Gandi qui ne voit pas l'index Id = 0 
		if($rueId != 0)
		{
			$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
			// var_dump($rueObj);
			$rue = ucfirst(strtolower($rueObj->getRue()));
			//echo $rue;
		}
		else
		{
			$rue = "";
		}
		//
		$repereId = $activiteObj->getRepereId();
// echo $repereId."\r\n";
		// changement de l'id de  la rueId en nom de la rue
		// patch pour Gandi qui ne voit pas l'index Id = 0
		$repereObj = "";
		if($repereId)
		{
			$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId);
			// var_dump($repereObj);
			$repere = ucfirst(strtolower($repereObj->getRepere()));
			//echo $rue;

		}
		else
		{
			$repere = "";
		}
// echo $repere;
		// fin patch pour Gandi qui ne voit pas l'index Id = 0

		// MAPS BUBBLING - si l'activit? n'a pas de map, on prend celle du repere, sinon celle de la rue, sinon celle du qyuartier, sinon celle de Douala
		$map_cordonates = array();
		// $map_cordonates[0] = '0'; // lattitude
		// $map_cordonates[1] = '0'; // longitude
		$map = trim($activiteObj->getMap());
		// var_dump($map);
		$map_cordonates = explode(",",trim($map));
		// var_dump($map_cordonates);
		if(!$map_cordonates[0] || !$map_cordonates[1]) // l'activite n'a pas de map
		{
			if($repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId))
			{
				// la map du repere
				$map = $repereObj->getMap();
				$map_cordonates = explode(",",trim($map));
				//var_dump($map_cordonates);
			}
		}
		if(!$map_cordonates[0] || !$map_cordonates[1]) // le perere n'a pas de map
		{
			if($rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId))
			{
				// la map de la rue
				$map = $rueObj->getMap();
				$map_cordonates = explode(",",trim($map));
			}
		}
		if(!$map_cordonates[0] || !$map_cordonates[1])  // la rue n'a pas de map
		{       	//map du quartier
			if($quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId))
			{
				// la map de la rue
				$map = $quartierObj->getMap();
				$map_cordonates = explode(",",trim($map));
			}
		}
		if(!$map_cordonates[0] || !$map_cordonates[1]) // le quartier n'a pas de map
		{
			//map de la ville
			if($quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId))
			{
				$map = $quartierObj->getMap();
				$map_cordonates = explode(",",trim($map));
			}
		}
		if(!$map_cordonates[0] || !$map_cordonates[1]) // le quartier n'a pas de map
		{
			//map de la ville
			$villeId = $activiteObj->getVilleId();
			$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId); // la ville a tjrs une map
			$map = $villeObj->getMap();
			$map_cordonates = explode(",",trim($map));
		}
		// fin map

		$place = $activiteObj->getPlace(); 
		//
		$contact = $activiteObj->getContact();
		//
		$fonctionId = $activiteObj->getFonctionId();
		//
		if( $fonctionId != 0 ){
			$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);
			// var_dump($fonctionObj);
			$fonction = ucfirst(strtolower($fonctionObj->getFonction()));
			// traduction
			$translatedFonction = $translate->getOneTranslation( 2, $fonctionId, $langueId ); // getOneTranslation($tableid, $wordid, $languageid)
			if( $translatedFonction ){
				$fonction = $translatedFonction;
			}
			//echo $fonction;
		}
		else{
			$fonction = "";
		}
			// fin patch pour Gandi qui ne voit pas l'index Id = 0
		// telephone01
		if( strlen( $activiteObj->getTelephone01() ) > 6 ){
			$telephone01 = $activiteObj->getTelephone01();
		}
		else{
			$telephone01 = null;
		}
		// telephone02
		if( strlen( $activiteObj->getTelephone02() ) > 6 ){
			$telephone02 = $activiteObj->getTelephone02();
		}
		else{
			$telephone02 = null;
		}
		// fax
		if( strlen( $activiteObj->getFax() ) > 6 ){
			$fax = $activiteObj->getFax();
		}
		else{
			$fax = null;
		}
		// email
		$email = strtolower($activiteObj->getEmail());
// echo $activiteObj->getWeb()."\n";
		$website = $activiteObj->getWeb();
		// $website = strtolower(preg_replace('#^http://#', '', $activiteObj->getWeb()));
// $website = str_replace('/')
// echo $website."\n";
        
		$bp =  strtolower($activiteObj->getBp());
	// pour le breadscrumb
		$breadscrumb = array();
		if($from01 == "rubrique")
		{
	    	$breadscrumb[0] = "Search by activity area";
		}
		if($from01 == "quartier")
		{
	    	$breadscrumb[1] = "Search by district";
		}
		if($from01 == "rue")
		{
	   		$breadscrumb[2] =  "Search by street";
		}
		if($from01 == "motcle")
		{
	    	$breadscrumb[3] = "Search by company name";
		}

		// site datas (email, sitename, ...)
		$siteData = $this->getLocale();

		// entreprise model
        $entrepriseModel  = "";
        $entrepriseModels = $em->getRepository('ZoomDoualaBundle:CompanyRep')
								   ->findBy( array( 
                                    "active" => 1, 
                                    "rubriqueId" => $rubriqueId 
                                ), array() );
        if( !count( $entrepriseModels ) ){ // si il n'ya pas d'entreprise model, on prend une entreprise de la rubrique
            $entreprises = $em->getRepository('ZoomDoualaBundle:Activite')
								   ->findBy( array(
                                        "rubriqueId" => $rubriqueId,
                                        "activated"  => "oui",
                                    ), array());
            foreach( $entreprises as $v ){
                $entrepriseModel = $v;
            }
        }
        else{
            $entrepriseModel  = $entrepriseModels[0]->getEntrepriseId();
        }

        $entrepriseModel_id     = $entrepriseModel->getId();
        $entrepriseModel_nom    = $entrepriseModel->getEntreprise();  
// echo "entrepriseModel_nom: " . $entrepriseModel_nom;
// die; 
        $entrepriseModel_phone  = $entrepriseModel->getTelephone01();
        $entrepriseModel_email      = $entrepriseModel->getEmail();
        $entrepriseModelQuartierId  = $entrepriseModel->getQuartierId();
        $entrepriseModelQuartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')
                                         ->findOneById( $entrepriseModelQuartierId ) ;
        $entrepriseModel_quartier   = $entrepriseModelQuartierObj->getQuartier();
        
        $entrepriseModelRueId   = $entrepriseModel->getRueId();
        $entrepriseModelRueObj  = $em->getRepository('ZoomDoualaBundle:Rue')
                                     ->findOneById( $entrepriseModelRueId ) ;
        if( !is_null( $entrepriseModelRueObj ) )
            $entrepriseModel_rue    = $entrepriseModelRueObj->getRue();
        else
            $entrepriseModel_rue = null;
         
        $entrepriseModelVilleId   = $entrepriseModel->getVilleId();
        $entrepriseModelVilleObj  = $em->getRepository('ZoomDoualaBundle:Ville')
                                     ->findOneById( $entrepriseModelVilleId ) ;
        $entrepriseModel_ville    = $entrepriseModelVilleObj->getVille();
        
        $entrepriseModel_path03 = $entrepriseModel->getPath03();
        
        $entrepriseModelInfo    = Array();
        
        $entrepriseModelInfo[ "entreprise" ]    = $entrepriseModel_nom;
        $entrepriseModelInfo[ "phone" ]         = $entrepriseModel_phone;
        $entrepriseModelInfo[ "email" ]         = $entrepriseModel_email;
        $entrepriseModelInfo[ "quartier" ]      = $entrepriseModel_quartier;
        $entrepriseModelInfo[ "rue" ]           = $entrepriseModel_rue;
        $entrepriseModelInfo[ "id" ]            = $entrepriseModel_id;
        $entrepriseModelInfo[ "path03" ]        = $entrepriseModel_path03;
        $entrepriseModelInfo[ "ville" ]         = $entrepriseModel_ville;
        
		$rubriqueChoisie    = $rubriqueObj->getRubrique();

        // Gogle map image
        // Check if there is a Google map image for tis company
        $asset_path = $this->get('assets.packages')->getUrl('bundles/zoomdouala/images');

        $path = $_SERVER['DOCUMENT_ROOT'] . $asset_path . '/' . $activiteId . '/screenshot.jpg';
        $http = $_SERVER['SERVER_NAME'] == 'localhost' ? 'http://' : 'https://';
        $mapImg =  file_exists( $path ) === true ? $http.$_SERVER['SERVER_NAME'].$asset_path.'/'.$activiteId.'/screenshot.jpg' : '';
      
        // Company Photos
        $images     = Array();
        $photos_array = Array();
        $main_photo = $activiteObj->getPath01();
// echo 'Main photo: ' . $main_photo;
        // Main photo
        $main_photo_path = '';  
        $asset_path02 = $this->get('assets.packages')->getUrl('/uploads/documents/');
		if( $main_photo ){
            $asset_path_main = $this->get('assets.packages')->getUrl('uploads/documents');
            
            $tab['path'] = $http.$_SERVER['SERVER_NAME'].$asset_path02.'/'.$main_photo;
            $tab['description']     = '';
            $tab['price']           = '';
            $tab['name']            = $activite;
            $tab['imgId']           = '';
            
            $images[] = $tab;
        }
        
		// Additional pictures
        $image_tab  = $activiteObj->getImages();
        
        
        $indice = 1;
        foreach( $image_tab as $image ){
            $tab = Array();
            
            $tab['path']            = $http.$_SERVER['SERVER_NAME']. $asset_path02 . $image->getPath();
            $tab['description']     = ( $image->getDescription() ) ? $image->getDescription() : '';
            $tab['price']           = ( $image->getPrix() ) ? $image->getPrix() : '';
            $tab['name']            = ( $image->getName() ) ? $image->getName() : 'Photo ' . $indice;
            $tab['imgId']           = $image->getId();
            
            $images[] = $tab;
            $indice ++;
        }

        // Lat long
        $path = $_SERVER['DOCUMENT_ROOT'] . $asset_path . '/' . $activiteId; // check if folder exist

        $lat = '';
        $lon = '';
        if( file_exists( $path ) ){ 
            $latlonFilePath =  $this->get('assets.packages')->getUrl('/bundles/zoomdouala/images/' . $activiteId );
            $latlonFilename = 'cordonates.txt';
            $fileURL = $http.$_SERVER['SERVER_NAME'].$latlonFilePath.'/'. $latlonFilename;

            $fh = fopen($fileURL,'r');
            $text_tab = explode( ',', fgets($fh) );          
            $lat_str = $text_tab[0];
            $lon_str = $text_tab[1]; 
            $lat_tab =  explode( ':', $lat_str );
            $lon_tab =  explode( ':', $lon_str );
            $lat = trim( $lat_tab[1] ); 
            $lon = trim( $lon_tab[1] );
            $lat = str_replace("\"","",$lat);
            $lon = str_replace("\"","",$lon);
            
        } 
               
		$videoPath = $activiteObj->getPath02();
        
//echo  $_SERVER['SERVER_NAME'] . $asset_path . '/' . $activiteId . '/screenshot.png';
//die();
		return $this->render('ZoomDoualaBundle:Show:activiteShow.html.twig', array
								(
									'videoPath' 	  => $videoPath, 
									'photos_array'	  => $images, 
									'activite'        => $activite, 
									'rubrique'        => $rubrique, 
									'logoPath'        => $logoPath, 
									'telephone01'     => $telephone01, 
									'telephone02'     => $telephone02, 
									'fax'             => $fax, 
									'email'           => $email, 
									'quartier'        => $quartier, 
									'rue'             => $rue, 
									'place'           => $place, 
									'repere'          => $repere, 
									'map'             => $map, 
									'website'         => $website, 
									'contact'         => $contact, 
									'fonction'        => $fonction,
									'from01'          => $from01,
									'from02'          => $from02,
									'activiteChoisie' => $activiteChoisie,
									'rubriqueChoisie' => $rubriqueChoisie,
									'breadscrumb'     => $breadscrumb, 
									'ville'           => $ville, 
									'map_cordonates'  => $map_cordonates, 
									'bp'              => $bp,
									'rubriqueId'      => $rubriqueId,
									'siteData'        => $siteData,
									'localData'		  => $this->getLocale(),
									'entrepriseModelInfo' => $entrepriseModelInfo,
                                    'mapImg'            => $mapImg,
                                    'lat'               => $lat,
                                    'lon'               => $lon
								)
							);
	}
	else
	{
		// redirection vers la page d'accueil
        return $this->redirect($this->generateUrl('zoom_douala_default'));
	}
}

///////////////////////////// LISTE  LES ACTIVITES issues du formulaire de recherche par nom quand l'entrprise n'a pas été slelectionnée mais saisie sans la prendre dans l'autocompletion ////////////////////////
    public function activiteListAction($activiteSaisie, Request $request)
	{
// echo "travaux en cours sur cette page.. 99% <br>";

		$idzero = 0;
		// Activite saisise 
		$activated = 'oui';
		$em = $this->getDoctrine()->getManager();
		$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a WHERE a.id !=:id AND a.entreprise LIKE :activiteSaisie ORDER BY a.entreprise ASC')
				->setParameters(array('activiteSaisie'=>'%'.$activiteSaisie.'%', 'id' => $idzero));
		
     	$activites = $query->getResult();	
		$conteur = count($activites);
		// changer le nom des quartiers en rempla?ant l'id par le nom de la quartier et cr?ee le tableau des index alphabetique ? afficher
		$indexAlphaArray = array();
		$indexAlphaArray[0] = "";
		$lastinsertedId = 0;
		$pagelimit = 25; // limit par page de la pagination knp

		// nombre d'entreprise à afficher / total paginé
		if($conteur < $pagelimit)
		{
			$toshow = $conteur;
		}
		else
		{
			$toshow = $pagelimit;
		}
		//
// echo $indexPaginationQuartier;
		foreach($activites as $index=>$activite)
		{
			// on enleve les caracteres sp?ciaux dans le nom de l'activit?
			$entreprise = str_replace('/', '', $activite->getEntreprise());
			$activite->setEntreprise($entreprise);
			// changement de l'id de  la villeId en nom de ville
			$villeId = $activite->getVilleId();
		    $villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
			$ville = $villeObj->getVille();
			$activite->setVilleId($ville);
			// changement de l'id de  la rueId en nom de la rue
			$rueId = $activite->getRueId();
			// patch pour Gandi qui ne voit pas l'index Id = 0 
		    if($rueId != 0)
			{
				$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
				// var_dump($rueObj);
				$rue = ucfirst(strtolower($rueObj->getRue()));
				//echo $rue;
			}
			else
			{
				$rue = "";
			}
			// fin patch pour Gandi qui ne voit pas l'index Id = 0 
			$activite->setRueId($rue);
			// changement de l'Id du quartier en nom du quartier
			$quartierId = $activite->getQuartierId();
// echo "Quartier:".$quartierId;
			// patch pour Gandi qui ne voit pas l'index Id = 0 
		    if($quartierId != 0)
			{
				$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
//var_dump($quartierObj);
				$quartier = ucfirst(strtolower($quartierObj->getQuartier()));
				//echo $quartier;
			}
			else
			{
				$quartier = "";
			}
			$activite->setQuartierId($quartier);
//echo "Quartier:".$quartier;
			// logo par defaut
			$logo = $activite->getPath03();
			if(!isset($logo))
			{
				$activite->setPath03("default/logo".array_rand([1,2,3], 1).".gif");
			}
			else{
				$activite->setPath03("../../../uploads/documents/".$logo);
			}
			//
			// Affichage du bouton "Details" de cette quartier: est-ce qu'il ya des entreprises dans quartier
			if($conteur > 0)
			{
		    	$afficher_btn_details = 1;
			}
			else
			{
		    	$afficher_btn_details = "";
			}
			// tableau des index alphabetique des entrprises
			// l'index alphabetique de l'entreprise
			$alpha = ucfirst($entreprise[0]);
			$indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
			if($index==0) // premiere insertion ou insetion diferente de la derni?re
			{
				$indexAlpha = $alpha;
				$indexAlphaArray[$index] =  $alpha; 
			}
			else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
			{
				$indexAlpha = $alpha;
			}
			else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
			{
				$indexAlpha = "";
			}
			$lastinsertedId = $index;
			//
			// Fabrication de l'array des lignes ? afficher
			$lignesEntreprise[$index]["alpha"] = $indexAlpha;
			$lignesEntreprise[$index]["entreprise"] = $activite->getEntreprise();
			$lignesEntreprise[$index]["telephone01"] = $activite->getTelephone01();
			$lignesEntreprise[$index]["email"] = strtolower ($activite->getEmail());
			$lignesEntreprise[$index]["quartierId"] = $activite->getQuartierId();
			$lignesEntreprise[$index]["villeId"] = $ville;
			$lignesEntreprise[$index]["path03"] = $activite->getPath03(); // logo;
			$lignesEntreprise[$index]["button"] = $afficher_btn_details;
			$lignesEntreprise[$index]["nombre"] = $conteur;
			$lignesEntreprise[$index]["rueId"] = $activite->getRueId();
			$lignesEntreprise[$index]["logo"] = $activite->getPath03();
			$lignesEntreprise[$index]["id"] = $activite->getId();
		}
// var_dump($lignesEntreprise);
/////// Pagination knp_paginator
		$paginator  = $this->get('knp_paginator');
		$pagination = "";
	    if($conteur)
		{
			$pagination = $paginator->paginate($lignesEntreprise, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
		}
		
		return $this->render('ZoomDoualaBundle:Show:activiteList.html.twig', array(
			'pagination' => $pagination, 'type' => 'Entreprise', 'activiteSaisie' => $activiteSaisie, 'indexAlpha' => $indexAlphaArray, 'totalEntreprise' => $conteur, 'toshow'=>$toshow));
    }
	
    // list company with given tag
    public function activiteTagListAction($tag, Request $request)
	{
        //  get companies with given tag
		$idzero = 0;
		// Activite saisise 
		$activated = 'oui';
		$em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('ZoomDoualaBundle:Activite');
        $activites = $repository->createQueryBuilder('u')
            ->innerJoin('u.tags', 't')
            ->where('t.name = :tag_name')
            ->setParameter('tag_name', $tag)
            ->getQuery()->getResult();

		$conteur = count($activites);
        
// echo 'Conteur: ' . $conteur;
// die();
		// changer le nom des quartiers en rempla?ant l'id par le nom de la quartier et cr?ee le tableau des index alphabetique ? afficher
		$indexAlphaArray = array();
		$indexAlphaArray[0] = "";
		$lastinsertedId = 0;
		$pagelimit = 25; // limit par page de la pagination knp

		// nombre d'entreprise à afficher / total paginé
		if($conteur < $pagelimit)
		{
			$toshow = $conteur;
		}
		else
		{
			$toshow = $pagelimit;
		}
		//
// echo $indexPaginationQuartier;
		foreach($activites as $index=>$activite)
		{
			// on enleve les caracteres sp?ciaux dans le nom de l'activit?
			$entreprise = str_replace('/', '', $activite->getEntreprise());
			$activite->setEntreprise($entreprise);
			// changement de l'id de  la villeId en nom de ville
			$villeId = $activite->getVilleId();
		    $villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
			$ville = $villeObj->getVille();
			$activite->setVilleId($ville);
			// changement de l'id de  la rueId en nom de la rue
			$rueId = $activite->getRueId();
			// patch pour Gandi qui ne voit pas l'index Id = 0 
		    if($rueId != 0)
			{
				$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
				// var_dump($rueObj);
				$rue = ucfirst(strtolower($rueObj->getRue()));
				//echo $rue;
			}
			else
			{
				$rue = "";
			}
			// fin patch pour Gandi qui ne voit pas l'index Id = 0 
			$activite->setRueId($rue);
			// changement de l'Id du quartier en nom du quartier
			$quartierId = $activite->getQuartierId();
// echo "Quartier:".$quartierId;
			// patch pour Gandi qui ne voit pas l'index Id = 0 
		    if($quartierId != 0)
			{
				$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
//var_dump($quartierObj);
				$quartier = ucfirst(strtolower($quartierObj->getQuartier()));
				//echo $quartier;
			}
			else
			{
				$quartier = "";
			}
			$activite->setQuartierId($quartier);
//echo "Quartier:".$quartier;
			// logo par defaut
			$logo = $activite->getPath03();
			if(!isset($logo))
			{
				$activite->setPath03("default/logo".array_rand([1,2,3], 1).".gif");
			}
			else{
				$activite->setPath03("../../../uploads/documents/".$logo);
			}
			//
			// Affichage du bouton "Details" de cette quartier: est-ce qu'il ya des entreprises dans quartier
			if($conteur > 0)
			{
		    	$afficher_btn_details = 1;
			}
			else
			{
		    	$afficher_btn_details = "";
			}
			// tableau des index alphabetique des entrprises
			// l'index alphabetique de l'entreprise
			$alpha = ucfirst($entreprise[0]);
			$indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
			if($index==0) // premiere insertion ou insetion diferente de la derni?re
			{
				$indexAlpha = $alpha;
				$indexAlphaArray[$index] =  $alpha; 
			}
			else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
			{
				$indexAlpha = $alpha;
			}
			else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
			{
				$indexAlpha = "";
			}
			$lastinsertedId = $index;
			//
			// Fabrication de l'array des lignes ? afficher
			$lignesEntreprise[$index]["alpha"] = $indexAlpha;
			$lignesEntreprise[$index]["entreprise"] = $activite->getEntreprise();
			$lignesEntreprise[$index]["telephone01"] = $activite->getTelephone01();
			$lignesEntreprise[$index]["email"] = strtolower ($activite->getEmail());
			$lignesEntreprise[$index]["quartierId"] = $activite->getQuartierId();
			$lignesEntreprise[$index]["villeId"] = $ville;
			$lignesEntreprise[$index]["path03"] = $activite->getPath03(); // logo;
			$lignesEntreprise[$index]["button"] = $afficher_btn_details;
			$lignesEntreprise[$index]["nombre"] = $conteur;
			$lignesEntreprise[$index]["rueId"] = $activite->getRueId();
			$lignesEntreprise[$index]["logo"] = $activite->getPath03();
			$lignesEntreprise[$index]["id"] = $activite->getId();
		}
// var_dump($lignesEntreprise);
/////// Pagination knp_paginator
		$paginator  = $this->get('knp_paginator');
		$pagination = "";
	    if($conteur)
		{
			$pagination = $paginator->paginate($lignesEntreprise, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
		}
		
		return $this->render('ZoomDoualaBundle:Show:activiteList.html.twig', array(
			'pagination' => $pagination, 'type' => 'Tag', 'activiteSaisie' => $tag, 'indexAlpha' => $indexAlphaArray, 'totalEntreprise' => $conteur, 'toshow'=>$toshow));
    }
    
	// page de contact
	public function contactAction(Request $request)
	{
		$contactLayoutFormObj = new contactLayoutForm(); // pour le formulaire de contact de la page d'accueil
		$contactLayoutForm = $this->createForm($contactLayoutFormObj);
		return $this->render('ZoomDoualaBundle:Show:contact.html.twig', array('contactLayoutForm' => $contactLayoutForm->createView()));
	}
	
	// en fonction de l'entrée validée, on redirige vers la page de modification d' l'ajout
	public function contactEntrepriseIntroAction(Request $request)
    {
		// si les cookies des listbox son deja pret sur le serveur, on ouvre la page de modif
		if(isset($_COOKIE['nomEntreprise']) && isset($_COOKIE['entrepriseId'])){
			return $this->redirect(
				$this->generateUrl(
					'zoom_douala_zoom_contactEntrepriseModif', array(
						'selected' => $_COOKIE['nomEntreprise'], 
						'id' => $_COOKIE['entrepriseId']  
					)
				)
			);	
		}
		//
		$em = $this->getDoctrine()->getManager();
		$contactEntrepriseIntroForm = $this->createForm(contactEntrepriseIntroForm::class);
		$contactEntrepriseIntroForm->handleRequest($request);
		// entreprise saisie
		$message = "";
		if ($contactEntrepriseIntroForm->isValid())
		{
			$entrepriseChoisieData = $contactEntrepriseIntroForm['entreprise']->getData();
			
			// on verifie qu'il n'ya pas de caractere illegale
			$interdit = ["*", ".", "/", "\\", "[", "]", ":", ";", "|", "=", "_"];
			
			foreach($interdit as $value){
				if($entrepriseChoisieData[0] === $value){
					$message = "Illegal charactere '".$value."'";
					// formulaire de contactEntrepriseIntroForm
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseIntro.html.twig', array(
							 'contactEntrepriseIntroForm' => $contactEntrepriseIntroForm->createView(),
							 'message' => $message,
					 ));
				}
			}
			
			if(ini_get('magic_quotes_gpc'))
			{
				$entrepriseChoisieData = stripslashes($entrepriseChoisieData);
				$entrepriseChoisieData = htmlspecialchars(strip_tags($entrepriseChoisieData));
			}
			$entrepriseChoisieTab = explode(',', $entrepriseChoisieData);
			// recuperation des info du formulaire (entreprise, quartier et id)
			$selected = trim($entrepriseChoisieTab[0]);
			// recupération du nom de l'entreprise sasie et création d'un cookie le contenant

			$nomEntreprise_value = $selected;
			
			// on verifie l'existance des cookie de l'entreprise en cours.

				if(array_key_exists(1, $entrepriseChoisieTab)){ // quartier
					$qartierTab = explode(' - ', $entrepriseChoisieTab[1]);
					$quartier = trim($qartierTab[0]);		
				}
				else{ // on va sur la page d'ajout d'une entreprise car ya pas tout les element pour la modif
					return $this->redirect($this->generateUrl('zoom_douala_contactEntrepriseRedirectAjout', array(
					'selected' => $selected)));
				}
				if(array_key_exists(1, $qartierTab)){ // id
					$entrepriseId = trim($qartierTab[1]);
				}
				else{// on va sur la page d'ajout d'une entreprise car ya pas tout les element pour la modif
					return  $this->redirect($this->generateUrl('zoom_douala_contactEntrepriseRedirectAjout', array(
				    	'selected' => $selected)));			
				}
				// Id du quartier
				if ($quartier){	
					$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
					$quartierId = $quartierObj->getId();	
				}
				else{// on va sur la page d'ajout d'une entreprise car ya pas tout les element pour la modif
					return $this->redirect($this->generateUrl('zoom_douala_contactEntrepriseRedirectAjout', array(
					'selected' => $selected)));	
				}
  				// set cookie et recharge de cette page
				$entrepriseObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneBy(array('entreprise'=>$selected,'quartierId'=>$quartierId,'id'=>$entrepriseId));
			
			// Preparation des elements pour cookies
				if($entrepriseObj) // modif
				{	
					$translate = new Translate;
					$language = new Languagefromurl;
					$langueId = $language->getLanguage();
					//entit? de l'entreprise selection?e
					$selectedObj = $em->getRepository('ZoomDoualaBundle:Activite')->findOneByEntreprise($selected);
					
					// Rubrique
					$oldRubriqueId = $selectedObj->getRubriqueId();
					$oldRubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($oldRubriqueId);
					$oldRubrique = $oldRubriqueObj->getRubrique();
					
					// Fonction
					$oldFonctionId = $selectedObj->getFonctionId();
					$oldFonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($oldFonctionId);
					if($oldFonctionObj){
						$oldFonction = $oldFonctionObj->getFonction();
					}
					else{
						$oldFonction = "";
					}
					// Ville
					$oldVilleId = $selectedObj->getVilleId();
					$oldVilleObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($oldVilleId);
					$oldVille = $oldVilleObj->getVille();
					
					// Quartier
					$oldQuartierId = $selectedObj->getQuartierId();
					$oldQuartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($oldQuartierId);
					$oldQuartier = $oldQuartierObj->getQuartier();
					
					// Adsize
					$oldAdsize = '';
					
					// Fabrication des cookies
					setcookie('oldRubrique', $oldRubrique, time() + (86400 * 30), '/');
					setcookie('oldFonction', $oldFonction, time() + (86400 * 30), '/');
					setcookie('oldVille', $oldVille, time() + (86400 * 30), '/');
					setcookie('oldQuartier', $oldQuartier, time() + (86400 * 30), '/');
					setcookie('oldAdsize', $oldAdsize, time() + (86400 * 30), '/');
					setcookie('entrepriseId', $entrepriseId, time() + (86400 * 30), '/');
					setcookie('nomEntreprise', $nomEntreprise_value, time() + (86400 * 30), '/');
							// some ids to ease translation on the form
					setcookie('oldRubriqueId', $oldRubriqueId, time() + (86400 * 30), '/');		
					setcookie('oldFonctionId', $oldFonctionId, time() + (86400 * 30), '/');
					
					// rechargement de la page pour "activer" les cookies
					return $this->redirect($this->generateUrl('zoom_douala_zoom_contactEntrepriseIntro', array(
					'contactEntrepriseIntroForm' => $contactEntrepriseIntroForm->createView(),)));
				}
				else{ // l'entreprise n'existe pas: redirection: c'est une entreprise à Ajouter
					return $this->redirect($this->generateUrl('zoom_douala_contactEntrepriseRedirectAjout', array(
					'selected' => $selected)));
				}
 // les cookies sont deja créé et activés, on va sur la page de modif
					return $this->redirect($this->generateUrl('zoom_douala_zoom_contactEntrepriseModif', array(
					'selected' => $selected,
					'id' => $_COOKIE['entrepriseId'],
					)));
					
				$contactEntrepriseIntroForm = $this->createForm(contactEntrepriseIntroForm::class);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
							 'id' => $_COOKIE['entrepriseId'],
							 'selected' => $selected,
							 'contactEntrepriseModifier' => $contactEntrepriseIntroForm->createView(),
				 ));
			
		}
		// formulaire de contactEntrepriseIntroForm
		return $this->render('ZoomDoualaBundle:Show:contactEntrepriseIntro.html.twig', array(
							 'contactEntrepriseIntroForm' => $contactEntrepriseIntroForm->createView(),
							 'message' => $message,
							 ));
	}
	
	// formulaire d'insertion de l'netreprise ? traiter
	public function contactEntrepriseRedirectAjoutAction(Request $request, $selected) // $theuserid = envoyeur
    {
		setcookie('nomEntreprise', $selected, time() + (86400 * 30), '/');
		
		if (!isset($_COOKIE['nomEntreprise'])){ // le cookie n'est pas pret, on recharge la page
			return $this->redirect($this->generateUrl('zoom_douala_contactEntrepriseRedirectAjout', array(
					'selected' => $selected,
					)));
		}
		else if(isset($_COOKIE['nomEntreprise'])){
			return $this->redirect($this->generateUrl('zoom_douala_zoom_contactEntrepriseAjout'));
		}
	}

	// page d'ajout d'une entreprise
	function contactEntrepriseAjoutAction(Request $request)
	{
		$translator = $this->get('translator');
		$activite = new Activite();		
		$contactEntrepriseAjouterForm = $this->createForm(contactEntrepriseAjouterForm::class, $activite );
		//$request = $this->container->get('request');
		$contactEntrepriseAjouterForm->handleRequest($request);
		$em = $this->getDoctrine()->getManager();
		if ($contactEntrepriseAjouterForm->isSubmitted() && $contactEntrepriseAjouterForm->isValid())  // formulaire POST
		{  			
			$datas = $contactEntrepriseAjouterForm->getData();
			// farication de la chaine des donn?es du formulaire ? envoyer par mail
				//rubrique
			$rubriqueId = $datas->getRubriqueId();
			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
			$form_rubrique = $rubriqueObj->getRubrique();
				//entreprise
			$form_entreprise = $contactEntrepriseAjouterForm['entreprise']->getData();
				//bp
			$form_bp = $contactEntrepriseAjouterForm['bp']->getData();
				//telephone01
			$form_telephone01 = $contactEntrepriseAjouterForm['telephone01']->getData();
				//
			$form_telephone02 = $contactEntrepriseAjouterForm['telephone02']->getData();
				//
			$form_fax = $contactEntrepriseAjouterForm['fax']->getData();
				//
			$form_contact = $contactEntrepriseAjouterForm['contact']->getData();
				//fonction
			$form_fonction = "aucune";
			$fonctionId = $datas->getFonctionId();
			if($fonctionId){
				$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);$form_fonction = $fonctionObj->getFonction();
			}

// var_dump($fonctionId);
				//
			$form_ville = $contactEntrepriseAjouterForm['villeId']->getData();
				//
			$form_quartier = $contactEntrepriseAjouterForm['quartierId']->getData();
			//
			// filtrage des reperes
			$form_repere = stripslashes($contactEntrepriseAjouterForm['repereId']->getData());
			$form_rue = htmlspecialchars(strip_tags($form_repere));
			//
			$form_details = $contactEntrepriseAjouterForm['place']->getData();
			// filtrage des rues
			$form_rue = stripslashes($contactEntrepriseAjouterForm['rueId']->getData());
			$form_rue = htmlspecialchars(strip_tags($form_rue));
			//
			$form_email = $contactEntrepriseAjouterForm['email']->getData();
			$form_web = $contactEntrepriseAjouterForm['web']->getData();
			// filtrage de l'adresse web et des slash
			$form_web = str_replace("http://","",$form_web);
			// filtrage de AdSize et ses apostrophes
			$form_adsize =  str_replace("'","",$contactEntrepriseAjouterForm['adsizeId']->getData());
			// filtrage de Alaune et ses apostrophes
			$form_alaune =  str_replace("'","",$contactEntrepriseAjouterForm['alaune']->getData());
			// Clean up these input values
			if(ini_get('magic_quotes_gpc'))
			{	
				//contact
				$form_contact = stripslashes($form_contact);
				$form_contact = htmlspecialchars(strip_tags($form_contact));
			}
			$form_map = $contactEntrepriseAjouterForm['map']->getData();
			$form_datas = "Entreprise: ".$form_entreprise." - "."Rubrique: ".$form_rubrique." - "."Bp: ".$form_bp." - "."telephone01: ".$form_telephone01." - "."telephone02: ".$form_telephone02." - "."fax: ".$form_fax." - "."contact: ".$form_contact." - "."fonction: ".$form_fonction." - "."ville: ".$form_ville." - "."quartier: ".$form_quartier." - "."repere: ".$form_repere." - "."details: ".$form_details." - "."map: ".$form_map." - "."email: ".$form_email." - "."web: ".$form_web." - "."rue: ".$form_rue." - "."Nombre de mois Represantant de sa rubrique: "." - ".$form_adsize." - Nombre de mois A la une: ".$form_alaune;
			//
		    // Reperes: si le rep?re saisie n'existe pas encore dans la base de donn?e, on l'ajoute dans la table repere
		    $repereSaisie = trim($contactEntrepriseAjouterForm['repereId']->getData());
			// est ce que un repere a ?t? saisie
			if($repereSaisie != "")
			{ 
				// est ce que ce repere existe d?ja sinon on le cr?e
				$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneByRepere($repereSaisie );
//var_dump($repereObj);
				$repereCount = sizeof($repereObj);
//echo $repereCount ;
				if($repereCount==0 AND $contactEntrepriseAjouterForm['repereId']->getData()!= '') //nouveau repere
				{   
					$em01 = $this->getDoctrine()->getManager();
					//quartierId du repere en fonction du nom du quartier
					$quartier = trim($contactEntrepriseAjouterForm['quartierId']->getData());
					$quartierObj = $em01->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
					$quartierId = $quartierObj->getId();
					// villeId du repere
					$ville = trim($contactEntrepriseAjouterForm['villeId']->getData());
					$villeObj = $em01->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($ville);
					$villeId = $villeObj->getId();
					// repere
					$repere = new Repere();
					$repere->setRepere($repereSaisie);
					$repere->setQuartierId($quartierId);
					$repere->setVilleId($villeId);
					//// on persist la base de donn?e avec le nouveau Repere
				   $em->persist($repere); 
				   $em->flush();
				}
			}
			// fin traitement des Reperes
			
			// Traitement des rues
			// Rue: si la rue saisie n'existe pas encore dans la base de donn?e, on l'ajoute dans la table Rue
		    $rueSaisie = trim($contactEntrepriseAjouterForm['rueId']->getData());
			// est ce que une rue a ?t? saisie
			if($rueSaisie)
			{ 
				// est ce que cette rue existe d?ja sinon on la cr?e
				$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneByRue($rueSaisie );
//var_dump($repereObj);
				$rueCount = sizeof($rueObj);
//echo $repereCount ;
				if($rueCount==0) //nouvelle rue
				{  
					$em01 = $this->getDoctrine()->getManager();
					//quartierId de la rue en fonction du nom du quartier
					$quartier = trim($contactEntrepriseAjouterForm['quartierId']->getData());
					$quartierObj = $em01->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartier);
					$quartierId = $quartierObj->getId();
					// villeId de la rue
					$ville = trim($contactEntrepriseAjouterForm['villeId']->getData());
					$villeObj = $em01->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($ville);
					$villeId = $villeObj->getId();
					// prorpietés de la rue
					$rue = new Rue();
					$rue->setRue($rueSaisie);
					$rue->setQuartierId($quartierId);
					$rue->setVilleId($villeId);
					//// on persist la base de donn?e avec la nouvelle Rue
				    $em->persist($rue); 
				    $em->flush();
				}
			}
			// fin traitement des rues
			// Recup?rationdes Id en fonction des noms sur le formulaire avant de sauvegarder
			// Id de la ville ? partir du nom de la ville
			$villeId = trim($contactEntrepriseAjouterForm['villeId']->getData());
			$villeObj = $em->getRepository('ZoomDoualaBundle:Ville')->findOneByVille($villeId);
			$ville = $villeObj->getId();
			$activite->setVilleId($ville);
			// Id du quartier ? partir du nom duu quartier
			$quartierId = trim($contactEntrepriseAjouterForm['quartierId']->getData()); 
			$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneByQuartier($quartierId);
			$quartier = $quartierObj->getId();
			$activite->setQuartierId($quartier);
			// site web
			$web = trim($contactEntrepriseAjouterForm['web']->getData()); 
			$activite->setWeb($web);
			// Id de la fonction ? partir du nom de la fonction
			$fonctionId = trim($contactEntrepriseAjouterForm['fonctionId']->getData());
//var_dump($datas->getFonctionId());
			if ($fonctionId){
				$activite->setFonctionId($fonctionId);
			}
			else{ // pas de fonction choisie
				$activite->setFonctionId(0);
			}
			// Id de la rubrique ? partir du nom de la rubrique
			$rubriqueId = trim($contactEntrepriseAjouterForm['rubriqueId']->getData()); 
			$activite->setRubriqueId($rubriqueId);
			// Id de adsize  partir du nom de la adsize
//			$adsizeId = trim($contactEntrepriseAjouterForm['adsizeId']->getData()); 
//			if ($adsizeId){ 
//				$adsizeObj = $em->getRepository('ZoomDoualaBundle:Adsize')->findOneById($adsizeId);
//				$adsize = $adsizeObj->getId();
//				$activite->setAdsizeId($adsize);
//			}
//			else{ // pas de adsize choisis
//				$activite->setAdsizeId(0);
//			}
			// Id du repere ? partir du nom du repere
			$repereId = trim($contactEntrepriseAjouterForm['repereId']->getData());
			$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneByRepere($repereId);
			if(isset($repereObj))
			{
				$repere = $repereObj->getId();
				$activite->setRepereId($repere);
			}
			else // si aucun repere n'a ?t? choisis, l'id du repere = 0
			{
				$activite->setRepereId(0);	
			}
			// fin
			// Id de la rue ? partir du nom de la rue
			if($rueSaisie)
			{
				$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneByRue($rueSaisie );
				$rueId = $rueObj->getId();
				$activite->setRueId($rueId);
			}
			else // si aucun rue n'a ?t? choisis, l'id du repere = 0
			{
				$activite->setRueId(0);	
			}
			// Messages d'erreur de validation et contraintes suppl?mentaires du formlaire d'ajout modification d'activit?s 
			$validation = "";
			// Validation de la rubrique
			$data01 = $contactEntrepriseAjouterForm['rubriqueId']->getData(); // on verifie que le champ rubrique de la listbox a ?t? modifi? avant de persister
			$rubriqueformId = $contactEntrepriseAjouterForm['rubriqueId']->getData(); 
// echo $rubriqueformId;
			if($rubriqueformId == 0) // la rubrique n'a pas bien ?t? chang?e
			{
			    $validation = 1; // Veuillez selectionner une rubrique
			}
			// Validation du num?ro de telephone01
			$telephone01 = $contactEntrepriseAjouterForm['telephone01']->getData();
			     // nombre de caracteres du num?ro
			$telephone01_len = strlen($telephone01);
			if($telephone01_len < 6 || $telephone01_len > 16)
			{
			    $validation = 2; // Le num?ro T?l?phone01 est invalide
			}
           // Validation du num?ro de telephone02
			$telephone02 = $contactEntrepriseAjouterForm['telephone02']->getData();
			     // nombre de caracteres du num?ro
			$telephone02_len = strlen($telephone02);
			if($telephone02_len !=0 AND $telephone02_len < 6)
			{
			    $validation = 3; // Le num?ro T?l?phone02 est invalide
			}
           	// Validation du num?ro du fax
			$fax = $contactEntrepriseAjouterForm['fax']->getData();
			     // nombre de caracteres du num?ro
			$fax_len = strlen($fax);
			if($fax_len!=0 AND $fax_len < 6)
			{
			    $validation = 4; // Le num?ro Fax est invalide
			}
			// Validation du nom de l'activit?
			    // nombre de caracteres de l'activt?
			$entreprise = $contactEntrepriseAjouterForm['entreprise']->getData();
			$activite_len = strlen($entreprise);
			if($activite_len < 3)
			{
			    $validation = 5; // Le nom de l'activit? est invalide
			}
			// Validation du quartier
			$data02 = $contactEntrepriseAjouterForm['quartierId']->getData(); // on verifie que le champ rubrique a ?t? modifi? avant de persister
			$quartierformId = $data02->getId(); 
			if($quartierformId == 0) // la rubrique n'a pas bien ?t? chang?e
			{
			    $validation = 6; // Veuillez selectionner une rubrique
			}
			// Validation de l'unicit? de EntrepriseRubriqueRue
			// Collection de toutes Id les entreprises qui ont deja ce nom

			$entrepriseAInserer = trim($activite->getEntreprise());
			$entrepriseAInsererRubrique = trim($activite->getRubriqueId());
			$entrepriseAInsererRueId = trim($activite->getRueId());
			$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a 
											WHERE a.entreprise =:entrepriseAInserer AND a.rubriqueId =:entrepriseAInsererRubrique AND a.rueId =:entrepriseAInsererRueId AND a.rueId != 0') // si la rue existe, rueId != 0
                                           ->setParameters(array(
										   'entrepriseAInserer' => $entrepriseAInserer, 
										   'entrepriseAInsererRubrique' => $entrepriseAInsererRubrique, 
										   'entrepriseAInsererRueId' => $entrepriseAInsererRueId,));
			$entreprisesDejaObj = $query->getResult();
			if(sizeof($entreprisesDejaObj) > 0) // la rubrique n'a pas bien ?t? chang?e
			{
			    $validation = 7; // Veuillez selectionner une rubrique 
			}

			// validation des coordonnés de la map: on verifie le format (latitude:float,longitude:float)
			if($form_map)
			{
				$form_mapArray = explode(',',$form_map);
				//var_dump($form_mapArray);
				is_numeric(trim($form_mapArray[0]))?($validation = $validation):($validation = 8); // latitude incorect
				is_numeric(trim($form_mapArray[1]))?($validation = $validation):($validation = 9); // longitude incorect
			}
			else
			{
				$form_map = "0,0";
			}
			// Validation de l'email
			$data10 = $contactEntrepriseAjouterForm['email']->getData(); // 
			if(!filter_var($data10, FILTER_VALIDATE_EMAIL)) // l'email
			{
			    $validation = 10;  
			}
			// fin validation de l'email


			// Fin des messages de validations ///
           
		    ///////////// validations ///
			if($validation == "") // Tout va bien
			{
				//var_dump($activite);
				//// on upload les fichiers et on persist la base de donn?e avec les infos du formulaire de modif ou d'ajout
				$file01 = $activite->getPath01();
				$file02 = $activite->getPath02();
				$file03 = $activite->getPath03();
				
				$photo = "no";
				$video = "no";
				$logo  = "no";
				
				if($file01){
					$path01 = $this->get('app.file_uploader')->upload($file01);				
					$activite->setPath01($path01);
					$photo = $path01; // pour le mail à l'admin
				}
				if($file02){
					$path02 = $this->get('app.file_uploader')->upload($file02);				
					$activite->setPath02($path02);
					$video = $path02; // pour le mail à l'admin
				}
				if($file03){
					$path03 = $this->get('app.file_uploader')->upload($file03);				
					$activite->setPath03($path03);
					$logo = $path03; // pour le mail à l'admin
				}

				$em->persist($activite); 
				$em->flush();

				// fin url
				$nom   = ucfirst($activite->getEntreprise());
				$email = $activite->getEmail();
				if($email == "")
				{
					$email = "inconu";
				}
				$contact=$activite->getContact();
				if($contact == "")
				{
					$contact = "Inconu";
				}
				// formulaire de prestation de la page d'enregistrement Ok
					// langue en cours:
				$language = new Languagefromurl;
				$translate = new Translate;
				
				$langueId = $language->getLanguage();
				$translatedPrestation = $translate->getTableTranslation(3, $langueId); // 3 is the id of the table Prestation
				// reindexation before sending to view
				$prestation = array();

				foreach($translatedPrestation as $key=>$value){
					if($value){
						$v = html_entity_decode(htmlentities($value, 0, 'UTF-8'));
						array_push($prestation, ucfirst($v));
					}
				}

				$message_new = "";
				// le formulaire de prestation a ete envoy?
				$type   = "ajout";
				$action = "Ajout";
				// medias: ces variables sont requise dans le fichier ajax d'envoie du mail. elles sont vide pour un ajout car seront flushé et accessibles dans la bd

				// Send Ajout mail
				$type = "ajout";
				$visitoremail = $email;
				$dzoomreceveur = "registration@doualazoom.com";
				// sitename, email, pays...
				$siteData = $this->getLocale();
// var_dump($siteData);
				$sender = new Sendmail($this->get('templating'), $this->get('mailer'));
				$sender->send($siteData, $visitoremail, $dzoomreceveur, $nom, $entreprise, $form_datas, $type, $photo, $video, $logo, $this->get('translator'));
				
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseOk.html.twig', array(
					'prestation'  => $prestation,
					'message_new' => $message_new,
					'nom'         => $nom,
					'email'       => $email,
					'contact'     => $contact,
					'entreprise'  => $entreprise,
					'form_datas'  => $form_datas,
					'action'      => $action,
					'type'        => $type,
					'photo'       => $photo,
					'video'       => $video,
					'logo'        => $logo,

				));
			}
			// validations
			// $translator = $this->get('translator');
			// echo 
			else if($validation == 1) // rubrique requise
			{
				$message = $translator->trans('please choose an activity sector');
				$dateError = new FormError($message); 
				$contactEntrepriseAjouterForm->get('rubriqueId')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 2) // Téléphone01  est invalide
			{
				    $message = $translator->trans('phone number 01 is invalid');
				    $dateError = new FormError($message); 
					$contactEntrepriseAjouterForm->get('telephone01')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 3) // T?l?phone02  est invalide
			{
				    $message = $translator->trans('phone number 02 is invalid');
				    $dateError = new FormError($message); 
					$contactEntrepriseAjouterForm->get('telephone02')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 4) // Fax est invalide
			{
				    $message = $translator->trans('fax number is invalid');
				    $dateError = new FormError($message);
					$contactEntrepriseAjouterForm->get('fax')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 5) // Nom de l'entreprise incorrect
			{
				    $message = $translator->trans('the company name must be at least 3 characters long');
				    $dateError = new FormError($message);
					$contactEntrepriseAjouterForm->get('entreprise')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 6) // quartier requis
			{
				    $message =  $translator->trans('Select a district please');
				    $dateError = new FormError($message);
					$contactEntrepriseAjouterForm->get('quartierId')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 7)
			{
				    $message = $translator->trans('this company already exists in the selected street').$nomRue;
				    $dateError = new FormError($message); // entreprise deja exitante
					$contactEntrepriseAjouterForm->get('entreprise')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 8)
			{ 		
				    $message = $translator->trans('invalid latitude value');
				    $dateError = new FormError($message); // latitude non valide
					$contactEntrepriseAjouterForm->get('map')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 9)
			{
				    $message =  $translator->trans('invalid longitude value');
				    $dateError = new FormError($message); // longitude non valide
					$contactEntrepriseAjouterForm->get('map')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
			else if ($validation == 10)			
			{
				    $message = $translator->trans('please enter an email address');
				    $dateError = new FormError($message); // 
					$contactEntrepriseAjouterForm->get('email')->addError($dateError);
					return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
			}
		}
		else
		{
			//affichage du formulaire d'ajout d'une entreprise
			return $this->render('ZoomDoualaBundle:Show:contactEntrepriseAjouter.html.twig', array('contactEntrepriseAjouterForm' => $contactEntrepriseAjouterForm->createView()));
		}
	}
	
	// Page de modification d'une entreprise
	function contactEntrepriseModifierAction(Request $request, $selected, $id)
	{	
		$entreprise = $selected;
		$translator = $this->get('translator');
		if(!isset($_COOKIE['nomEntreprise'])){
			return $this->redirect($this->generateUrl('zoom_douala_zoom_contactEntrepriseIntro'));
		}
		
		$contactEntrepriseModifierObj = new contactEntrepriseModifierForm(); // 
		$em = $this->getDoctrine()->getManager();
		$activite = $em->getRepository('ZoomDoualaBundle:Activite')->findOneBy(array('entreprise'=>$selected, 'id'=>$id));
		//var_dump($activite);
		// Ids to names
		// rubriqueId to rubrique
		
 		$rubriqueId = $activite->getRubriqueId(); 
		// patch pour Gandi qui ne voit pas l'index Id = 0 
		if($rubriqueId != 0){
			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
			// var_dump($rubriqueObj);
			$rubrique = ucfirst(strtolower($rubriqueObj->getRubrique()));
			//echo $rue;
		}
		else{
			$rubrique = "";
		}
		// fin patch pour Gandi qui ne voit pas l'index Id = 0 
		$activite->setRubriqueId($rubrique);
		// rueId to rue
		$rueId = $activite->getRueId(); 
		// patch pour Gandi qui ne voit pas l'index Id = 0 
		if($rueId != 0)	{
			$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
			// var_dump($rueObj);
			$rue = ucfirst(strtolower($rueObj->getRue()));
			//echo $rue;
		}
		else{
			$rue = "";
		}
		// fin patch pour Gandi qui ne voit pas l'index Id = 0 
		$activite->setRueId($rue);
		//
		// quartierId to quartier
		$quartierId = $activite->getQuartierId();
		// patch pour Gandi qui ne voit pas l'index Id = 0 
		if($quartierId != 0){
			$quartierObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
			// var_dump($quartierObj);
			$quartier = ucfirst(strtolower($quartierObj->getQuartier()));
			//echo $quartier;
		}
		else{
			$quartier = "";
		}
		$activite->setQuartierId($quartier);

		// fin patch pour Gandi qui ne voit pas l'index Id = 0 
		// repereId to repere
		$repereId = $activite->getRepereId();
		// patch pour Gandi qui ne voit pas l'index Id = 0 
		if($repereId != 0){
			$repereObj = $em->getRepository('ZoomDoualaBundle:Repere')->findOneById($repereId);
			// var_dump($repereObj);
			$repere = ucfirst(strtolower($repereObj->getRepere()));
				//echo $repere;
		}
		else{
			$repere = "";
		}
		// fin patch pour Gandi qui ne voit pas l'index Id = 0 
		$activite->setRepereId($repere);
		//
		// functionId to function
		$fonctionId = $activite->getFonctionId();
		// patch pour Gandi qui ne voit pas l'index Id = 0 
		if($fonctionId != 0){
			$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);
			// var_dump($fonctionObj);
			$fonction = ucfirst(strtolower($fonctionObj->getFonction()));
			//echo $fonction;
		}
		else{
			$fonction = "";
		}
		// fin patch pour Gandi qui ne voit pas l'index Id = 0 
		$activite->setFonctionId($fonction);
		//
		// adsizeId to adsize
//			$adsizeId =  trim($activite->getAdsizeId());
//			// patch pour Gandi qui ne voit pas l'index Id = 0
//			if($adsizeId != 0)
//			{
//				$adsizeObj = $em->getRepository('ZoomDoualaBundle:Adsize')->findOneById($adsizeId);
//				// var_dump($AdsizeObj);
//				$adsize = $adsizeObj->getAdsize();
//				//echo $adsize;
//			}
//			else
//			{
//				$adsize = "Aucune";
//			}
		// fin patch pour Gandi qui ne voit pas l'index Id = 0
//		$activite->setAdsizeId($adsize);
		$contactEntrepriseModifierForm = $this->createForm(contactEntrepriseModifierForm::class, $activite );
		$contactEntrepriseModifierForm->handleRequest($request);
		if ($contactEntrepriseModifierForm->isValid()){  // formulaire POST
		//  Prestation list to display in the current local on the thank you page
			// langue en cours:
			$language = new Languagefromurl;
			$translate = new Translate;
			$langueId = $language->getLanguage();
			$translatedPrestation = $translate->getTableTranslation(3, $langueId); // 3 is the id of the table Prestation
			// reindexation before sending to view
			$prestation = array();
			$i = 0;
			foreach($translatedPrestation as $key=>$value){
					if($value){
						$v = html_entity_decode(htmlentities($value, 0, 'UTF-8'));
						array_push($prestation, ucfirst($v));
					}
			} 

			$message_new = 'Les modifications de l\'entreprise "'.$entreprise. '" ont bien &eacute;t&eacute; enregistr&eacute;es.<br><br>Nous vous contacterons bient&ocirc;t pour la v&eacute;rification de vos donn&eacute;es et l\'activation de votre page dans l\'annuaire DoualaZoom.com.';
			$contact = $contactEntrepriseModifierForm['contact']->getData();
			$email = $contactEntrepriseModifierForm['email']->getData();
			$nom = $entreprise;
			// farication de la chaine des donn?es du formulaire ? envoyer par mail
			$form_entreprise = $contactEntrepriseModifierForm['entreprise']->getData();
			// rubrique
			$datas = $contactEntrepriseModifierForm->getData();
			$rubriqueId = $datas->getRubriqueId();
// echo 'rubriqueId:'.$rubriqueId;
			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubriqueId);
			$form_rubrique = $rubriqueObj->getRubrique();
			// bp
			$form_bp = $contactEntrepriseModifierForm['bp']->getData();
			$form_telephone01 = $contactEntrepriseModifierForm['telephone01']->getData();
			$form_telephone02 = $contactEntrepriseModifierForm['telephone02']->getData();
			$form_fax = $contactEntrepriseModifierForm['fax']->getData();
			$form_contact = $contactEntrepriseModifierForm['contact']->getData();
			// fonction
			$fonctionId = $datas->getFonctionId();
			$form_fonction = "aucune";
			if($fonctionId){
				$fonctionObj = $em->getRepository('ZoomDoualaBundle:Fonction')->findOneById($fonctionId);
				$form_fonction = $fonctionObj->getFonction();
			}
			// ville
			$form_ville = $contactEntrepriseModifierForm['villeId']->getData();
			$form_quartier = $contactEntrepriseModifierForm['quartierId']->getData();
			$form_repere = $contactEntrepriseModifierForm['repereId']->getData();
			// traitement de details
			$form_details = str_replace("'"," ",$contactEntrepriseModifierForm['place']->getData());
			$form_map = $contactEntrepriseModifierForm['map']->getData();
			$form_email = $contactEntrepriseModifierForm['email']->getData();
			$form_rue = $contactEntrepriseModifierForm['rueId']->getData();
			$form_web = $contactEntrepriseModifierForm['web']->getData();
			// traitement de l'adresse web et des slash
			$form_web = str_replace("http://","",$form_web);
			// traitement de AdSize et ses apostrophes
			$form_adsize =  str_replace("'","",$contactEntrepriseModifierForm['adsizeId']->getData());
			// traitement de Alaune et ses apostrophes
			$form_alaune =  str_replace("'","",$contactEntrepriseModifierForm['alaune']->getData());
			// Clean up these input values
			if(ini_get('magic_quotes_gpc')){
				//contact
				$form_contact = stripslashes($form_contact);
				$form_contact = htmlspecialchars(strip_tags($form_contact));
			}
			// la chaine de variable à envoyer dans le mail
			$form_datas = "Entreprise: ".$form_entreprise." - "."Rubrique: ".$form_rubrique." - "."Bp: ".$form_bp." - "."telephone01: ".$form_telephone01." - "."telephone02: ".$form_telephone02." - "."fax: ".$form_fax." - "."contact: ".$form_contact." - "."fonction: ".$form_fonction." - "."ville: ".$form_ville." - "."quartier: ".$form_quartier." - "."repere: ".$form_repere." - "."details: ".$form_details." - "."map: ".$form_map." - "."email: ".$form_email." - "."web: ".$form_web." - "."rue: ".$form_rue." - "."Nombre de mois Represantant de sa rubrique: "." - ".$form_adsize." - Nombre de mois A la une: ".$form_alaune;
			//echo "Entreprise:".$entreprise;
			$action = "Modification";
			$type = "modification"; 
			//validations
			///////////////// Messages d'erreur de validation et contraintes suppl?mentaires du formlaire d'ajout modification d'activit?s /////
			$validation = "";
			// Validation de la rubrique
//			$data01 = $contactEntrepriseModifierForm['rubriqueId']->getData(); // on verifie que le champ rubrique de la listbox a ?t? modifi? avant de persister
			$rubriqueformId = $contactEntrepriseModifierForm['rubriqueId']->getData();
			if($rubriqueformId == 0){ // la rubrique n'a pas bien ?t? chang?e
			
				$validation = 1; // Veuillez selectionner une rubrique
			}
			// Validation du num?ro de telephone01
			$telephone01 = $form_telephone01;
		     // nombre de caracteres du num?ro
			$telephone01_len = strlen($telephone01);
			if($telephone01_len < 6 || $telephone01_len > 16){
				$validation = 2; // Le num?ro T?l?phone01 est invalide
			}
			// Validation du num?ro de telephone02
			$telephone02 = $form_telephone01;
		     // nombre de caracteres du num?ro
			$telephone02_len = strlen($telephone02);
			if($telephone02_len !=0 AND $telephone02_len < 6){
				$validation = 3; // Le num?ro T?l?phone02 est invalide
			}
			// Validation du num?ro du fax
			$fax = $form_fax;
		     // nombre de caracteres du num?ro
			$fax_len = strlen($fax);
			if($fax_len!=0 AND $fax_len < 6){
				$validation = 4; // Le num?ro Fax est invalide
			}
			// Validation du nom de l'activit?
		    // nombre de caracteres de l'activt?
			$entreprise = $form_entreprise;
			$activite_len = strlen($entreprise);
			if($activite_len < 3){
				$validation = 5; // Le nom de l'activit? est invalide
			}
			// Validation du quartier
			$data02 = $form_quartier; // on verifie que le champ rubrique a ?t? modifi? avant de ersister
			$quartierformId = $data02->getId(); 
			if($quartierformId == 0){ // la rubrique n'a pas bien ?t? chang?e
				$validation = 6; // Veuillez selectionner une rubrique
			}
			// Validation de l'unicit? de EntrepriseRubriqueRue
			// Collection de toutes Id les entreprises qui ont deja ce nom
			$entrepriseAInserer = trim($form_entreprise);
			$entrepriseAInsererRubrique = trim($activite->getRubriqueId());
			$entrepriseAInsererRueId = trim($activite->getRueId());
			$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a 
											WHERE a.entreprise =:entrepriseAInserer AND a.rubriqueId =:entrepriseAInsererRubrique AND a.rueId =:entrepriseAInsererRueId AND a.rueId != 0') // si la rue existe, rueId != 0
                                           ->setParameters(array(
										   'entrepriseAInserer' => $entrepriseAInserer, 
										   'entrepriseAInsererRubrique' => $entrepriseAInsererRubrique, 
										   'entrepriseAInsererRueId' => $entrepriseAInsererRueId,));
			$entreprisesDejaObj = $query->getResult();
			if(sizeof($entreprisesDejaObj) > 0){ // la rubrique n'a pas bien ?t? chang?e
			
				$validation = 7; // Veuillez selectionner une rubrique 
			}
			// validation des coordonnés de la map: on verifie le format (latitude:float,longitude:float)
			if($form_map){
				$form_mapArray = explode(',',$form_map);
				//var_dump($form_mapArray);
				is_numeric(trim($form_mapArray[0]))?($validation = $validation):($validation = 8); // latitude incorect
				is_numeric(trim($form_mapArray[1]))?($validation = $validation):($validation = 9); // longitude incorect
			}
			else{
					$form_map = "0,0";
			}
			// fin validation des coordonnés de la map
			// Validation de l'email
			$data10 = $contactEntrepriseModifierForm['email']->getData(); //
			if(!filter_var($data10, FILTER_VALIDATE_EMAIL)){ // l'email
				$validation = 10;  
			}
			///////////// Fin des messages de validations ///
			///////////// validations ///
			if($validation == ""){ // Tout va bien
				// Send Modification mail
				$visitoremail = $email;
				$dzoomreceveur = "registration@doualazoom.com";
				
				// traitement des medias
				$photo = "no";
				$video = "no";
				$logo  = "no";
				$path01 = null;
				$path02 = null;
				$path03 = null;
				
				$file01 = $activite->getPath01();
				$file02 = $activite->getPath02();
				$file03 = $activite->getPath03();

				if($file01){
					$path01 = $this->get('app.file_uploader')->upload($file01);				
					$activite->setPath01($path01);
					$photo = $path01; // pour le mail à l'admin
				}
				if($file02){
					$path02 = $this->get('app.file_uploader')->upload($file02);				
					$activite->setPath02($path02);
					$video = $path02; // pour le mail à l'admin
				}
				if($file03){
					$path03 = $this->get('app.file_uploader')->upload($file03);				
					$activite->setPath03($path03);
					$logo = $path03; // pour le mail à l'admin
				}
				
				//		
				$nom = $selected;
				
				// sitename, email, pays...
				$siteData = $this->getLocale();

				$sender = new Sendmail($this->get('templating'), $this->get('mailer'));
				$sender->send($siteData, $visitoremail, $dzoomreceveur, $nom, $entreprise, $form_datas, $type, $photo, $video, $logo, $this->get('translator'));
				//
				
				
				
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseOk.html.twig', array(
					'prestation'  => $prestation,
					'message_new' => $message_new,
					'nom'         => $nom,
					'email'       => $email,
					'contact'     => $contact,
					'entreprise'  => $entreprise,
					'form_datas'  => $form_datas,
					'action'      => $action,
					'type'        => $type,
					'photo'       => $path01,
					'video'       => $path02,
					'logo'        => $path03,
					)
				);
			}
			else if($validation == 1){ // rubrique requise
				$message = $translator->trans('please choose an activity sector');
				$dateError = new FormError($message); 
				$contactEntrepriseModifierForm->get('rubriqueId')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', 		array(
						'selected'=>$selected,
						'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
						)
				);
			}
			else if ($validation == 2){ // T?l?phone01  est invalide
				$message = $translator->trans('phone number 01 is invalid');
				$dateError = new FormError($message); 
				$contactEntrepriseModifierForm->get('telephone01')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', 		array(
						'selected'=>$selected,
						'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
					));
			}
			else if ($validation == 3){ // T?l?phone02  est invalide
			    $message = $translator->trans('phone number 02 is invalid');
			    $dateError = new FormError($message); 
				$contactEntrepriseModifierForm->get('telephone02')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
					'selected'=>$selected,
					'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
					));
			}
			else if ($validation == 4){ // Fax est invalide
			    $message = $translator->trans('phone number fax is invalid');
			    $dateError = new FormError($message);
				$contactEntrepriseModifierForm->get('fax')->addError($dateError);
							return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
							'selected'=>$selected,
							'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
					));
			}
			else if ($validation == 5){ // Nom de l'entreprise incorrect
			    $message = $translator->trans('the company name must be at least 3 characters long');
			    $dateError = new FormError($message);
				$contactEntrepriseModifierForm->get('entreprise')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
					'selected'=>$selected,
					'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
					));
			}
			else if ($validation == 6){ // quartier non requis
			    $message = "Choisissez un quartier";
			    $dateError = new FormError($message);
				$contactEntrepriseModifierForm->get('quartierId')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
					'selected'=>$selected,
					'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
					));
			}
			else if ($validation == 7){
			    $message = $translator->trans('this company already exists in the street').$nomRue;
			    $dateError = new FormError($message); // entreprise deja exitante
				$contactEntrepriseModifierForm->get('entreprise')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
					'selected'=>$selected,
					'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
					));
			}
			else if ($validation == 8){
			    $message = $translator->trans('invalid latitude value');
			    $dateError = new FormError($message); // latitude non valide
				$contactEntrepriseModifierForm->get('map')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
					'selected'=>$selected,
					'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
					));
			}
			else if ($validation == 9){
				$message = $translator->trans('invalid longitude value');
				$dateError = new FormError($message); // longitude non valide
				$contactEntrepriseModifierForm->get('map')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
					'selected'=>$selected,
					'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(), 
					));
			}
			else if ($validation == 10){		
				$message = $translator->trans('please enter an email address');
				$dateError = new FormError($message); // 
				$contactEntrepriseModifierForm->get('email')->addError($dateError);
				return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
				'selected'=>$selected,
				'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView(),
				));
			}
		}
		//fin validations
		else{
			//affichage du formulaire de modification d'une entreprise
			return $this->render('ZoomDoualaBundle:Show:contactEntrepriseModifier.html.twig', array(
				'selected'=>$selected,
				'contactEntrepriseModifierForm' => $contactEntrepriseModifierForm->createView()));
		}
	}

	
	// page pays, description du pays du zoom
	function showPaysAction()
	{
		$em = $this->getDoctrine()->getManager();
		// get ville
		$localObj = $em->createQuery('SELECT a.ville, a.pays
									  FROM ZoomDoualaBundle:Locale a')
									  ->setMaxResults(1);
		$local = $localObj->getResult();
		$ville = $local[0]['ville'];
		$pays  = $local[0]['pays'];
		//
		$em = $this->getDoctrine()->getManager();
		$page = "pays";
		$contentObj = $em->getRepository('ZoomDoualaBundle:Content')->findOneByPage($page);
		$content    = $contentObj->getContent();
		$contentId  = $contentObj->getId();
		// traduction avant affichage
		$language   = new Languagefromurl;
		$translate  = new Translate;
		$langueId   = $language->getLanguage(); // get current language id
		
		$translatedContent = $translate->getOneTranslation( 5, $contentId, $langueId ); // getOneTranslation($tableid, $wordid, $languageid)
		if( $translatedContent ){
			$content = $translatedContent;
		}
//		var_dump($translatedContent);
		return $this->render('ZoomDoualaBundle:Show:paysShow.html.twig', array(
																		 'content' => $content,
																		 'ville'   => $ville,
																		 'pays'    => $pays,
																		)
					        );
	}
	
	// ville, description de la ville du zoom
	function showVilleAction()
	{
		$em = $this->getDoctrine()->getManager();
		// get ville
		$localObj = $em->createQuery('SELECT a.ville, a.pays
									  FROM ZoomDoualaBundle:Locale a')
									  ->setMaxResults(1);
		$local = $localObj->getResult();
		$ville = $local[0]['ville'];
		$pays  = $local[0]['pays'];
		//
		$em = $this->getDoctrine()->getManager();
		$page = "ville";
		$contentObj = $em->getRepository('ZoomDoualaBundle:Content')->findOneByPage($page);
		$content    = $contentObj->getContent();
		$contentId  = $contentObj->getId();
		// traduction avant affichage
		$language   = new Languagefromurl;
		$translate  = new Translate;
		$langueId   = $language->getLanguage(); // get current language id
		
		$translatedContent = $translate->getOneTranslation( 5, $contentId, $langueId ); // getOneTranslation($tableid, $wordid, $languageid)
		if( $translatedContent ){
			$content = $translatedContent;
		}
//		var_dump($translatedContent);
		return $this->render('ZoomDoualaBundle:Show:villeShow.html.twig', array(
																		 'content' => $content,
																		 'ville'   => $ville,
																		 'pays'    => $pays,
																		)
					        );
	}

	
	// render de la pub sur les pages de list
	function pubListsAction()
	{
		return $this->render('ZoomDoualaBundle:Show:pubLists.html.twig');
	}

	function pubShowsAction()
	{
		return $this->render('ZoomDoualaBundle:Show:pubShows.html.twig');
	}

	// envoie du mail de contact redu sur les layout
	public function mailLayoutContactAction($visitoremail, $dzoomemail, $dzoomreceveur, $message, $nom, $entreprise, $local) 
    {
		// traductions
		// set mail subject and ajax message cuz we cannot get local when running this controller on the background
		if( $local == "fr" ){
			$subject   = "Merci, nous vous contacterons par email";
			$content01 = "Nous avons reçu votre message à";
			$content02 = "Nous vous répondrons bientôt";
			$content03 = "Cordialement";
			$hello     = "Bonjour";
			$ajaxmsg   = "Merci, nous vous contacterons par email";
		}
		if( $local == "en" ){
			$subject   = "Thank you, we will contact you by email";
			$content01 = "We have received your message to";
			$content02 = "We will answer you soon";
			$content03 = "Regards";
			$hello     = "Hello";
			$ajaxmsg   = "Thank you, we will contact you by email";
		}
		if( $local == "es" ){
			$subject   = "Gracias, nos pondremos en contacto con usted por correo electrónico";
			$content01 = "Hemos recibido su solicitud de cotización en DoualaZoom.com";
			$content02 = "Hemos recibido su mensaje para";
			$content03 = "Saludos";
			$hello     = "Hola";
			$ajaxmsg   = "Gracias, nos pondremos en contacto con usted por correo electrónico";
		}
		if( $local == "cn" ){
			$subject   = "谢谢，我们会通过电子邮件与您联系";
			$content01 = "我们已收到您的留言";
			$content02 = "我们会尽快回答你";
			$content03 = "问候";
			$hello     = "你好";
			$ajaxmsg   = "谢谢，我们会通过电子邮件与您联系";
		}
		if( $local == "ar" ){
			$subject   = "شكرا لك ، سوف نتصل بك عن طريق البريد الإلكتروني";
			$content01 = "لقد استلمنا رسالتك";
			$content02 = "سنقوم بالرد عليك قريبا";
			$content03 = "مع تحياتي";
			$hello     = "مرحبا";
			$ajaxmsg   = "شكرا لك ، سوف نتصل بك عن طريق البريد الإلكتروني";
		}

		// sitename, email, pays...
		$siteData = $this->getLocale();
	    // get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];

		//le mail aux administrateurs
		 try 
		 {
			$messageText = $message;
			$from_name   = "DoualaZoom.com";
			$from_email  = "info@doualazoom.com";
			$from = array($from_email => $from_name);
			$to01 = $dzoomreceveur;
			$to02 = "courrier@abidjanzoom.com";
			$to   = array($to01, $to02);
			$message = \Swift_Message::newInstance()
            ->setSubject($subject)
            ->setFrom($from)
            ->setTo($to)
            ->setBody($this->renderView('ZoomDoualaBundle:Show:mailLayoutContact.txt.twig', array
												(
													'nom' 		   => $nom, 
													'message'	   => $messageText, 
													'entreprise'   => $entreprise,
													'sitetitle'    => $sitetitle,
													'siteurl'      => $siteurl,
													'sitename'     => $sitename,
													'visitoremail' => $visitoremail)) , 'text/html'
			);
			$send01 = $this->get('mailer')->send($message, $errors); // envoie du mail des l'admin
			
			// retour pour ajax au visiteur alertbox
			echo $ajaxmsg; 
		}
		catch (\Swift_TransportException $STe)
		{
		 	 $string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
			 echo "\n";
			 echo "send mail to info@doualazoom.com exeption: $string \n";
		}
		
		// le mail d'accusé de reception du message du visiteur 
		 try 
		 {
			$from_name = "DoualaZoom.com";
			$from_email = "info@doualazoom.com";
			$from = array($from_email => $from_name);
			$to01 = $visitoremail;
// $to02 = "courrier@abidjanzoom.com";
			$to = array($to01);
			$message = \Swift_Message::newInstance()
            ->setSubject($subject)
            ->setFrom($from)
            ->setTo($to)
            ->setBody( $this->renderView('ZoomDoualaBundle:Show:mailLayoutContactResponse.txt.twig', array
													(
													 'nom'          => $nom, 
													 'entreprise'   => $entreprise, 
													 'content01'    => $content01, 
													 'content02'    => $content02, 
													 'content03'    => $content03,
													 'sitetitle'    => $sitetitle,
													 'siteurl'      => $siteurl,
													 'sitename'     => $sitename,												 
													 'visitoremail' => $visitoremail
													)
										) , 'text/html'
					);
			$send01 = $this->get('mailer')->send($message, $errors); // envoie du mail des l'admin
		}
		catch (\Swift_TransportException $STe)
		{
		 	 $string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
			 echo "\n";
			 echo "send mail to info@doualazoom.com exeption: $string \n";
		}
// echo "merci, nous vous contacterons par mail.";
// echo "Sent to: $send \n";
// echo "Failures:"; 
// print_r($failures);
// var_dump($message);
// echo $message;
// echo "visitoremail: {$visitoremail} ,  dzoomemail {$dzoomemail} , dzoomreceveur {$dzoomreceveur} , message {$message}, nom {$nom} , entreprise {$entreprise}";
		return new Response();
	}

	// envoie du mail d'erreur du formulaire redu sur les layout
	public function mailLayoutErrorAction($visitoremail, $dzoomemail, $dzoomreceveur, $message, $nom, $lien, $local) 
    {	
		// sitename, email, pays...
		$siteData = $this->getLocale();
	    // get site data values for email.txt.twig
		$sitetitle = $siteData['title'];
		$siteurl   = $siteData['url'];
		$sitename  = $siteData['name'];
		
		// traductions
		// set mail subject and ajax message cuz we cannot get local when running this controller on the background
		if( $local == "fr" ){
			$subject   = "Nous avons reçu votre notification d'erreur";
			$content01 = "Nous avons reçu votre notification d'erreur sur la page";
			$content02 = "Merci";
			$content03 = "Cordialement";
			$hello     = "Bonjour";
			$ajaxmsg   = "Merci, nous vous contacterons par email";
		}
		if( $local == "en" ){
			$subject   = "We have received your error notification";
			$content01 = "We have received your error notification on the page";
			$content02 = "Thank you";
			$content03 = "Regards";
			$hello     = "Hello";
			$ajaxmsg   = "Thank you, we will contact you by email";
		}
		if( $local == "es" ){
			$subject   = "Hemos recibido su notificación de error";
			$content01 = "Hemos recibido su notificación de error en la página";
			$content02 = "Gracias";
			$content03 = "Saludos";
			$hello     = "Hola";
			$ajaxmsg   = "Gracias, nos pondremos en contacto con usted por correo electrónico";
		}
		if( $local == "cn" ){
			$subject   = "我们已收到您的错误通知";
			$content01 = "我们已在页面上收到您的错误通知";
			$content02 = "谢谢";
			$content03 = "问候";
			$hello     = "你好";
			$ajaxmsg   = "谢谢，我们会通过电子邮件与您联系";
		}
		if( $local == "ar" ){
			$subject   = "لقد تلقينا إشعارًا بالخطأ";
			$content01 = "لقد تلقينا إشعار الخطأ الخاص بك على الصفحة";
			$content02 = "شكرا لكم";
			$content03 = "مع تحياتي";
			$hello     = "مرحبا";
			$ajaxmsg   = "شكرا لك ، سوف نتصل بك عن طريق البريد الإلكتروني";
		}

		// sitename, email, pays...
		$siteData = $this->getLocale();

		//le mail d'erreur envoyé aux administrateurs
		 try 
		 {
		 	$lien = str_replace('*','/', $lien);
			$messageText = $message;
			$from_name = "DoualaZoom.com";
			$from_email = "info@doualazoom.com";
			$from = array($from_email => $from_name);
			$to01 = $dzoomreceveur;
			$to02 = "courrier@abidjanzoom.com";
			$to = array($to01, $to02);
			$message = \Swift_Message::newInstance()
            ->setSubject($subject)
            ->setFrom($from)
            ->setTo($to)
            ->setBody($this->renderView('ZoomDoualaBundle:Show:mailLayoutError.txt.twig', array
													(
														'nom' 		   => $nom, 
														'message'	   => $messageText, 
														'lien'		   => $lien, 
														'visitoremail' => $visitoremail,
														'sitetitle'    => $sitetitle,
														'siteurl'      => $siteurl,
														'sitename'     => $sitename,
													)
										) , 'text/html'
						);
			$send01 = $this->get('mailer')->send($message, $errors); // envoie du mail des l'admin
			// retour pour ajax au visiteur alertbox
			echo $ajaxmsg; 	
		}
		catch (\Swift_TransportException $STe)
		{
		 	 $string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
			 echo "\n";
			 echo "send mail exeption: $string \n";
		}
		// le mail envoyé au visiteur d'accusé de reception du message d'erreur signalé
		try 
		{	
			$from_name = "DoualaZoom.com";
		//	$from_email = $dzoomemail;
			$from_email = "info@doualazoom.com";
			$from = array($from_email => $from_name);
			$to01 = $visitoremail;
			$to = array($to01);
			$message = \Swift_Message::newInstance()
            ->setSubject($subject)
            ->setFrom($from)
            ->setTo($to)
            ->setBody($this->renderView('ZoomDoualaBundle:Show:mailLayoutErrorResponse.txt.twig', array
											(
												'nom'		   => $nom, 
												'lien'		   => $lien, 
												'visitoremail' => $visitoremail,
												'content01'    => $content01,
												'content02'    => $content02,
												'content03'    => $content03,
												'hello'        => $hello,
												'siteData'     => $siteData,
											)
										), 'text/html'
			);
			$send01 = $this->get('mailer')->send($message, $errors); // envoie du mail des l'admin
		}
		catch (\Swift_TransportException $STe)
		{
		 	 $string = date("Y-m-d H:i:s")  . ' - ' . $STe->getMessage() . PHP_EOL;
			 echo "\n";
			 echo "send mail exeption: $string \n";
		}
		return new Response();
	}


	// note: the message to admin is not sent here but contactEntrepriseModifier or contactEntrepriseAjouter
	public function mailPrestationAction ($visitoremail, $dzoomemail, $dzoomreceveur, $nom, $entreprise, $prestation, $local) 
    {
		$translator = $this->get('translator');
        // envoie du mail
		$from_name = "DoualaZoom.com";
		$from_email = $dzoomemail;
		
		$from = array($from_email => $from_name);
		$to01 = $dzoomreceveur;
		$to02 = "courrier@abidjanzoom.com";
//		$to01 = "yaosoft@hotmail.com";
//		$to02 = "yaosoft@hotmail.com";

		// sitename, email, pays...
		$siteData = $this->getLocale();
	    // get site data values for email.txt.twig
		$sitetitle    = $siteData['title'];
		$siteurl  = $siteData['url'];
		$sitename = $siteData['name'];
		
		// mail à l'admin
		$to = array($to01, $to02);
        $message = \Swift_Message::newInstance()
            ->setSubject($nom.' '.$translator->trans('wants services on DoualaZoom.com'))
            ->setFrom($from)
            ->setTo($to)
            ->setBody($this->renderView('ZoomDoualaBundle:Show:mailPrestation.txt.twig', array
											(
												'nom' 			=> $nom, 
												'prestation'	=> $prestation, 
												'entreprise'	=> $entreprise,
												'sitetitle'        => $title,
												'siteurl'      => $siteurl,
												'sitename'     => $sitename,
												'visitoremail'  => $visitoremail
											)
										) , 
										'text/html');
		$this->get('mailer')->send($message); 

		// set mail subject and ajax message
		if( $local == "fr" ){
			$subject   = "Votre demande de prestations sur DoualaZoom.com";
			$content01 = "Nous avons bien reçu votre demande de prestation";
			$content02 = "Nous vous contacterons vite";
			$content03 = "Merci";
			$hello     = "Bonjour";
			$ajaxmsg   = "Merci! Nous vous enverrons un devis par mail";
		}
		if( $local == "en" ){
			$subject   = "Your request for quotation on DoualaZoom.com";
			$content01 = "We have received your request for a quotation on prestation";
			$content02 = "We will reply soon";
			$content03 = "Thanks";
			$hello     = "Hello";
			$ajaxmsg   = "Thanks! We will send you a quotation to your mailbox";
		}
		if( $local == "es" ){
			$subject   = "Su solicitud de servicios en DoualaZoom.com";
			$content01 = "Hemos recibido su solicitud de cotización en DoualaZoom.com";
			$content02 = "Responderemos pronto";
			$content03 = "Gracias";
			$hello     = "Hola";
			$ajaxmsg   = "¡Gracias! Le enviaremos una cotización a su correo";
		}
		if( $local == "cn" ){
			$subject   = "您对DoualaZoom.com的服务请求";
			$content01 = "我们已经注册了您的索赔 DoualaZoom.com";
			$content02 = "我们会尽快回复";
			$content03 = "谢谢";
			$hello     = "你好";
			$ajaxmsg   = "谢谢！ 我们会向您的邮箱发送报价";
		}
		if( $local == "ar" ){
			$subject   = "طلبك للحصول على الخدمات على DoualaZoom.com";
			$content01 = "لقد تلقينا طلبك للحصول على عرض أسعار على";
			$content02 = "سوف نقوم بالرد قريبا";
			$content03 = "شكر";
			$hello     = "مرحبا";
			$ajaxmsg   = "كر! سوف نرسل لك عرض أسعار لعلبة البريد الخاصة بك";
		}

		// message au visiteur
		$to = array($visitoremail);

		echo $ajaxmsg; // return message to ajax
		
		$message = \Swift_Message::newInstance() 
			->setSubject( $subject )
			->setFrom( $from )
			->setTo( $to )
			->setBody($this->renderView('ZoomDoualaBundle:Show:mailPrestationResponse.txt.twig', array
						(
							'nom'          => $nom, 
							'content01'    => $content01,
							'content02'    => $content02,
							'content03'    => $content03,
							'hello'        => $hello,
							'prestation'   => $prestation, 
							'entreprise'   => $entreprise,
							'sitetitle'    => $sitetitle,
							'siteurl'      => $siteurl,
							'sitename'     => $sitename,
							'visitoremail' => $visitoremail
						)
					) , 'text/html');
		$this->get('mailer')->send($message);

		return new Response();
	}
///////////////////// Pharmacies de garde //////////
	public function showPgardeAction(Request $request){   
		$locale = $request->getLocale();
		
		$em = $this->getDoctrine()->getManager();
		$activated = 'oui';
		$today = \date('Y-m-d');
//var_dump($today);
		$query = $em->createQuery('SELECT a.pgardeid, a.datefin FROM ZoomDoualaBundle:Pgarde a
								   WHERE a.datefin >=:today AND  a.datedebut <=:today ')
								   ->setParameters(array('today'=>$today)); 
		$pgardeObj = $query->getResult();
		if($pgardeObj){
			// table des pharmacies (objet Activite) à partir des pharmacies de gardes (objet Pgarde)
	    	$i = 0;
			foreach($pgardeObj as $value){
				$query = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Activite a WHERE a.id =:value')
									   ->setParameters(array('value'=>$value['pgardeid'])); 
				$activites[$i]['ids'] = $query->getResult(); // table des objets Activite (les pharmacies de garde)
				$activites[$i]['datefin'] = $value['datefin'];
				$i++;
			}
			$conteur = count($activites);
			$pagelimit = 25;
			// nombre d'entreprise à afficher / total paginé
			if($conteur < $pagelimit)
			{
				$toshow = $conteur;
			}
			else
			{
				$toshow = $pagelimit;
			}
			// changer le nom des pgardes en rempla?ant l'id par le nom de la pgarde et cr?ee le tableau des index alphabetique ? afficher
			$k = 0;
			$indexAlphaArray = array();
			$indexAlphaArray[0] = "";
			$lastinsertedId = 0;
			$i=0;
			for($i=0; $i<$conteur; $i++)
			{
				$index = $i;
				// on enleve les caracteres sp?ciaux dans le nom de l'activit?
				$entreprise = str_replace('/', '', $activites[$i]['ids'][0]->getEntreprise());
				$activites[$i]['ids'][0]->setEntreprise($entreprise);
				// changement de l'id du quartier  en nom du quartier
				$quartierId = $activites[$i]['ids'][0]->getQuartierId();
		    	$quartierObj =  $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartierId);
				$quartier = ucfirst(strtolower($quartierObj->getQuartier()));
				$lignesEntreprise[$index]["quartierId"] = $quartier;
				// changement de l'id de  la villeId en nom de ville
				$villeId = $activites[$i]['ids'][0]->getVilleId();
				$villeObj =  $em->getRepository('ZoomDoualaBundle:Ville')->findOneById($villeId);
				$ville = $villeObj->getVille();
				if($ville){
					$lignesEntreprise[$index]["villeId"] = $ville;
				}
				// changement de l'id de  la rueId en nom de la rue
				$rueId = $activites[$i]['ids'][0]->getRueId();
				// patch pour Gandi qui ne voit pas l'index Id = 0 
		   		 if($rueId != 0){
					$rueObj = $em->getRepository('ZoomDoualaBundle:Rue')->findOneById($rueId);
					// var_dump($rueObj);
					$rue = ucfirst(strtolower($rueObj->getRue()));
					//echo $rue;
				}
				else
				{
					$rue = "";
				}
				// fin patch pour Gandi qui ne voit pas l'index Id = 0 
				$lignesEntreprise[$index]["rueId"] = $rue;
				// logo par defaut
				$logo = $activites[$i]['ids'][0]->getPath03();
				if(!isset($logo))
				{
					$activites[$i]['ids'][0]->setPath03("default/logo".array_rand([1,2,3], 1).".gif");
				}
				else{
					$activites[$i]['ids'][0]->setPath03("../../../uploads/documents/".$logo);
				}
				// Affichage du bouton "Details" de cette quartier: est-ce qu'il ya des entreprises dans quartier
				if($conteur > 0)
				{
		    		$afficher_btn_details = 1;
				}
				else
				{
		    		$afficher_btn_details = "";
				}
				// tableau des index alphabetique des entrprises
				// l'index alphabetique de l'entreprise
				$alpha = ucfirst($entreprise[0]);
				$indexAlphaArray[$index] = $alpha; // array qui garde les valeurs des index alpha, pour comparaison
				if($index==0) // premiere insertion ou insetion diferente de la derni?re
				{
					$indexAlpha = $alpha;
					$indexAlphaArray[$index] =  $alpha; 
				}
				else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] != $indexAlphaArray[$lastinsertedId]))
				{
					$indexAlpha = $alpha;
				}
				else if(isset($lastinsertedId) AND ($indexAlphaArray[$index] == $indexAlphaArray[$lastinsertedId]))
				{
					$indexAlpha = "";
				}
				$lastinsertedId = $index;
				// Fabrication de l'array des lignes ? afficher
				$lignesEntreprise[$index]["alpha"] = $indexAlpha;
				$lignesEntreprise[$index]["entreprise"] = ucfirst(strtolower($activites[$i]['ids'][0]->getEntreprise()));
				$lignesEntreprise[$index]["telephone01"] = $activites[$i]['ids'][0]->getTelephone01();
				$lignesEntreprise[$index]["email"] = strtolower ($activites[$i]['ids'][0]->getEmail());
				$lignesEntreprise[$index]["description"] = $quartierObj->getDescription();
				$lignesEntreprise[$index]["path03"] = $activites[$i]['ids'][0]->getPath03(); //logo;
				$lignesEntreprise[$index]["button"] = $afficher_btn_details;
				$lignesEntreprise[$index]["nombre"] = $conteur;
				$lignesEntreprise[$index]["logo"] = $activites[$i]['ids'][0]->getPath03();
				$lignesEntreprise[$index]["id"] = $activites[$i]['ids'][0]->getId();
				// date de fin de la garde
				$lignesEntreprise[$index]["datefin"] = $activites[$i]['datefin'];
			}
			$pagelimit = 100; // limit de la pagination knp et alphabetique
			$pgardeChoisie = 'Pharmacie de garde';
			$paginator  = $this->get('knp_paginator');		   
	   	 	$pagination = $paginator->paginate($lignesEntreprise, $request->query->get('page', 1)/*page number*/, $pagelimit/*limit per page*/);
			
			// sitename, email, pays...
			$localData = $this->getLocale();
			return $this->render('ZoomDoualaBundle:Show:pgardeShow.html.twig', array
				(
					'pagination'      => $pagination, 
					'type'            => 'Pgarde', 
					'pgardeChoisie'   => $pgardeChoisie, 
					'indexAlpha'      => $indexAlphaArray, 
					'totalEntreprise' => $conteur, 
					'toshow'          => $toshow, 
					'today'           => $today,
					'localData'       => $localData
				)
			);
  		}
		else{
			return $this->render('ZoomDoualaBundle:Show:pgardeNullShow.html.twig');
		}
	}

///////////////////// end Liens utiles //////////

//////////////////// pubs //////////////////
	
	/** take the pud id and return an array of pubs to show**/

	public function pubAction($adtype){ //$adtype is the id of an ad type
		// A quelle nom correspond $adtype
		$em = $this->getDoctrine()->getManager();
		$adnamesarray = array(); // liste des categories d'ads
		$adsimagesarray = array(); // liste des images publicitaire de la categories

		$adstypeObj =  $em->getRepository('ZoomDoualaBundle:Adstype')->findOneById($adtype);

		$adname = $adstypeObj->getAdsname();
		$maxadstoanim = $adstypeObj->getMaxadstoanim(); // rq: maxadstoanim n'est plus utilisé
		$active   = 1;
		$status01 = 3;	//affichage en cours
		$status02 = 5; //affichage en cours et remplacement demande
		// création d'un array avec les images à afficher, selon le type de ad
		$adsObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Ads a 
	                           		WHERE (a.status   = :status01 OR  a.status = :status02)
									AND a.adtype = :adtype
									AND a.active = :active')
							   		->setParameters(array('adtype'    => $adtype,
														  'active'    => $active,
														  'status01'  => $status01,
														  'status02'  => $status02));
		$ads = $adsObj->getResult();

// set ads array images
		$j = 0;
		foreach($ads as $key => $value){
			$adsimagesarray[$j]['path']   =  $value->getPath();
			$adsimagesarray[$j]['client'] =  $value->getClient();
			$adsimagesarray[$j]['url']    =  $value->getUrl();
			$j++;
		}
		// ajout de la publicité zoom de l'espace publicitaire rq: maxadstoanim n'est plus utilisé
			$adsimagesarray[$j+1]['path']   =  "models/".$adname.".jpg";
			$adsimagesarray[$j+1]['client'] =  "DoualaZoom.com";
			$adsimagesarray[$j+1]['url']    =  "http://www.doualazoom.com/web/fr/store/showcase";
		//
		return $this->render('ZoomDoualaBundle:Show:/Ads/'.$adname.'.html.twig', array('adsimagesarray' => $adsimagesarray,) );
	}

/////// End Pubs /////////////////////////////////////////////////////

/////// Layout links ///////////////////////////////////////////////////
	public function layoutSidelinksMenuAction(){
		$siteData = $this->getLocale();
		return $this->render('ZoomDoualaBundle:Show:layoutSidelinksMenu.html.twig', array
								(
									'siteData'  => $siteData,
								)
		);
	}
/////////////////////////////////////////////////////////////////////////
/////// Layout donation menu ///////////////////////////////////////////////////
	public function layoutDonationMenuAction(){
		$siteData = $this->getLocale();
		return $this->render('ZoomDoualaBundle:Show:layoutDonationMenu.html.twig');
	}
////////////////////////////////////////////////////////////////////////
/////// donation page ///////////////////////////////////////////////////
	public function donationAction(){
		$siteData = $this->getLocale();
		return $this->render('ZoomDoualaBundle:Show:donation.html.twig', array
								(
									'siteData'  => $siteData,
								)
							);
	
	}
/////// about us page ///////////////////////////////////////////////////
	public function aboutusAction(){
		//
		$em = $this->getDoctrine()->getManager();
		$page = "aboutus";
		$contentObj =  $em->getRepository('ZoomDoualaBundle:Content')->findOneByPage($page);
		$content    = $contentObj->getContent();
		$contentId  = $contentObj->getId();
		// traduction avant affichage
		$language   = new Languagefromurl;
		$translate  = new Translate;
		$langueId   = $language->getLanguage(); // get current language id
		
		$translatedContent = $translate->getOneTranslation( 5, $contentId, $langueId ); // getOneTranslation($tableid, $wordid, $languageid)
		if( $translatedContent ){
			$content = $translatedContent;
		}
//		var_dump($translatedContent);
		return $this->render('ZoomDoualaBundle:Show:aboutus.html.twig', array(
																		 'content' => $content,
																		)
					        );
	}
 
/////// footer disclaimer //////////////////////////////////////////////////
	public function disclaimerAction(){
		$em = $this->getDoctrine()->getManager();
		$page = "disclaimer";
		$contentObj =  $em->getRepository('ZoomDoualaBundle:Content')->findOneByPage($page);
		$content    = $contentObj->getContent();
		$contentId  = $contentObj->getId();
		// traduction avant affichage
		$language   = new Languagefromurl;
		$translate  = new Translate;
		$langueId = $language->getLanguage(); // get current language id
		
		$translatedContent = $translate->getOneTranslation(5, $contentId, $langueId); // getOneTranslation($tableid, $wordid, $languageid)
		if( $translatedContent ){
			$content = html_entity_decode(htmlentities($translatedContent, 0, 'UTF-8'));
		}
//		var_dump($translatedContent);
		return $this->render('ZoomDoualaBundle:Show:disclaimer.html.twig', array
								(
									'content' => $content,
								)
					        );
	}

///////////////////// Liens utiles //////////
	public function usefullAction(Request $request){
		$em = $this->getDoctrine()->getManager();
		$translate = new Translate;
		$language   = new Languagefromurl;
		$langueId   = $language->getLanguage();
		
		$tableUsefullId     = 6; // id of the table Usefull
		$tableUsefullTypeId = 7; // id of the table Usefull
		// usefull array
		$usefullObj   = $em->getRepository('ZoomDoualaBundle:Usefull')->findBy( [], ['usefulltypeUsefull' => 'DESC'] );
		$titleArrayRaw = array();
		$i = 0;

		// titles array
		foreach( $usefullObj as $key => $value ){
			$title   = $value->getUsefulltypeUsefull()->getUsefulltype();
			$usefullTypeId = $value->getUsefulltypeUsefull()->getId();

			if( $this->multiarray( $title, $titleArrayRaw ) ){
				$data = null;
			}
			else {
				// translation of titles
				$data = $title;
			}
			$titleArrayRaw[$i][$usefullTypeId] = $data;
			$i++;
		}
		unset($value); 
		
		// titles translation
		$titleArray = array();
		foreach($titleArrayRaw as $key => $value ){
			foreach($value as $k => $v){
				if( $v ){
					$trans  = $translate->getOneTranslation( $tableUsefullTypeId, $k, $langueId );
					if( $trans ){
						$data = $trans;
					}
					else{
						$data = $v;
					}
					array_push( $titleArray, $data );
				}
				else{
					array_push( $titleArray, NULL );
				}
			}
		}
		// subtitle translation
		
		foreach($usefullObj as $key => $value){
			$termid      = $value->getId();
			$trans   = $translate->getOneTranslation( $tableUsefullId, $termid, $langueId );
//			echo $trans;
			if( $trans ){
				$value->setUsefull($trans);
			}
		}
		// sitename, email, pays...
		$siteData = $this->getLocale();
		
		return $this->render('ZoomDoualaBundle:Show:usefull.html.twig', array(
						'usefull'   => $usefullObj,
						'titles'    => $titleArray,
						'siteData'  => $siteData,
			)
		);
	}
//////////////////
	public function multiarray( $needle, $haystack, $strict = false ) {
	
		foreach ( $haystack as $value ){
			if ( in_array( $needle, $value )) {
				return true;
			}
		}
		return false;
    }
////////////////
////////////////////////////////////////////////////////////////////////
	public function testAction(){
	//	$tablesArray = new Tablearray;
	//	$tablesArray->getTablearray(1);
		$translate = new Translate;
	//	$translated = $translate->getOneTranslation(2, 2, 1);
	//	$translated = $translate->getTableTranslation(1, 1); // traduction de la table rubrique en anglais
		$myarray = array();
		$myarray[4] = "foo";
		$myarray[10] = "bar";
		asort($myarray, SORT_ASC);
//echo "<pre>";
//	var_dump($myarray);
//echo "</pre>";
		//var_dump($translated);
		return new response("<br><br>End of test");
	}

/////// Contact entreprise footer ///////////////////////////////////////////////////
	public function contactFooterAction(){
		// sitename, email, pays...
		$localData = $this->getLocale();
		
		return $this->render('ZoomDoualaBundle:Show:contactFooter.html.twig', array
								(
									'localData' => $localData,
								)
		);
	}
/////////////////////////////////////////////////////////////////////////
// show site title
	public function titleAction(){
		// sitename, email, pays...
		$localData = $this->getLocale();
		$sitetitle = $localData['title'];
		return $this->render('ZoomDoualaBundle:show:title.html.twig', array
								(
									'sitetitle' => $sitetitle,
								)
		);
	}
/////// Get locales variables, return array
	public function getLocale (){
		$em = $this->getDoctrine()->getManager();
		$localeObj   = $em->getRepository('ZoomDoualaBundle:Locale')->findAll();
		$localData = array();
		//
		$localData['email'] = $localeObj[0]->getEmail();
		$localData['name']  = $localeObj[0]->getSitename();
		$localData['url']   = $localeObj[0]->getSiteUrl();
		$localData['title'] = $localeObj[0]->getSiteTitle();
		$localData['ville'] = $localeObj[0]->getVille();
		$localData['pays']  = $localeObj[0]->getPays();
		//
		return $localData;
	}
////////////////// shuffle for associative arrays, preserves key=>value pairs. ////////////////
    public function shuffle_assoc(&$array) {
        $keys = array_keys($array);

        shuffle($keys);

        foreach($keys as $key) {
            $new[$key] = $array[$key];
        }

        $array = $new;

        return $array;
    }

///////////////// take an array and return a randomized n lenght element ////////////////////////
	public function randomize($array, $n){
		$lenght = count($array);
		if( $lenght > $n){
			$lenght = $n;
		}
		$ran_keys = array_rand( $array, $lenght );
		shuffle( $ran_keys );
		
		// return
		return $ran_keys;
	}
	
	///////////////////////////////////////////////////////////////////////////////////  Page d'accueil (Default) ///////
    public function testdefaultAction(Request $request)
    {
// echo "we are working on this page...98%";
		$motcle = "";
		$rubrique = "";
		$quartier = "";
		$id = "";
	    // $formRechercheActiviteObj = new rechercheActiviteShowForm();
	    // $formRechercheRubriqueObj = new rechercheRubriqueShowForm();
	    // $formRechercheQuartierObj = new rechercheQuartierShowForm();
        $formActivite = $this->createForm(rechercheActiviteShowForm::class);
        $formRubrique = $this->createForm(rechercheRubriqueShowForm::class);
        $formQuartier = $this->createForm(rechercheQuartierShowForm::class);
	    $em = $this->getDoctrine()->getManager();
		if ($request) 
		{   
			// recuperation des données sélectionnées sur les formiulaire de recherche de la page d'accueil
			$formActivite->handleRequest($request); // recherche par nom
		    $motcle = $request->get('motcle');
			$formRubrique->handleRequest($request);  // recherche par rubrique
		    $rubrique = $request->get('rubrique');
	        $formQuartier->handleRequest($request);  // recherche par quartier
		    $quartier = $request->get('quartier');
			// recherche par mot cle
        	if ($motcle)
        	{
				$motcleTab = explode(",",$motcle);
 				$motcle = trim($motcleTab[0]);
				$activiteChoisie = ucfirst(strtolower($motcle));
				// eviter d'avoir une chaine de points dans l'url [...]
				if(! preg_match('/[^\.]/', $activiteChoisie)) {
					$activiteChoisie = $activiteChoisie.'_';
				}

				if(array_key_exists(1, $motcleTab)) // entreprise choisie dans la list box l'autocompletion
				{
					$qartierTab = explode(' - ', $motcleTab[1]);  // quartier
					if($qartierTab)
					{
						if($qartierTab[0] && $qartierTab[1])
						{
							$quartier = trim($qartierTab[0]);		
							$activiteId = trim($qartierTab[1]);			  // id
							$from01 = "motcle";
							$from02 = $motcle;
							return $this->redirect($this->generateUrl('zoom_douala_show_activite', array(
						'from01'=>$from01,'from02'=>$from02, 'activiteChoisie'=>$activiteChoisie, 'activiteId'=>$activiteId)));
						}
						else  // entreprise saisie et non selectionée dans la list autocompletée, on compare et list les entreprises ressemblant 
						{
							$from01 = "saisie";
							$activiteSaisie = $activiteChoisie;
							return $this->redirect($this->generateUrl('zoom_douala_list_activite', array(
						'from01'=>$from01,'activiteSaisie'=>$activiteSaisie,))); 
						}
					}
					else  // entreprise saisie et non selectionée dans la list autocompletée, on compare et list les entreprises ressemblant 
					{
						$from01 = "saisie";
						$activiteSaisie = $activiteChoisie;
						return $this->redirect($this->generateUrl('zoom_douala_list_activite', array(
						'from01'=>$from01,'activiteSaisie'=>$activiteSaisie,))); 
					}
				}
				else if (!array_key_exists(1, $motcleTab)) // entreprise saisie et non selectionée: on compare et liste les entreprises ressemblant 
				{
					$from01 = "saisie";
					$activiteSaisie = $activiteChoisie;
					return $this->redirect($this->generateUrl('zoom_douala_list_activite', array(
					'from01'=>$from01,'activiteSaisie'=>$activiteSaisie,))); 
				}
				else if ($activiteChoisie != "Saisissez une entreprise")// rien n'a été saisie, retour à la page d'accueil
				{
					return $this->render('ZoomDoualaBundle:Show:default.html.twig', array(
					'formActivite'       => $formActivite->createView(), 
					'formRubrique'       => $formRubrique->createView(), 
					'formQuartier'       => $formQuartier->createView(), 
					'representantsArray' => $representantsArray, 
					'rubriquesWindow'    => $rubriquesWindow, 
					'quartiers'          => $quartiers));
				}
			}
			else if($rubrique != '' AND $rubrique != 0)
        	{	// echo $rubrique;
				$from01 = "rubrique";
				$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneById($rubrique);
				$rubriqueChoisie = $rubriqueObj->getRubrique();
				// redirection vers la page de la rubrique choisie
				return $this->redirect($this->generateUrl('zoom_douala_show_rubrique', array(
					'from01'		  => $from01, 
					'rubriqueChoisie' => $rubriqueChoisie
				)));
				 
	    	}
			else if($quartier != '' AND $quartier != 0)
        	{	//echo $quartier;
				$quartieObj = $em->getRepository('ZoomDoualaBundle:Quartier')->findOneById($quartier);
				$quartierChoisie = $quartieObj->getQuartier();
				// redirection vers la page du quartier choisie
				return $this->redirect($this->generateUrl('zoom_douala_show_quartier', array(
					'quartierChoisie'=>$quartierChoisie
				)));
	    	}
		}
		
		/** affichage d'un échantillon de rubriques sur la page d'accueil (rubriquesWindowObj) et du logo de leur entreprise representante si elle existe.
		**/
		$total = 24; // Nombre total de rubriques à afficher 
		// Array des id des rubriques représentés par une entreprise model
		$rubriqueWithModelId = array();
		$rubriqueWithNoModelId = array();
		$rubriqueWithModelObj = $em->getRepository('ZoomDoualaBundle:CompanyRep')->findBy(array("active"=>1), array());
		$countModels = count($rubriqueWithModelObj);
			// array of objects
		for( $i = 0; $i < $countModels; $i++ ){
			$rubriqueObj  = $rubriqueWithModelObj[$i]->getRubriqueId();
			$rubriqueId   = $rubriqueObj->getId(); // a rubrique id
			$companyrepId = $rubriqueWithModelObj[$i]->getId();
			$rubriqueWithModelId[$companyrepId] = $rubriqueId;
		}
			// randomize ids

			// list of duplicate items to delete
		$deleteListCreator = new KeysOfDuplicateValues;
		$deleteList = $deleteListCreator->getDuplicatedKey($rubriqueWithModelId);
			// Delete unwanted keys
		foreach( $deleteList as $key => $value ){
			unset( $rubriqueWithModelId[$value] );
		}

		// randomize activity sector to display
		$rubriqueWithModelId = $this->shuffle_assoc($rubriqueWithModelId);


		// Array des id des rubriques non représentés par une entreprise model
			// Array des id de toutes les rubriques
		$allRubriqueWithNoModelId = array();
		
		if( count($rubriqueWithModelId) < $total ){ // not enough activity sector model
			$allRubriqueWithNoModelObj  = $em->getRepository('ZoomDoualaBundle:Rubrique')->findAll(); // all ruriques
			$countAllRubrique = count($allRubriqueWithNoModelObj);
			
			for( $i = 0; $i < $countAllRubrique; $i++ ){	
				$rubriqueId = $allRubriqueWithNoModelObj[$i]->getId(); // a rubrique id
				if(!in_array($rubriqueId, $rubriqueWithModelId)){ // jump elements of $rubriqueWithModelId
					array_push( $allRubriqueWithNoModelId, $rubriqueId );
				}
			}
			// Create a random  array of index from allRubriqueWithNoModelId with Total - models values
			$rubriqueWithModelCount = count($rubriqueWithModelId);
			$necessaryTotal = (int)$total - (int)$rubriqueWithModelCount;// number of rubrique necessary to reach $total
			$rubriqueWithNoModelId = array();
			$countAllRubriqueWithNoModelId = count( $allRubriqueWithNoModelId );
			do {
				$necessary = array_rand($allRubriqueWithNoModelId, 1); // random key 
				$idvalue   = $allRubriqueWithNoModelId[$necessary];
				if( !in_array( $idvalue, $rubriqueWithNoModelId ) ){ // no duplications
					array_push( $rubriqueWithNoModelId, $idvalue ); // put when random value not already in array
				}
			} while ( count( $rubriqueWithNoModelId ) <= $necessaryTotal ); // random value already in array, do rand again
		}

		// Entire array of ids of objects to display
		$allWidgetRubriqueId = [];
		$i = 0;
		foreach($rubriqueWithModelId as $key => $value){
			$i++;
			if( count($allWidgetRubriqueId) < $total ){
				array_push($allWidgetRubriqueId, $value);
			}
		}
		foreach($rubriqueWithNoModelId as $key => $value){
			$i++;
			if( count($allWidgetRubriqueId) < $total ){
				array_push($allWidgetRubriqueId, $value);
			}
		}
		
		//array of objects to display
		$rubriquesWindow = array();
		for( $i = 0; $i < count($allWidgetRubriqueId); $i++ ){
			$rubriqueId  = $allWidgetRubriqueId[$i];
			$rubriqueObj = $em->getRepository('ZoomDoualaBundle:Rubrique')->findOneBy(array('id'=>$rubriqueId ));
			array_push( $rubriquesWindow, $rubriqueObj ); // array of objects
		}

		// display		$representantsArray = array(); // array des representants (logo, nom, id)
		$i = 0;
		foreach($rubriquesWindow as $rubrique)
		{	
			$rubriqueId = $rubrique->getId(); 
			if(in_array($rubriqueId, $rubriqueWithModelId)){// entreprise representat la categorie
				$modelId = array_keys($rubriqueWithModelId, $rubriqueId);// modelid is stored as key
				$queryRepresentant = $em->createQuery('
											SELECT a FROM ZoomDoualaBundle:CompanyRep a                            			
											WHERE a.id =:modelId')
											->setParameters(array('modelId'=>$modelId ));
				$representantObj = $queryRepresentant->getResult(); // array of objects
//				var_dump($rubriqueId);
				if(isset($representantObj)){
					$representant     = $representantObj[0]->getEntrepriseId();
					$representantLogo = $representant->getPath03();
					$representantNom  = $representant->getEntreprise();
					$activiteId       = $representant->getId();
					// si un representat existe, on affiche son logo sinon le logo par default
					if($representantLogo)
					{
						$representantsArray["logo"][$i] = $representantLogo;
					}
					else
					{
						$representantsArray["logo"][$i]  = "rubrique".$i.".gif";
					}
					
					$representantsArray["nom"][$i] = $representantNom;
					$representantsArray["activiteId"][$i] = $activiteId;
				}
			}
			else
			{
				$representantsArray["logo"][$i]  = "rubrique".$i.".gif";
				$representantsArray["nom"][$i] = "";
			}
			$i++;
		}
		// Fin affichage des rubriques sur la page d'accueil
		
		// Affichage des entreprises à la une
		$entrepriseAlauneObj = $em->getRepository('ZoomDoualaBundle:CompanyAlaune')->findBy(array("active"=>1), array());
		$alauneArray = array();
		if( count( $entrepriseAlauneObj ) ){
			$i = 0;
			// list des entreprises à la une pour randomize
			$alauneIdsArray = array();
			foreach( $entrepriseAlauneObj as $k => $v ){
				$alaune   = $v->getEntrepriseId();
				$alauneId =  $alaune->getId();
				array_push($alauneIdsArray, $alauneId);
			}
;
			// randomize and select 37 ids
			$selectedIds = $this->randomize($alauneIdsArray, 12);
// var_dump($selectedIds);
			foreach( $selectedIds as $k => $v ){
				// $alaune = $v->getEntrepriseId();
				$alauneArray[$i]['entreprise'] = $entrepriseAlauneObj[$v]->getEntrepriseId()->getEntreprise(); // $v are selected key after 
				// Logo randomization
				if( $entrepriseAlauneObj[$v]->getEntrepriseId()->getPath03() ){
					$alauneArray[$i]['logo'] = $entrepriseAlauneObj[$v]->getEntrepriseId()->getPath03();
				}
				else{
					$alauneArray[$i]["logo"] = "default/logo".rand(0, 2).".gif";
				}
				$alauneArray[$i]['id'] = $entrepriseAlauneObj[$v]->getEntrepriseId()->getId();
				// ville
				
				// quartier
				
				// rue
				$i++;
			}
		}
		else{
			$alauneArray = null;
		}
//echo "<pre>";
//	var_dump($alauneArray);
//echo "</pre>";
		// Affichage des quatiers (boutons) sur la page d'accueil
		$quartierObj = $em->createQuery('SELECT a FROM ZoomDoualaBundle:Quartier a 
	                            WHERE a.id != 0');
		$quartiers = $quartierObj->getResult();
		// Fin affichage des quatiers (boutons) sur la page d'accueil
        //affichage de la page d'accueil
		
		// lucky links datas
			// quartier names array
			    // random ids array
		$table        = "quartier";
		$entity       = ucfirst($table);
		$lastIdResult = $em->createQuery( "SELECT COUNT(a.id) FROM ZoomDoualaBundle:$entity a" );
		$lastIdObj    = $lastIdResult->getResult();
		$lastId       = $lastIdObj[0][1]; // number of rows
// var_dump($lastIdObj);
// var_dump($lastId);
// return "--";
		$length    = 3; //we want array of 3 elements
		$randomQuartierIdArray = $this->getRandomIdArray( $lastId, $table, $length );

		$quartierNamesArray = $this->getNamesArray( $randomQuartierIdArray, $table );

			// Rubrique names array
			    // random ids array
		$table     = "rubrique";
		$entity       = ucfirst($table);
		$lastIdResult = $em->createQuery( "SELECT COUNT(a.id) FROM ZoomDoualaBundle:$entity a" );
		$lastIdObj    = $lastIdResult->getResult();
		$lastId       = $lastIdObj[0][1]; // number of rows
// echo $lastId;
// return "Toto";
		$length    = 3; //we want array of 3 elements
		$randomRubriqueIdArray = $this->getRandomIdArray( $lastId, $table, $length );
		$rubriqueNamesArrayBrut = $this->getNamesArray( $randomRubriqueIdArray, $table );
				// translate rubrique array
		$tableId = 1;
		$rubriqueNamesArray = $this->getArrayTrans( $rubriqueNamesArrayBrut, $tableId );
// var_dump($rubriqueNamesArray);	
			// Companies names array
			    // random ids array
		$table     = "activite";
		$entity       = ucfirst($table);
		$lastIdResult = $em->createQuery( "SELECT COUNT(a.id) FROM ZoomDoualaBundle:$entity a" );
		$lastIdObj    = $lastIdResult->getResult();
		$lastId       = $lastIdObj[0][1]; // number of rows
		$length       = 3; //we want array of 3 elements
		$randomCompanyIdArray = $this->getRandomIdArray( $lastId, $table, $length );
		$companyNamesArray = $this->getNamesArray( $randomCompanyIdArray, $table );
		
// total number of rubrique in rubrique list form
		$resultResult  = $em->createQuery( "SELECT COUNT(a.id) 
											FROM ZoomDoualaBundle:rubrique a" );
		$resultObj     = $resultResult->getResult();
		$countrubrique = $resultObj[0][1]; // number of rows

// total number of district in rubrique list form
		$resultResult  = $em->createQuery( "SELECT COUNT(a.id) 
											FROM ZoomDoualaBundle:quartier a" );
		$resultObj     = $resultResult->getResult();
		$countquartier = $resultObj[0][1]; // number of rows
		// site datas (email, sitename, ...)
		$siteData = $this->getLocale();

		$currentRoute = $request->attributes->get('_route');
// echo $currentRoute;
//        if( $currentRoute == "zoom_douala_home﻿" ){
//			$page = "ZoomDoualaBundle:Show:default.html.twig";
//		}
//		else{
//			$page = "ZoomDoualaBundle:Show:testdefault.html.twig";
//		}

$page = "ZoomDoualaBundle:Show:testdefault.html.twig";

        return $this->render($page,  
							array(
									'formActivite'       => $formActivite->createView(), 
								    'formRubrique'       => $formRubrique->createView(), 
								    'formQuartier'       => $formQuartier->createView(), 
								    'representantsArray' => $representantsArray, 
									'alauneArray'        => $alauneArray,
								    'rubriquesWindow'    => $rubriquesWindow, 
								    'quartiers'          => $quartiers,
								    'luckydistrict'      => $quartierNamesArray,
								    'luckycompany'       => $companyNamesArray,
								    'luckysector'        => $rubriqueNamesArray,
								    'countrubrique'      => $countrubrique,
								    'countquartier'      => $countquartier,
								    'siteData'           => $siteData
								  )
							);
	}
	
	////////////////////////////////////////////////////////////  Bouton ajouter votre logo ///////
    public function btn_AddlogoAction(Request $request)
    {
		return $this->render('ZoomDoualaBundle:Show:btn_addlogo.html.twig');
	}
}