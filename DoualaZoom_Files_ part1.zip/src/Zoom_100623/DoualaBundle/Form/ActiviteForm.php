<?php
namespace Zoom\DoualaBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface; 
use Doctrine\ORM\EntityRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
// use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType; 

use Doctrine\Common\Persistence\ObjectManager;
use Zoom\DoualaBundle\Form\TagsToCollectionTransformer;

class ActiviteForm extends AbstractType
{
    
    private $manager;

    public function __construct(ObjectManager $manager)
    {
        $this->manager = $manager;
    }
    
	public function buildForm(FormBuilderInterface $builder, array $options)
    {   
	    // old repere
		$cookiename = "php_oldRepere_cookie";
		$repere = isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : '';
		// old rue
		$cookiename = "php_oldRue_cookie";
		$rue = isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : '';
		// old quartier
		$cookiename = "php_oldQuartier_cookie";
        $php_oldQuartier_cookie = isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : '';
		//if($_COOKIE[$cookiename])
		//{
		//	$php_oldQuartier_cookie = $_COOKIE[$cookiename];
		//}
		// old rubrique
		$cookiename = "php_oldRubrique_cookie";
        $php_oldRubrique_cookie = isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : '';
		//if($_COOKIE[$cookiename])
		//{
		//	$php_oldRubrique_cookie = $_COOKIE[$cookiename];
		//}
		// activated value 01
		$cookiename = "php_activated_value01_cookie";
        $php_activated_value01_cookie  = isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : 'oui';
		//if($_COOKIE[$cookiename])
		//{
		//	$php_activated_value01_cookie = $_COOKIE[$cookiename];
		//}
		//else
		//{
		//	$php_activated_value01_cookie = 'oui';
		//}
        
		// activated value 02
		$cookiename = "php_activated_value02_cookie";
        $php_activated_value02_cookie  = isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : 'oui';
		//if($_COOKIE[$cookiename])
		//{
		//	$php_activated_value02_cookie = $_COOKIE[$cookiename];
		//}
		//else
		//{
		//	$php_activated_value02_cookie = 'no';
		//}
		// old date
		//$cookiename = "php_oldDate_cookie";
		//if($_COOKIE[$cookiename]){ // si c une modif
			//php_date_cookie = new \DateTime();
			//$dateTab = explode('-', $_COOKIE[$cookiename]);
			//$day = intval(trim($dateTab[0]));
			//$month = intval(trim($dateTab[1]));
			//$year = intval(trim($dateTab[2]));
// echo $cookiename.' = '.$_COOKIE[$cookiename];
			//$php_date_cookie->setdate($year, $day, $month);
			//unset($_COOKIE[$cookiename]);
		//}
		//else
		//{
		//	$php_date_cookie = new \DateTime();
		//}
		$builder
          ->add('entreprise', TextType::class, array('label' =>'Nom'))
          ->add('tags', CollectionType::class, array(
                'entry_type' => 'Zoom\DoualaBundle\Form\TagForm',
                'allow_add' => true,
                'allow_delete' => true,
                'required' => false
           ))
          ->add('images', CollectionType::class, array(
                'entry_type' => 'Zoom\StoreBundle\Form\ImageForm',
                'allow_add' => true,
                'allow_delete' => true,
                'required' => false
           ))
          ->add('bp', TextType::class, array('required' => false))
          ->add('telephone01', TextType::class,array('required' => true))
          ->add('telephone02', TextType::class, array('required' => false))
          ->add('fax', TextType::class, array('required' => false))
          ->add('email', EmailType::class, array('required' => false))
          ->add('web', TextType::class, array('required' => false,))
          ->add('contact', TextType::class, array('label'=>'Nom du contact','required' => false))
          ->add('fonctionId', EntityType::class, array(
				'label' =>'Fonction',
				'class' => 'ZoomDoualaBundle:Fonction', 
				'query_builder' => function(EntityRepository $er) {
		                     $cookiename = "php_oldFonction_cookie";
					         $fonction = isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : '';
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.fonction = :fonction THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
							 ->setParameters(array('fonction' => $fonction)); 
                             if( isset( $_COOKIE[$cookiename] ) )
                                unset($_COOKIE[$cookiename]);
							}
							))	
          ->add('villeId',EntityType::class, array('label' =>'Ville', 'class' => 'ZoomDoualaBundle:Ville'))	
          ->add('quartierId', EntityType::class, array(
				'label' =>'Quartier',
				'class' => 'ZoomDoualaBundle:Quartier', 
				'query_builder' => function(EntityRepository $er) {
		                     $cookiename = "php_oldQuartier_cookie";
					         $quartier = isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : '';
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.quartier = :quartier THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
							 ->setParameters(array('quartier' => $quartier)); 
                             if( isset( $_COOKIE[$cookiename] ) )
                                unset($_COOKIE[$cookiename]);
							}
							))
          ->add('rueId', TextType::class, array('label' =>'Rue', 'data'=>$rue, 'required' => false))	
	      ->add('repereId', TextType::class, array('label' =>'.', 'data'=>$repere, 'required' => false, ))	
          ->add('rubriqueId', EntityType::class, array(
				'label' =>'Rubrique',
				'class' => 'ZoomDoualaBundle:Rubrique', 
				'query_builder' => function(EntityRepository $er) {
		                     $cookiename = "php_oldRubrique_cookie";
					         $rubrique =  isset( $_COOKIE[$cookiename] ) ? $_COOKIE[$cookiename] : '';
                             return $er->createQueryBuilder('ss')
							 ->addSelect('CASE WHEN ss.rubrique = :rubrique THEN 1 ELSE 0 END AS HIDDEN sortCondition')
                             ->addOrderBy('sortCondition', 'DESC')
                             ->addOrderBy('ss.rubrique', 'ASC')
							 ->setParameters(array('rubrique' => $rubrique)); 
                             if( isset( $_COOKIE[$cookiename] ) )
                                unset($_COOKIE[$cookiename]);
							}
							))
          ->add('place', TextType::class, array('label' =>'Détail', 'required' => false))
          ->add('map', TextType::class, array('required' => false))
          ->add('date', DateType::class, array('widget' => 'single_text', 'format' => 'dd-MM-yyyy', 'attr' => array('style' => ('display:inline'))))
          ->add('rueId_primary_key', HiddenType::class) // champ ajouté pour la combobox (listbox + textbox)
		  ->add('path01', FileType::class,  array('attr'=>array('style'=>(' border:none')),'required' => false, 'data_class' =>NULL,'label' => 'Photo de l\'entreprise (.jpg)'))
		  ->add('path02', FileType::class, array('attr'=>array('style'=>(' border:none')), 'required' => false, 'data_class' =>NULL,'label' => 'Animation vidéo (.flv)'))
		  ->add('path03', FileType::class, array('attr'=>array('style'=>(' border:none')),'required' => false, 'data_class' =>NULL,'label' => 'Logo de l\'entreprise (.jpg, .gif)'))
		  ->add('activated', ChoiceType::class, array('attr' => array('style' => ('width:80px;')),
			    'label'  => 'Activer',
			    'choices' => array($php_activated_value01_cookie => $php_activated_value01_cookie, $php_activated_value02_cookie => $php_activated_value02_cookie)
		  ,));
          
        // Data Transformer
        $builder
            ->get('tags')
             ->addModelTransformer(new TagsToCollectionTransformer($this->manager));
    }
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Zoom\DoualaBundle\Entity\Activite',
        ));
    }
    
	public function getBlockPrefix()
	{
    	return '';
	}

}