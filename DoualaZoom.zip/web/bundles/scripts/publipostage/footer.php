<?php
echo '<br>';
echo '&copy; August 2017 YaoundeZoom.com';