<?php
header('Content-Type: text/html; charset=iso 8859');

if(!isset($_SESSION)){
	session_start();
}

$password = 'aDmin58965';
echo "<p><span style='font-size:2em'>YaoundeZom.com</span></p>";
echo "<p style='font-style:italic'>Publipostage file generator</p>";
echo "<p>This script writes companies fields like this: <br>[ id ]*[ entreprise ]*[ bp ]*[ telephone01 ]*[ telephone02 ]*[ web ]*[ contact ]*[ fonction ]*[ map ]*[ email ]*[ alphabetique ]*[rubrique] *[quartier]*[ rue ]*[ alphabetiqueLink ]*[ rubriqueLink ]*[ quartierLink ]*[ rueLink ]*[ companyLink ]*[ gsearchLink ]*[ gmapLink ]*[ adsize ]*[ activated ]<br>Email: All</p>";
echo "<p>At the end of the treatment, download the publipostage text issued <a href = 'files/publipostage.txt' download = 'files/publipostage.txt' target='_blank'>here</a></p>";

echo "<p>&nbsp;</p>";
// message � afficher
if(isset($_POST['password']) && $_POST['password'] == $password){
	$_SESSION['typedpassword'] = $_POST['password']; // le client est logu�
}

if(isset($_POST['password']) && $_POST['password'] != $password){
		echo "<p style='color:red'>Mot de passe incorrect<br></p>";
}
// Formulaire � afficher
if(isset($_SESSION['typedpassword']) ){
	echo "<p style='color:green'>Bienvenue admin</p>";
	echo "<p>
			<form method='post' enctype='multipart/form-data'>
				<div style='background-color:#F4F4F4; width:30%;'>
				<label>Importer un fichier .txt[id, email]<br><span style='font-size:10'>facultatif</span>
					<br><input type='file' name='emailfile'  id='emailfile'>
					Differentiation<input type='checkbox' name='diff'>
				</label>
				</div>
				<input type='hidden' name='commencer'>
				<br><input type='submit' value='COMMENCER'>
			</form>
		 </p>";
}
else{
	echo "<p>veuillez vous identifier pour continuer</p>";
	echo "<p><form method='post'>
		     <input type='password' name='password' name='password'><input type='submit' value='ok'>
			 </form>
		  </p>";
}
// session_destroy();