<?php
/**
	retourne le nom d'un element en fonction de son id dans la table activite
**/

class companyproperties
{
	public $rubrique;
  public $rubriqueId;
	public $quartier;
	public $rue;
	public $alphabetique;
	public $company;
	// id to name
	public function getProperties($companyId){
		
		$sql =  "SELECT * FROM activite WHERE id = '$companyId'";
		$idtoname = new idtoname;
		//connexion
		$connexion = new dbconnexion;
		$dbh = $connexion->connect(); // database object
		//set properties
    	foreach  ($dbh->query($sql) as $row) {
			$this->rubrique = $idtoname->getName($row['rubriqueId'], 'rubrique');
			$this->quartier =  $idtoname->getName($row['quartierId'], 'quartier');
			$this->rue =  $idtoname->getName($row['rueId'], 'rue');
			$this->ville =  $idtoname->getName($row['villeId'], 'ville');
			$this->fonction =  $idtoname->getName($row['fonctionId'], 'fonction');
			$this->company =  $row['entreprise'];
			$tab = str_split($this->company);
			$this->alphabetique = $tab[0];
			$this->adsize =  $idtoname->getName($row['adsizeId'], 'adsize');
      $this->rubriqueId = $row['rubriqueId'];
  		}
		$connexion = NULL;
	}
}


