<?php
/**
	Properties of this class has links that a company has in the site after a search by sector, name, ...
**/

class linkcreator
{
	// linkcreator properties
	public $rubriqueLink;
	public $quartierLink;
	public $rueLink;
	public $alphabetiqueLink;
	public $companyLink;
	
	
	public function getLink($companyId){
	// propri�t�s de cette companyId
		$properties = new companyproperties;
		$properties->getProperties($companyId);
		// company rubrique name
		$rubrique = $properties->rubrique;
		// company quartier name
		$quartier = $properties->quartier;
		// company rue name
		$rue = $properties->rue;
		// company alphabetique name
		$alphabetique = $properties->alphabetique;
		// company name
		$company = $properties->company;
		// ville
		$ville = $properties->ville; 
		
	// fabrication des liens
		// company found by rubrique link
		$this->rubriqueLink = "http://www.doualazoom.com/web/fr/recherche/rubrique/$rubrique/$rubriqueId";
		// company found by quartier link
		$this->quartierLink = "http://www.doualazoom.com/web/fr/quartier/quartier/$quartier";
		// company found by rue link
		$this->rueLink = "http://www.doualazoom.com/web/fr/show/rue/$rue";
		// company found by alphasearch link
		$this->alphabetiqueLink = "http://www.doualazoom.com/web/fr/index/alpha/$alphabetique";
		// company company page
		$this->companyLink = "http://www.doualazoom.com/web/fr/activite/motcle/lien sponsorise/$company/$companyId";
		// google search
		$this->gsearchLink = "https://www.google.cm/search?dcr=0&source=hp&ei=QO4jWri-DcKgUZnKoNgK&q=".$company." Cameroun, ".$ville.", CM.&oq=".$company." Cameroun, ".$ville.", CM&gs_l=psy-ab.3..0i203k1j0j0i203k1l8.1450.3576.0.3945.8.7.0.0.0.0.384.1622.2-2j3.6.0..2..0...1.1.64.psy-ab..2.6.2131.6..35i39k1.511.FoxNDe6JPGs";
		$this->gmapLink = "http://www.google.cm/maps/place/".$company.",".$ville.",CM";
	}
}