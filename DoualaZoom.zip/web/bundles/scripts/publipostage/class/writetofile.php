<?php
/**
 *	Walk thru the company table and write line to the text file
 **/
 
class writetofile
{
	public function writingtofile($filename = NULL, $diff = NULL){
		ini_set('max_execution_time', 0);
		//connexion
		$connexion = new dbconnexion;
		$dbh = $connexion->connect(); // database object
		// file creation
		$myfile = "files/".$filename;
		// id list
		$idlist = array();
		$idfromfile = array();
		$idfromdb = array();
		
		// ids from the file
		if($filename){
			// open the file
			$fileobj = fopen($myfile,"r");

			while(!feof($fileobj))
  			{
  				$fileline = fgets($fileobj);
				$filelineArray = explode(",", $fileline);
				// id list
				if($filelineArray[0]){
					$id = trim($filelineArray[0]);
					array_push($idfromfile, $id);
					$idlist = $idfromfile;
					$message = "Source de donn�es: fichier.<br>";
				}
				// update email in the database if differentiation not checked
				if(isset($filelineArray[0]) && isset($filelineArray[1]) && $diff == NULL){
					$email = trim($filelineArray[1]);
					$sql =  "UPDATE activite SET email = '$email'  WHERE id = '$id'";
					$stmt = $dbh->prepare($sql);
					$stmt->execute();
					$count = $stmt->rowCount();
				}
  			}
			fclose($fileobj);
		}
		
		// ids from the database - id from file
		if($filename && $diff){ 
			$sql =  "SELECT id FROM activite";
			foreach($dbh->query($sql) as $row) {
				// id list
				array_push($idfromdb, $row['id']);
			}
			$idlist = array_diff($idfromdb, $idfromfile);
			$message = "Source de donn�es: difference entre la base de donn�e et le fichier.<br>";
		}
		
		// ids from the database
		if(!$filename){
		$message = "Source de donn�es: database.<br>";
			$sql =  "SELECT id FROM activite";
			foreach($dbh->query($sql) as $row) {
				// id list
				array_push($idfromdb, $row['id']);
			}
			$idlist = $idfromdb;
		}
		// message de la source de donn�e
		echo $message;
		// Publipostage data
		// query
		$sql =  "SELECT * FROM activite WHERE id = :id";
		$sth = $dbh->prepare($sql);
		// company property initialisation
		$properties = new companyproperties;
		// company links initialisation
		$link = new linkcreator;
		// walking and writing
		$lineText = "";
		$towrite = array();
		
		$publipostagefile = fopen("files/publipostage.txt", "w");
		foreach($idlist as $id){
			$sth->bindParam(':id', $id);
			$sth->execute();
			$result = $sth->fetchAll();
			foreach($result as $row) {
			//if($row['email']){ // only companies with email are treated
				$properties->getProperties($row['id']); // build company properties object property
				$link->getLink($row['id']); // build company links object property
				$lineText = $row['id'].'*'.$row['entreprise'].'*'.$row['bp'].'*'.$row['telephone01'].'*'.$row['telephone02'].'*'.$row['web'].'*'.$row['fax'].'*'.$row['contact'].'*'.$properties->fonction.'*'.$row['map'].'*'.$row['email'].'*'.$properties->alphabetique.'*'.$properties->rubrique.'*'.$properties->quartier.'*'.$properties->rue.'*'.$link->alphabetiqueLink.'*'.$link->rubriqueLink.'*'.$link->quartierLink.'*'.$link->rueLink.'*'.$link->companyLink.'*'.$link->gsearchLink.'*'.$link->gmapLink.'*'.$properties->adsize.'*'.$row['activated'];
				array_push($towrite, $lineText);
			//}
			}
		}
		// Write publipostage data to file and output
		echo "Nombre d'entreprises: ".count($idlist);
		foreach($towrite as $lineText){
			echo "<p>".$lineText."</p>";
			fwrite($publipostagefile, $lineText."\r\n\r\n");
		}
		fclose($publipostagefile);
	}
}