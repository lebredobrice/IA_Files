<?php
   $dbhost = 'localhost';
   $dbname = 'default_db';
   $dbuser = 'root';
   $dbpass = '';
?>