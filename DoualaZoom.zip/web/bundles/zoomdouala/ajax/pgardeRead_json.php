<?php 
	error_reporting(E_ALL); 
	ini_set('display_errors', 1);
	header('Content-type: text/html; charset=ISO-8859-1');
	// ini_set("display_errors","1");
	 
	// id de la rubrique pharmacie
	include_once("connexion.php");
	include_once("connexionTableRubrique.php");
    $query = "SELECT id from $table WHERE rubrique = 'pharmacie'";
    $conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
    $result = mysqli_query($conn, $query);
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{ 
		$pharmacieId = $row['id'];
	}
//echo $pharmacieId;
	// toutes les entreprises, pour l'autocompletion
	include_once("connexionTableActivite.php");
//	include_once ("AmpersandReplace.php"); // classe proprietaire
//	$ampRplc = new AmpersandRemplace;
//	$term = trim(strip_tags($_GET['term']));//retrieve the search term that autocomplete sends
//	$term = "Okalla Ahanda";
//  echo $term;
    $query = "SELECT entreprise, quartierId, id from $table WHERE activated = 'oui' AND rubriqueId = '$pharmacieId' 	              ORDER BY entreprise ASC";
    $conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
//	mysqli_set_charset($conn,"ISO-8859-1");
    $result = mysqli_query($conn, $query);
// echo count($result); 
	$entreprises = array();		
	
	include_once("connexionTableQuartier.php");
//include_once ("AmpersandReplace.php"); // classe proprietaire
//	$ampRplc = new AmpersandRemplace;
	$pgarde = "";
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{   
		// extraction de nom de quartierles quartiers
		$query02 = "SELECT quartier from $table where id = $row[quartierId]";
    	$conn02 = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
    	$result02 = mysqli_query($conn02, $query02);
		
		while ($row02 = mysqli_fetch_array($result02,MYSQLI_ASSOC))
		{ 	
			$entreprise = $row["entreprise"];
		 	// $entreprise = $ampRplc->replacement(htmlentities($entreprise)); // traitement des ampersands
			$pgarde = $pgarde.$entreprise.", ".$row02["quartier"]." - ".$row["id"]."*";
    	}
	}

echo $pgarde;
