<?php
header('Content-type: text/html; charset=ISO-8859-1');

$array = array('nome'=>'Pai��o','cidade'=>'S�o Paulo');

$array = array_map('htmlentities',$array);

//encode
$json = html_entity_decode(json_encode($array));

//Output: {"nome":"Pai��o","cidade":"S�o Paulo"}
echo $json;