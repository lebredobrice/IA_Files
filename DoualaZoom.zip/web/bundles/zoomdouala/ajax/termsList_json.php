<?php 
	/** receive a table id an language id, returns an array 
	 **  with id and name of non translated terms. 
	 **/
	
	header('Content-type: text/html; charset=ISO-8859-1');
	error_reporting(E_ALL); 
	ini_set('display_errors', 1);
	ini_set("display_errors","1");
	// id de la rubrique pharmacie
	include_once("connexion.php");
	$tableid = $_POST["tableid"];
	$languageid = $_POST["languageid"];
//$tableid = 1;
//$languageid = 1;
	$table = "";
	// nom de la table
	$query = "SELECT name FROM tablelist WHERE id = $tableid AND id >0 LIMIT 1";
	$conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
    $result = mysqli_query($conn, $query);
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{ 
		$table = strtolower($row["name"]);
	}
	$field = $table; // le champ recherch� a le meme nom que la table, par convention

	// list des termes ayant deja une traduction dans cette table et cette langue
	$query = "SELECT translatedid from translation WHERE table_id = $tableid AND language_id = $languageid";
    $conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
    $result = mysqli_query($conn, $query);
	$j = 0;
	$alreadyTranslatedId = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
	{
		$alreadyTranslatedId[$j] = $row["translatedid"];
		$j++;
	}

	// termes � traduires
    $query = "SELECT id, $field FROM $table";
    $conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
    $result = mysqli_query($conn, $query);	
	$count =  $result->num_rows;
	$termslist = "";
	$i = 0;
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{
		if(!in_array($row["id"], $alreadyTranslatedId)){// si l'id n'apartient pas au id deja traduits
			$termslist .= $row["id"].'|'.$row[$field]."*";
		}
		$i++;
	}
	//on enleve l'etoile � la fin de la chaine
	$termslist = substr(trim($termslist), 0, count($termslist)-2);
	// retout � ajax
	echo $termslist;
