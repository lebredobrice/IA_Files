<?php 
	error_reporting(E_ALL); 
	ini_set('display_errors', 1);
	header('Content-type: text/html; charset=ISO-8859-1');
	// ini_set("display_errors","1");

	include_once("connexion.php");
    $query = "SELECT id, language FROM language";
    $conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
    $result = mysqli_query($conn, $query);
	$tablelist = "";
	$count =  $result->num_rows;
	$i = 0;
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{ 
		if($i < $count-1){
			$tablelist = $tablelist.$row["id"]." - ".$row["language"]."*";
		}
		else{
			$tablelist = $tablelist.$row["id"]." - ".$row["language"];
		}
		$i++;
	}

	echo $tablelist;
