<?php 
header('Content-Type: text/html; charset=ISO-8859-15'); 
    //$quartierId = $_POST['ajaxQuartier'];
	// $paysId = 34; 
    include_once("connexionTableActivite.php");
    $db_conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
    $rues = "";
    $sql = "SELECT id from $table  WHERE villeId != 1";
    $query = mysqli_query($db_conn, $sql);
	while($row = mysqli_fetch_array($query, MYSQLI_ASSOC))
    {
       if($row)
	   {
	       echo $row["id"]."<br>";
	   }
    }

	// Close your database connection
    mysqli_close($db_conn);
	// Echo the results back to Ajax
	// $villes = rtrim($villes, "|");
?>
    
