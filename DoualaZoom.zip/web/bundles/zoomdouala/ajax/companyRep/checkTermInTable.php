<?php 
/**
 * Get a field value from a string containing company id
 **/	
header('Content-type: text/html; charset=ISO-8859-1');
//errors
ini_set("display_errors","1"); 
ERROR_REPORTING(E_ALL);

class isASectorCompany
{
	public $dbhost;
	public $dbname;
	public $dbuser;
	public $dbpass;
	public $dbport;
	public $MyPDO;
	
	public function __construct(){
		// required
		require("../connexion.php");
		//Initiate PDO vars from required file
		$this->dbhost =  $dbhost;
		$this->dbname =  $dbname;
		$this->dbuser =  $dbuser;
		$this->dbpass =  $dbpass;
		$this->dbport =  $dbport;
	}
	
	public function connect(){
		try{
			$this->MyPDO = new PDO("mysql:host=$this->dbhost;port=$this->dbport;dbname=$this->dbname", $this->dbuser, $this->dbpass);
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}
	// get term id in the table
	public function checkTermInTable($table, $term){ // table = rubrique
		$query  = "SELECT * FROM $table 
				   WHERE $table = '$term'";
		$sth = $this->MyPDO->prepare($query);
		$sth->execute();
		$result = $sth->fetch(PDO::FETCH_ASSOC);
		return $result['id'];
	}
	// is this id exist in the activity table
//	public function isASectorCompany($table, $field, $term){// table = activite, field = rubriqueId, 
//		$query  = "SELECT * FROM $table 
//				   WHERE $field = '$term'";
//		$sth = $this->MyPDO->prepare($query);
//		$sth->execute();
//		$result = $sth->fetch(PDO::FETCH_ASSOC);
//		var_dump($query);
//		if($result[$field]){
//			return true;
//		}
//		else{
//			return false;
//		}
//		
//	}
}
$isASectorCompany = new isASectorCompany;
$isASectorCompany->connect();
$table = "rubrique";
$term  = "abattoir";
// get id of the term id on his child table
$termId = $isASectorCompany->getSectorId($table, $term);

// check if this id exist for the field of the table
$table = "activite";
$field = "rubriqueId"; // field name in the mother table (activite)
$isASector  =  $isASectorCompany->isASectorCompany($table, $field, $termId);
var_dump($isASector);