<?php 
	header('Content-type: text/html; charset=ISO-8859-1');
	// ini_set("display_errors","1"); 
    // ERROR_REPORTING(E_ALL);
	// toutes les entreprises, pour l'autocompletion
	include_once("connexionTableActivite.php");
//	include_once ("AmpersandReplace.php"); // classe proprietaire
//	$ampRplc = new AmpersandRemplace;
	$term = trim(strip_tags($_GET['term']));//retrieve the search term that autocomplete sends
//	$term = "Okalla Ahanda";
//  echo $term;
    $query = "SELECT entreprise, quartierId, id from $table WHERE activated = 'oui' AND entreprise LIKE '%$term%'";
    $conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
//	mysqli_set_charset($conn,"ISO-8859-1");
    $result = mysqli_query($conn, $query);
// echo count($result); 
	$entreprises = array();		
	
	include_once("connexionTableQuartier.php");
	include_once ("AmpersandReplace.php"); // classe proprietaire
	$ampRplc = new AmpersandRemplace;
	
	while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	{   
		// les quartiers
		$query02 = "SELECT quartier from $table where id = $row[quartierId]";
    	$conn02 = mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname");
    	$result02 = mysqli_query($conn02, $query02);
		while ($row02 = mysqli_fetch_array($result02,MYSQLI_ASSOC))
		{ 	
			 $entreprise = $row["entreprise"];
		 // $entreprise = $ampRplc->replacement(htmlentities($entreprise)); // traitement des ampersands
			$entreprises["value"] = utf8_encode($entreprise.", ".$row02["quartier"]." - ".$row["id"]);
			$entreprises["id"] = (int)$row["id"];
			if($entreprises["value"])
			{
				$row_set[] = $entreprises;	//build an array
			}
    	}
	}
	
	echo json_encode($row_set);
