<?php 
header('Content-type: text/plain; charset=UTF-8');

/* Recuperation des donn�es du formulaire de 
 * de report d'erreur et envoie des donn�es 
 * au ShowController
 */

// fonction qui change les / en *
function slashToStar($string)
{	
	return str_replace('/','*', $string);
} 

// assainissemant de toutes les valeurs post�es
foreach($_POST as $key => $value) 
{
  if(ini_get('magic_quotes_gpc'))
  $_POST[$key] = stripslashes($_POST[$key]);
  $_POST[$key] = htmlspecialchars(strip_tags($_POST[$key]));
}


$local         = rawurlencode($_POST["local"]);
$visitoremail  = rawurlencode($_POST["email"]);
$dzoomemail    = rawurlencode("courrier@doualazoom.com"); // adresse smtp
$dzoomreceveur = rawurlencode("error@doualazoom.com"); // adresse du destinataire du mail (admin)
$nom           = rawurlencode($_POST["nom"]);
$lien          = slashToStar($_POST["lien"]); 
$message       = rawurlencode($_POST["message"]);
$urlprefix     = "http://".$_SERVER['SERVER_NAME']."/web/errormail";
$url           = $urlprefix.'/'.$visitoremail.'/'.$dzoomemail.'/'.$dzoomreceveur.'/'.$message.'/'.$nom.'/'.$lien.'/'.$local;
// echo $url;
$content = file_get_contents($url);
if($content === Null)
{
	echo "Erreur d'envoie des donn�es";
}
else
{
	echo $content; // reponse du controller ShowController
}
 