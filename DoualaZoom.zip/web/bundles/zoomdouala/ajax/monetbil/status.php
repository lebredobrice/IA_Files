<?php
/**
	Insert transactionid in current transaction table if this transaction id don't exist
	Return the current transaction status
*/

class Status{
	public $dbhost;
	public $dbname;
	public $dbuser;
	public $dbpass;
	public $dbport;
	public $MyPDO;
	public $secret;
	
	public function __construct(){
		// required
		require("../connexion.php");
		//Initiate PDO vars from included file
		$this->dbhost =  $dbhost;
		$this->dbname =  $dbname;
		$this->dbuser =  $dbuser;
		$this->dbpass =  $dbpass;
		$this->dbport =  $dbport;
	}

   /**
	* connect pdo connect
	*/
	public function connect(){
		try{
			$this->MyPDO = new PDO("mysql:host=$this->dbhost;port=$this->dbport;dbname=$this->dbname", $this->dbuser, $this->dbpass);
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}

   /**
	* is_transactionid_exist
	*
	* @param  string $transaction_id
	* @return bool
	*/
	public function is_transactionid_exist($transaction_id){ // insert transaction id aka transaction reference
		$conn  = $this->connect();
		$table = "curent_transaction";
		$query = "SELECT transaction_id 
				  FROM $table
				  WHERE transaction_id = '$transaction_id'";

		$pdo   = $this->MyPDO;
		$stmt  = $pdo->prepare($query);
		$stmt->execute();
		//Fetch all of the values in form of a numeric array 
		$result = $stmt->fetchAll(\PDO::FETCH_NUM);
		$ret = count($result);

		return $ret;
	}

   /**
	* insert_transaction
	*
	* @param  string $transaction_id
	* @return string
	*/
	public function insert_transaction($transaction_id){ // insert transaction id
		$date   = date("Y/m/d");
		$status = 0; // transaction is pending
		$table  = "curent_transaction";

		$conn   = $this->connect();
		$query  = "INSERT INTO $table ( transaction_id, status, date )
				   VALUES ( '$transaction_id', '$status', '$date' )";
		$pdo    = $this->MyPDO;
		$stmt   = $pdo->prepare($query);
		$result = $stmt->execute();

		return $result;
	}

   /**
	* getTransactionStatus
	*
	* @param  string $transaction_id
	* @return string
	*/
	public function getTransactionStatus($transaction_id){ // insert transaction id
		$table = "curent_transaction";
		$query = "SELECT status 
				  FROM $table
				  WHERE transaction_id = '$transaction_id'";
		$conn  = $this->connect();
		$pdo   = $this->MyPDO;
		$stmt  = $pdo->prepare($query);
		$stmt->execute();
		// status value
		//Fetch all of the values in form of a numeric array 
		$result = $stmt->fetchAll(\PDO::FETCH_NUM);
		$ret = 0;
		if($result){
			foreach($result as $key=>$value){
				$ret = $value[0];
			}
		}
		return $ret;
	}
}

$status = new Status;

$transaction_id = $_POST['transaction_id'];

$is_transactionid_exist = $status->is_transactionid_exist($transaction_id);

//echo "is_transactionid_exist:".$is_transactionid_exist;

// is this transaction is already in the database. If no, insert it
if( !$is_transactionid_exist ){
	$status->insert_transaction($transaction_id);
}
// get the status of this transaction and echo back for ajax
$rep = $status->getTransactionStatus($transaction_id);
echo $rep;

