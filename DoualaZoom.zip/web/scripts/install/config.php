<?php 
	$_SESSION['fileDir']       = "files";                           // upload directrory
	$_SESSION['inputName']     = "companiesFile";                   // upload directrory
	$_SESSION['outputfile']    = "output.txt";                      // upload directrory
	define('HOST',   "localhost");			            // database host
	define('DBNAME', "EQdb");	 					    // database name
	define('USER',   "root");                               // database user
	define('PASS',   "");                                  // database pass
	define('SITENAME',   "MalaZoom Installer");                         // site name
	define('SITEPASS',   "aDmin58965");                             // site pass