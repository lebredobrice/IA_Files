<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
/**
 *
 *  Ce script suprime les traductions de rubriques dans la table translation.
 *
 **/

// create connexion object to database
class DeletetTranslation
{
	public $MyPDO = "";

	public function connect(){
		try{
			$this->MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
		}
		catch (PDOException $e){
			echo 'Erreur:'.$e->getMessage();
		}
	}

	// delete all rubrique translation
	public function deleteRubriques($tableId){
		$query = "DELETE FROM translation 
				  WHERE table_id     = '$tableId'";
		$stmt   = $this->MyPDO->prepare($query);
		$stmt->execute();
		$count  = $stmt->rowCount();
		if($count){
			echo "$count rubriques effac�es";
		}
		else{
			echo 'Erreur lors de la suppression <br>' ;
		}
	}
// 	$this->iterate();
}

$deletetTranslation = new DeletetTranslation;
$deletetTranslation->connect();
$deletetTranslation->deleteRubriques(1);
// $insertTrans->getRubriqueId('Abattoir');
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
Copyright 2018 - DoualaZoom.com
</body>
</html>


