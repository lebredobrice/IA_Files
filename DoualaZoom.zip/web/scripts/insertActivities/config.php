<?php 
	$_SESSION['fileDir']       = "files";                           // upload directrory
	$_SESSION['inputName']     = "companiesFile";                   // upload directrory
	$_SESSION['outputfile']    = "output.txt";                      // upload directrory
	define('HOST',   "sg211.servergrove.com");			            // database host
	define('DBNAME', "weynaakc_dzoom");	 					        // database name
	define('USER',   "weyna_dzoom");                                // database user
	define('PASS',   "!aA111111");                                  // database pass
	define('SITENAME',   "DoualaZoom.com");                         // site name
	define('SITEPASS',   "aDmin58965");                             // site pass