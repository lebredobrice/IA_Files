<?php
	header('Content-Type: text/html; charset=UTF-8');
	
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
	
	$f01 = fopen( "francais_anglais.txt", "r" ) or exit( "Unable to open file!" ); // for read lines
	$f02 = fopen( "english_spain.txt",  "r" ) or exit( "Unable to open file!" );// for write results
	$f03 = fopen( "francais_espagnol.txt", "w" ) or exit( "Unable to open file!" );// for write results
	
	$translationArr = array();
	$i = 0;
	// fill translation array with french rubrique name
	while ( !feof( $f01 ) ){
		$line  = fgets( $f01 ); // Make an array new line and space as delimiter
		if( $line ){
			$lineTab = explode( '*', $line ); //
			if( isset( $lineTab[0] ) ){
				$rubrique = trim( $lineTab[0] );
				$translationArr[$i]['rubrique'] = $rubrique;
			}
		}
		$i++;
	}
	// fill translation array with translations
	$i = 0;
	while ( !feof( $f02 ) ){
		$line = fgets( $f02 ); // Make an array new line and space as delimiter
		if( $line ){
			$lineTab = explode( '*', $line ); //
			if( isset( $lineTab[1] ) ){
				$trans = trim( $lineTab[1] );
				$translationArr[$i]['translation'] = $trans;
			}
		}
		$i++;
	}
	// output
	$i = 0;
	foreach( $translationArr as $value){
		$rubrique  = $value['rubrique'];
		$translation = $value['translation'];
		
		fwrite( $f03,  $rubrique."*".$translation."\r\n"  );
		echo "$rubrique*$translation <br>";
		$i++;
	}
	// bye
	fclose($f01);
	fclose($f02);
	fclose($f03);