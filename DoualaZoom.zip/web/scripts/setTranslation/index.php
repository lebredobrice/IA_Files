<?php 
// error reporting
error_reporting(E_ALL);
ini_set("display_errors", 1);

//header
include("header.php");

// autoloader   
function my_autoloader($class) {
    include __DIR__.'/class/'.$class.'.php';
}
spl_autoload_register('my_autoloader');


// main
if( isset( $_POST['commencer'] ) ){
	// warnings message
	$filename = "";
	// get tranlation langue
	if( isset( $_POST['langue'] ) ){
		$langueId = $_POST['langue'];
		// upload tranlation list
		$file = new UploadAndCopyFile;
		$filename = $file->uploadSave($langueId);
		// set translatiion list
		if( $filename ){
			$setTranslation = new SetTranslation;
			$setTranslation->iterate($langueId); // we prefere to use valu which is the langage id
		}
		else{
			echo "Erreur: importez un fichier de traduction svp!<br>";
		}
	}
	else{
		echo "Erreur: choisissez un fichier et indiquez la langue de traduction du fichier<br>";
	}
}
// reinitialisation du formilaire
unset( $_POST );

echo "
<p>&nbsp;</p>
<p>&nbsp;</p>";

// footer
include("footer.php");