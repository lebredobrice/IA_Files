<?php
header('Content-Type: text/html; charset=UTF-8');

if(!isset($_SESSION)){
	session_start();
//	session_destroy();
}

// Few config
include('config.php');

echo "<p><span style='font-size:2em'>".SITENAME."</span></p>";
echo "<p style='font-style:italic'>Set Zoom's Rubrique Translations</p>";

// correct password
$password = SITEPASS;               // password
if(isset($_POST['password']) && $_POST['password'] == $password){
	$_SESSION['typedpassword'] = $_POST['password'];                // le client est logu�
}

if(isset($_POST['password']) && $_POST['password'] != $password){
		echo "<p style='color:red'>Mot de passe incorrect<br></p>";
}
// Formulaire � afficher
if(isset($_SESSION['typedpassword']) ){
	echo "<p style='color:green'>Bienvenue admin  <a href='logout.php'>deconnexion</a></p>";
	echo "<p>At the end of the treatment, download a report <a href = '".$_SESSION['fileDir']."/".$_SESSION['outputfile']."' download = '".$_SESSION['fileDir']."/".$_SESSION['outputfile']."' target='_blank'>here</a></p>";
	echo "<p>
			<form method='post' enctype='multipart/form-data'>
				<div style='background-color:#F4F4F4; width:80%;'>
				<label>".utf8_encode('1- Importer un fichier .txt au format [rubriqueEnFran�ais * rubriqueTraduite]')."<br><br>
				<input type='file' name=".$_SESSION['inputName']." id='emailfile'>
				</label><br><br>
				<label>2- Langue de traduction du fichier</label><br>
					".utf8_encode('Fran�ais')." vers 
					<select name='langue'>
						<option value='' disabled selected>Choisissez</option>
						<option value = 1>".utf8_encode('Anglais')."</option>
						<option value = 2>".utf8_encode('Fran�ais')."</option>
						<option value = 3>".utf8_encode('Chinois')."</option>
						<option value = 4>".utf8_encode('Espagnol')."</option>
						<option value = 5>".utf8_encode('Arabe')."</option> 
					</select>
				<br><br>
				</div>
				<input type='hidden' name='commencer'>
				<br><input type='submit' value='COMMENCER' style='height:40px; width:175px'>
			</form>
		 </p>";
}
else{
	echo "<p>veuillez vous identifier pour continuer</p>";
	echo "<p><form method='post'>
		     <input type='password' name='password' name='password'><input type='submit' value='ok'>
			 </form>
		  </p>";
}

// session_destroy();