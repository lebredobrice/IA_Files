<?php
use Webadress\Xlsx\Xlsx;
use Webadress\FileUpload\Upload;
use Webadress\UpdateDatabase\Update;
// id to name

// File upmpad form
echo "<form method='post' enctype='multipart/form-data'>
	  	<input type='file' name='fileToUpload' id='fileToUpload'>
		<input type='submit' value='Upload file & update datas' name='submit'>
	  </form>";
// upload file
if(isset($_POST["submit"])) {
	$upload = new Upload;
// delete all files before upload
	$upload->deleteDirFiles();
// upload
	$uploadResult = $upload->fileUpload();
// Treat the uploaded file
	if($uploadResult){
		$Xlsx = new Xlsx;
		$companyInfo = $Xlsx->getPHPArray($uploadResult);
		// update datas
		$Update = new Update;
		$message = $Update->updateData($companyInfo);
		// affichage resultat';
		echo '<br><br>Update Result:<br>';
		echo $Update->message.'<br>';
		foreach($message as $key=>$value){
			foreach($value as $a=>$b){
				echo "$a: $b<br>";
			}
			echo '<br>';
		}	
	}
}