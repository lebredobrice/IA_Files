<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>DoualaZoom.com - UpdateRues script</title>
</head>
<?php
//session_start();
//if(empty($_SESSION["authenticated"]) || $_SESSION["authenticated"] != 'true') {
//    header('Location: index.php');
//}

?>
<body>
*** DOUALAZOOM.com ***<br /><br />
Ce script ajoute les valeurs dans la table Rublique.
Les Rubrique sont soumises dans le fichier texte nom&eacute; <b>insertRubriques.txt</b> plac&eacute; dans le meme dossier.
<br /><br /><br /><br />
<?php
header('Content-Type: text/html; charset= iso 8859 1');

function insertline($rubrique){
	try{
		$myPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}
	$query = "INSERT INTO rubrique (rubrique, description) VALUES ($rubrique, $rubrique)";
	$count = $myPDO->exec($query);
	if($count == 1){
		echo 'La rubrique '.$rubrique.' a �t� ajout�e.<br>';
	}
	else{
		echo "erreur".$count;
	}
} 

function treatlist($list){
	$rowcount = 0;
	$f01 = fopen($list, "r") or exit("Unable to open file!");
	while (!feof($f01)){
		$line = explode('"',fgets($f01)); // Make an array new line and space as delimiter
		// rue
		$rubrique = trim($line[0]);
		// update
		echo $rowcount."<br>";
		insertline($rubrique);
		$rowcount++;
	}
}
var_dump($line);
$list = 'insertRubrique.txt';
treatlist($list);

?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
Copyright 2018 - DoualaZoom.com
</body>
</html>