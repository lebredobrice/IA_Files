<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>DoualaZoom.com - UpdateRues script</title>
</head>
<?php
//session_start();
//if(empty($_SESSION["authenticated"]) || $_SESSION["authenticated"] != 'true') {
//    header('Location: index.php');
//}

?>
<body>
*** DOUALAZOOM.com ***<br /><br />
Ce script update les valeurs du champ Rubrique.
Les Rubrique sont soumises dans le fichier texte nom&eacute; <b>updateRubriques.txt</b> plac&eacute; dans le meme dossier.
<br /><br /><br /><br />
<?php
header('Content-Type: text/html; charset= iso 8859 1');

function update($id, $rubrique){
	try{
		$MyPDO = new PDO('mysql:host = localhost; dbname=default_db', 'root', '');
	}
	catch (PDOException $e){
		echo 'Erreur:'.$e->getMessage();
	}
	$query = "UPDATE rubrique SET rubrique = '$rubrique', description = '$rubrique' WHERE rubrique.id = '$id'";
	$stmt = $MyPDO->prepare($query);
	$stmt->execute();
	$count = $stmt->rowCount();
	if($count){
		echo 'La rubrique '.$rubrique.' mise � jour avec les cordonn�s'.$rubrique.'<br>';
	}
	else{
		echo 'La rubrique '.$rubrique.' d�ja � jour <br>' ;
	}
	$MyPDO = NULL;
}

function treatlist($list){
	$counteur = 0;
	$f01 = fopen($list, "r") or exit("Unable to open file!");
	while (!feof($f01)){
		$line = explode('"',fgets($f01)); // Make an array new line and space as delimiter
		$rubriqueTab = explode('*', $line[0]); //
		// rue
		$id = trim($rubriqueTab[0]);
		$rubrique = trim($rubriqueTab[1]);
		// update
		echo $counteur."<br>";
		update($id, $rubrique);
		$counteur++;
	}
}
$list = basename(__DIR__).'.txt';
treatlist($list);

?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
Copyright 2017 - DoualaZoom.com
</body>
</html>