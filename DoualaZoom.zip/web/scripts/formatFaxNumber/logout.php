<?php 
// error reporting
error_reporting(E_ALL);
ini_set("display_errors", 1);

// autoloader   
function my_autoloader($class) {
    include __DIR__.'/class/'.$class.'.php';
}
spl_autoload_register('my_autoloader');

//header
include("header.php");
// kill sesion
session_destroy();
header("Location: index.php");

echo "
<p>&nbsp;</p>
<p>&nbsp;</p>";

// footer
include("footer.php");