<?php
/**
 *	Update de la base de donn�e
 **/

class update
{
	public $message;

	public $connexion;
	
	public function __construct(){
		// connexion
		$this->connexion = new Dbconnexion;
		$this->connexion->connect();
	}
	
	// update database
	public function updatenumbers($numbersArray){
		$total = count($numbersArray);
		$i = 0; // controlleur
		$updated = array();
	    try{
			foreach($numbersArray as $key => $value){ // walk thru  the formated numbers and update the database
				$id  =  $value['id'];
				$fax =  $value['fax'];
				$sql =  "
						UPDATE  activite
					 	SET fax  = '$fax'
					 	WHERE id = $id
						";

				$stmt   = $this->connexion->MyPDO->prepare($sql);
				$stmt->execute();

				// array � retourner
				$updated[$id]['id']  = $id;
				$updated[$id]['fax'] = $fax;
				if( $stmt->rowCount() ){
					$i++;
				}
			}
			$this->message = utf8_encode("$i entreprises modifi�es sur $total");
		}
		catch(Exception $e){
			$this->message = utf8_encode("ERREUR! $i insertion(s) sur $total,").$e->getMessage();
		}
		return $updated;
	}
}