<?php
/**
	Formatage des numeros de telephone 698 ** ** ** devient +237 698 ** ** **
**/

class modification
{
	// verifcation de la validit� du numero
	public function verification($numero){
		if( trim(strlen($numero)) == 12){
			return true;
		}
		else{
			return false;
		}
	}
	
	// formatage du numero numero
	public function formatel($numero){
		$formated_number = "+237 ".$numero;
		return $formated_number;
	}
}