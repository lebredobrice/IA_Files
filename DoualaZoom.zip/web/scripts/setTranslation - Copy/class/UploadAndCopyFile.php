<?php
/**
 *	Upload a file and save it
 *  return the file name
 **/

class UploadAndCopyFile
{
/**	public $fileDir;
	public $inputName;
	
	public function __construct(){
		$this->fileDir   = '../file'; // upload directrory
		$this->inputName = 'companiesFile'; // upload directrory
	}
**/

	// upload and save file
	public function uploadSave($languageId){
		// uploaded file name
		$inputName    = $_SESSION['inputName'];
		$filename     = $_FILES[$inputName]['name'];
		$tmpfilename  = $_FILES[$inputName]['tmp_name'];
		$directory    = $_SESSION['fileDir'];

		// move upploaded
		$message = move_uploaded_file($tmpfilename , "$directory/$languageId" );
		//
		if($message){
			return $filename;
		}
		return $message;
	}
}
