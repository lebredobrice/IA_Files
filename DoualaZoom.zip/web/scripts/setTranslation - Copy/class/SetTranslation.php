<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
/**
 *  This script wipe the translation table
 *  iterate a translation file, line by line
 *  get each translated id from rubrique table
 *  ge langage id from the translation file name
 *  insert the translatons
 **/

// create connexion object to database
require_once("Dbconnexion.php");

class SetTranslation
{
	public $connexion;
	
	public function __construct(){
		// connexion
		$this->connexion = new Dbconnexion;
		$this->connexion->connect();
	}

	// if item exist, get his id, if not, insert and get id
	public function idFromItem( $item, $table ){
		// is item exist in the database
		$id = '';
		$isItemExist = $this->isAlreadyExist($item, $table);
		if( $isItemExist ){ // just get the id
			$id = $this->getId( $item, $table );
		}
		if( !$isItemExist ){ // insert and get the id
			$id = $this->insertGetId( $item, $table );
		}
		return $id;
	}

	// insert translation
	public function insertTranslation( $languageId, $rubriqueId, $translation, $translatedId ){
		$this->connexion->MyPDO->quote($translation);
		$this->connexion->MyPDO->exec("set names utf8");
		$query = "INSERT INTO translation ( language_id, table_id, translation, translatedid ) 
				  VALUES ( 
						  '$languageId', 
						  '$rubriqueId',
						  :translation, 
						  '$translatedId',
						)";
		$stmt = $this->connexion->MyPDO->prepare($query);
		$stmt->execute([':translation' => $translation]);
		$id = $this->connexion->MyPDO->lastInsertId();

		if(!$id){
			return false;
		}
		return $id;
	}
	// iterate and insert
    public function iterate($file){
		//delete all translation
		deleteAllTranslation("rubrique")
		$i = 1;
		$directory  = $_SESSION['fileDir'];
		$outputfile = $_SESSION['outputfile'];
		$f01 = fopen("$directory/$file", "r") or exit("Unable to open file!"); // for read lines
		$f02 = fopen("$directory/$outputfile",  "w") or exit("Unable to open file!");// for write results
		$date       =  date("d/m/Y");
		fwrite($f02, utf8_encode("Entreprises ajout�es avec succes ($date)\r\n\r\n"));
		while (!feof($f01)){
			$line = fgets($f01); // Make an array new line and space as delimiter
			$lineTab = explode('*', $line); //
			if( isset( $lineTab[1] ) ){

				echo '<b>'.$i.'- '.$lineTab[0].'</b>:<br>';

				// rubrique
				$rubrique     = trim( $lineTab[0] );
				// translation
				$translation  = trim( $lineTab[1] );
				// language Id
				$langageIdTab = explode( '.', $file );
				$languageId   = $langageIdTab[0];
				// translated id
				if( $rubrique ){
					$translatedId = $this->idFromItem( $rubrique, 'rubrique' );
				}
				// insert
				if( $translatedId ){
					// insert new translation
					$inserted = $this->insertTranslation( $languageId, 1, $translation, $translatedId );
					// write result in a file
					if( $inserted ){
						fwrite($f02, utf8_encode("$entreprise, Id: $entrepriseId,  quartier:$quartier:  succ�s\r\n"));
						echo utf8_encode("<span style='color: green'>SUCCES </span>$rubrique - $translation<br>");
					}
					else{
						echo utf8_encode("<span style='color: red'>x Erreur: $rubrique - $translation<br>") ;
					}
					$i++;
				}
			}
		}
	}

	// delete all translation
	public function deleteAllTranslation($table){
		$this->connexion->MyPDO->quote($item);
		$query = "DELETE FROM $table";
		$stmt   = $this->connexion->MyPDO->prepare($query);
		$stmt->execute( [':item' => $item] );
		$count = $stmt->rowCount();

		if($count){
			echo utf8_encode("<span style='color:green'>$item effac� de la table $table $count fois</span><br>");
		}
		else{
			echo utf8_encode("<span style='color:red'>0 suppression</span><br>") ;
		}
	}
}

// $insertTrans->getRubriqueId('Abattoir');
?>


