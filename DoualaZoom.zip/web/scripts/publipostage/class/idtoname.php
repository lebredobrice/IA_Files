<?php
/**
	retourne le nom d'un element en fonction de son id dans la table activite
**/

class idtoname
{
	public $connexion;
	
	public function __construct(){
		// connexion
		$this->connexion = new Dbconnexion;
		$this->connexion->connect();
	}
	// id to name
	public function getName($elementId, $elementType){
	    if($elementType == 'activite'){ // cas particulier de la table activite qui a pour champ de nom 'entreprise'
			$sql =  "SELECT entreprise FROM $elementType WHERE id = '$elementId'";
		}
		else{
			$sql =  "SELECT $elementType FROM $elementType WHERE id = '$elementId'";
		}
		
		//connexion
		$stmt  = $this->connexion->MyPDO->prepare($sql);
		$this->connexion->MyPDO->exec("set names utf8");
		$stmt->execute();
		$result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
		$name = "";
    	foreach  ($result as $row) {
			$name = $row[$elementType];
  		}
		$connexion = NULL;
		return $name;
	}
}

